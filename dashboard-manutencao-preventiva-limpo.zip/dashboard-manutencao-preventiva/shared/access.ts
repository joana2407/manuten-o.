export type PerfilAcesso = "tecnico" | "manutencao" | "qualidade" | "gestao" | "observador";

export interface AcessoPerfil {
  perfil: PerfilAcesso;
  funcao: string;
  podeRegistar: boolean;
  podeValidar: boolean;
  podeGerir: boolean;
  podeGerirEquipamentos: boolean;
  podeGerirPins: boolean;
  podeGerirUtilizadores: boolean;
}

const PERFIS: Record<PerfilAcesso, Omit<AcessoPerfil, "perfil">> = {
  tecnico: { funcao: "Téc. Manutenção", podeRegistar: true, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true, podeGerirPins: false, podeGerirUtilizadores: false },
  manutencao: { funcao: "Resp. Manutenção", podeRegistar: true, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true, podeGerirPins: false, podeGerirUtilizadores: false },
  qualidade: { funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true, podeGerirPins: true, podeGerirUtilizadores: true },
  gestao: { funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true, podeGerirEquipamentos: true, podeGerirPins: true, podeGerirUtilizadores: true },
  observador: { funcao: "Acesso de consulta", podeRegistar: false, podeValidar: true, podeGerir: false, podeGerirEquipamentos: false, podeGerirPins: false, podeGerirUtilizadores: false },
};

const PERFIL_POR_NOME: Record<string, PerfilAcesso> = {
  "alfredo silva": "tecnico",
  "marco monteiro": "manutencao",
  "joana pina": "qualidade",
  "gestão": "gestao",
  "gestao": "gestao",
};

export function obterPerfilPorNome(nome: string): AcessoPerfil {
  const perfil = PERFIL_POR_NOME[nome.trim().toLocaleLowerCase("pt-PT")] ?? "observador";
  return { perfil, ...PERFIS[perfil] };
}

/** Perfis base documentados sem credenciais; os PINs existem apenas como hashes na base de dados. */
export function perfisBase() {
  return [
    { nome: "Alfredo Silva", perfil: "tecnico" as const },
    { nome: "Marco Monteiro", perfil: "manutencao" as const },
    { nome: "Joana Pina", perfil: "qualidade" as const },
    { nome: "Gestão", perfil: "gestao" as const },
  ];
}
