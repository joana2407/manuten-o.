export const getLoginUrl = () => "/acesso";
