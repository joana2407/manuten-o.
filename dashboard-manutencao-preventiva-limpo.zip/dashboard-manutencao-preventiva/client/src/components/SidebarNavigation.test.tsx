/** @vitest-environment jsdom */
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  location: "/",
  setLocation: vi.fn(),
  listarAreas: vi.fn(),
  seedAreasBase: vi.fn(),
  utils: { gestao: { listarAreas: { invalidate: vi.fn() } } },
}));

vi.mock("wouter", () => ({
  useLocation: () => [mocks.location, mocks.setLocation],
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    gestao: {
      listarAreas: { useQuery: mocks.listarAreas },
      seedAreasBase: { useMutation: mocks.seedAreasBase },
    },
    useUtils: () => mocks.utils,
  },
}));

vi.mock("./ModalGestaoArea", () => ({ ModalGestaoArea: () => null }));

import { Sidebar } from "./Sidebar";

afterEach(() => {
  cleanup();
  mocks.location = "/";
  mocks.setLocation.mockReset();
});

const filtros = { areas: [], estados: [], mes: null, busca: "", responsavel: null, fabrica: null } as any;

function renderSidebar(location = "/") {
  mocks.location = location;
  mocks.listarAreas.mockReturnValue({ data: [] });
  mocks.seedAreasBase.mockReturnValue({ mutate: vi.fn() });
  return render(
    <Sidebar
      areas={[]}
      filtros={filtros}
      setFiltros={vi.fn()}
      totalFiltrado={0}
      totalGlobal={0}
      collapsed={false}
      onToggleCollapse={vi.fn()}
    />,
  );
}

describe("Atalhos laterais de manutenção", () => {
  it("mantém os dois atalhos disponíveis no modo de sidebar aberto em ecrã móvel", () => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    renderSidebar();

    expect(screen.getByRole("navigation", { name: "Navegação de manutenção" })).toBeTruthy();
    expect(screen.getByRole("button", { name: "Manutenção Preventiva" }).getAttribute("aria-current")).toBe("page");
    expect(screen.getByRole("button", { name: "Manutenção Corretiva" })).toBeTruthy();
  });

  it("navega de Preventiva para Corretiva e assinala o destino ativo", async () => {
    const { rerender } = renderSidebar();
    await userEvent.click(screen.getByRole("button", { name: "Manutenção Corretiva" }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/corretiva");

    mocks.location = "/corretiva";
    rerender(
      <Sidebar areas={[]} filtros={filtros} setFiltros={vi.fn()} totalFiltrado={0} totalGlobal={0} collapsed={false} onToggleCollapse={vi.fn()} />,
    );
    expect(screen.getByRole("button", { name: "Manutenção Corretiva" }).getAttribute("aria-current")).toBe("page");

    mocks.location = "/";
    rerender(
      <Sidebar areas={[]} filtros={filtros} setFiltros={vi.fn()} totalFiltrado={0} totalGlobal={0} collapsed={false} onToggleCollapse={vi.fn()} />,
    );
    await userEvent.click(screen.getByRole("button", { name: "Manutenção Preventiva" }));
    expect(mocks.setLocation).toHaveBeenLastCalledWith("/");
    expect(screen.getByRole("button", { name: "Manutenção Preventiva" }).getAttribute("aria-current")).toBe("page");
  });
});
