/*
 * ModalRealizacao — Modal para registar e consultar o histórico de intervenções
 * Design: Industrial Dark Analytics
 * Campos: data, responsável, intervenção realizada, material gasto, anexos (foto/doc)
 * Histórico: lista intervenções com anexos e opção de remover
 */
import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, CheckCircle2, Calendar, Plus, Trash2, ClipboardList, Pencil,
  AlertTriangle, Paperclip, FileText, Image as ImageIcon, Loader2, ExternalLink, ShieldCheck,
} from 'lucide-react';
import { ModalValidacao } from '@/components/ModalValidacao';
import { ModalEditarIntervencao } from '@/components/ModalEditarIntervencao';
import type { Equipamento } from '@/lib/types';
import { calcularProxima, calcularEstadoPrazo } from '@/hooks/useRealizacoes';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';
import { formatDate } from '@/lib/utils';

interface ModalRealizacaoProps {
  equipamento: Equipamento | null;
  historico: IntervencaoDb[];
  onAdicionar: (data: string, intervencao: string, materialGasto: string, responsavel: string, responsavelValidacao?: string) => Promise<string>;
  onRemoverIntervencao: (id: string) => Promise<void>;
  onUploadAnexo: (intervencaoId: string, file: File) => Promise<{ id: string; url: string }>;
  onFechar: () => void;
}

const TIPOS_ACEITES = 'image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt';
const MAX_BYTES = 10 * 1024 * 1024; // 10 MB

function iconeAnexo(mimeType: string) {
  if (mimeType.startsWith('image/')) return <ImageIcon size={13} />;
  return <FileText size={13} />;
}

function formatBytes(bytes: number | null): string {
  if (!bytes) return '';
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

export function ModalRealizacao({
  equipamento,
  historico,
  onAdicionar,
  onRemoverIntervencao,
  onUploadAnexo,
  onFechar,
}: ModalRealizacaoProps) {
  const hoje = new Date().toISOString().split('T')[0];
  const [data, setData] = useState(hoje);
  const [intervencao, setIntervencao] = useState('');
  const [materialGasto, setMaterialGasto] = useState('');
  const [responsavel, setResponsavel] = useState<string>('Alfredo');
  const [responsavelValidacao, setResponsavelValidacao] = useState<string>('');
  const [erro, setErro] = useState('');
  const [confirmarRemover, setConfirmarRemover] = useState<string | null>(null);
  const [aRegistar, setARegistar] = useState(false);
  const [intervencaoParaValidar, setIntervencaoParaValidar] = useState<IntervencaoDb | null>(null);
  const [intervencaoParaEditar, setIntervencaoParaEditar] = useState<IntervencaoDb | null>(null);

  // Anexos pendentes (antes de registar)
  const [ficheirosAnexo, setFicheirosAnexo] = useState<File[]>([]);
  const [erroAnexo, setErroAnexo] = useState('');
  const [uploadingAnexos, setUploadingAnexos] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (equipamento) {
      setData(hoje);
      setIntervencao('');
      setMaterialGasto('');
      setResponsavel('Alfredo');
      setResponsavelValidacao('');
      setErro('');
      setConfirmarRemover(null);
      setFicheirosAnexo([]);
      setErroAnexo('');
    }
  }, [equipamento]);

  if (!equipamento) return null;

  const proximaCalculada = calcularProxima(data, equipamento.periodicidade_norm);
  const estadoCalculado = proximaCalculada ? calcularEstadoPrazo(proximaCalculada) : null;

  const estadoCores: Record<string, string> = {
    vencido: '#EF4444',
    proximo: '#F59E0B',
    em_dia: '#10B981',
  };

  const handleSelecionarFicheiros = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    const invalidos = files.filter(f => f.size > MAX_BYTES);
    if (invalidos.length > 0) {
      setErroAnexo(`Ficheiro(s) demasiado grande(s). Máximo: 10 MB por ficheiro.`);
      return;
    }
    setErroAnexo('');
    setFicheirosAnexo(prev => [...prev, ...files]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleRemoverFicheiro = (idx: number) => {
    setFicheirosAnexo(prev => prev.filter((_, i) => i !== idx));
  };

  const handleAdicionar = async () => {
    try {
      const sessaoRaw = sessionStorage.getItem('validador_sessao');
      if (sessaoRaw) {
        const sessao = JSON.parse(sessaoRaw) as { podeRegistar?: boolean };
        if (!sessao.podeRegistar) {
          setErro('O perfil autenticado não tem autorização para registar manutenções.');
          return;
        }
      }
    } catch {
      // Uma sessão corrompida não bloqueia o dashboard público; o servidor continua a validar operações protegidas.
    }
    if (!data) { setErro('A data de realização é obrigatória.'); return; }
    if (data > hoje) { setErro('A data de realização não pode ser futura.'); return; }
    setErro('');
    setARegistar(true);
    try {
      const intervencaoId = await onAdicionar(data, intervencao, materialGasto, responsavel, responsavelValidacao);

      // Upload dos anexos após criar a intervenção
      if (ficheirosAnexo.length > 0 && intervencaoId) {
        setUploadingAnexos(true);
        for (const file of ficheirosAnexo) {
          try {
            await onUploadAnexo(intervencaoId, file);
          } catch (err) {
            console.error('Erro ao fazer upload do anexo:', err);
          }
        }
        setUploadingAnexos(false);
      }

      setData(hoje);
      setIntervencao('');
      setMaterialGasto('');
      setResponsavel('Alfredo');
      setResponsavelValidacao('');
      setFicheirosAnexo([]);
    } finally {
      setARegistar(false);
      setUploadingAnexos(false);
    }
  };

  const isLoading = aRegistar || uploadingAnexos;

  return (
    <>
    <AnimatePresence>
      {equipamento && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40"
            style={{ background: 'oklch(0.05 0.005 240 / 0.85)', backdropFilter: 'blur(4px)' }}
            onClick={onFechar}
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 16 }}
            transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            onClick={e => e.stopPropagation()}
          >
            <div
              className="w-full max-w-lg rounded-xl overflow-hidden flex flex-col"
              style={{
                background: 'oklch(0.13 0.007 240)',
                border: '1px solid oklch(0.28 0.01 240)',
                boxShadow: '0 24px 64px oklch(0.05 0.005 240 / 0.8)',
                maxHeight: '90vh',
              }}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-5 py-4 flex-shrink-0" style={{ borderBottom: '1px solid oklch(0.22 0.008 240)' }}>
                <div className="flex items-center gap-2">
                  <ClipboardList size={18} style={{ color: 'oklch(0.72 0.18 60)' }} />
                  <span className="font-semibold text-sm" style={{ color: 'oklch(0.92 0.005 240)' }}>
                    Registo de Manutenção
                  </span>
                </div>
                <button
                  onClick={onFechar}
                  className="p-1.5 rounded hover:bg-white/10 transition-colors"
                  style={{ color: 'oklch(0.55 0.01 240)' }}
                >
                  <X size={16} />
                </button>
              </div>

              {/* Corpo com scroll */}
              <div className="overflow-y-auto flex-1">
                {/* Informação do equipamento */}
                <div className="px-5 pt-4">
                  <div className="px-4 py-3 rounded-lg" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-mono mb-0.5" style={{ color: 'oklch(0.72 0.18 60)' }}>{equipamento.codigo}</p>
                        <p className="text-sm font-medium leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>{equipamento.equipamento}</p>
                        <p className="text-xs mt-0.5" style={{ color: 'oklch(0.52 0.01 240)' }}>{equipamento.area}</p>
                      </div>
                      <span
                        className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                        style={{ background: 'oklch(0.72 0.18 60 / 0.15)', color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.3)' }}
                      >
                        {equipamento.periodicidade}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Formulário de nova intervenção */}
                <div className="px-5 pt-4 pb-2">
                  <p className="text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-1.5" style={{ color: 'oklch(0.72 0.18 60)' }}>
                    <Plus size={13} />
                    Registar nova intervenção
                  </p>

                  {/* Data */}
                  <div className="mb-3">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      <Calendar size={11} className="inline mr-1" />
                      Data de Realização *
                    </label>
                    <input
                      type="date"
                      value={data}
                      max={hoje}
                      onChange={e => { setData(e.target.value); setErro(''); }}
                      className="w-full px-3 py-2 rounded text-sm outline-none transition-colors"
                      style={{
                        background: 'oklch(0.1 0.006 240)',
                        border: `1px solid ${erro ? '#EF4444' : 'oklch(0.28 0.01 240)'}`,
                        color: 'oklch(0.92 0.005 240)',
                        colorScheme: 'dark',
                      }}
                    />
                    {erro && (
                      <p className="text-xs mt-1 flex items-center gap-1" style={{ color: '#EF4444' }}>
                        <AlertTriangle size={11} /> {erro}
                      </p>
                    )}
                  </div>

                  {/* Próxima calculada */}
                  {proximaCalculada && (
                    <div className="flex items-center justify-between px-3 py-2 rounded-lg mb-3" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
                      <span className="text-xs" style={{ color: 'oklch(0.52 0.01 240)' }}>Próxima manutenção calculada</span>
                      <span className="text-sm font-mono font-semibold" style={{ color: estadoCalculado ? estadoCores[estadoCalculado] ?? '#10B981' : '#10B981' }}>
                        {formatDate(proximaCalculada)}
                      </span>
                    </div>
                  )}

                  {/* Plano de Intervenção (leitura) */}
                  {equipamento.planoIntervencao && (
                    <div className="mb-3 px-3 py-3 rounded-lg" style={{ background: 'oklch(0.55 0.18 260 / 0.08)', border: '1px solid oklch(0.55 0.18 260 / 0.25)' }}>
                      <p className="text-xs font-semibold uppercase tracking-wider mb-1.5 flex items-center gap-1.5" style={{ color: 'oklch(0.72 0.15 260)' }}>
                        <ClipboardList size={12} />
                        Plano de Intervenção
                      </p>
                      <p className="text-xs whitespace-pre-wrap leading-relaxed" style={{ color: 'oklch(0.82 0.005 240)' }}>
                        {equipamento.planoIntervencao}
                      </p>
                    </div>
                  )}

                  {/* Responsável */}
                  <div className="mb-3">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      Responsável
                    </label>
                    <div className="flex gap-2">
                      {(['Alfredo', 'Marco', 'Outro: Externo'] as const).map(opcao => (
                        <button
                          key={opcao}
                          type="button"
                          onClick={() => setResponsavel(opcao)}
                          className="flex-1 py-2 px-2 rounded text-xs font-semibold transition-all"
                          style={{
                            background: responsavel === opcao ? 'oklch(0.55 0.18 260 / 0.25)' : 'oklch(0.1 0.006 240)',
                            border: `1px solid ${responsavel === opcao ? 'oklch(0.55 0.18 260 / 0.7)' : 'oklch(0.28 0.01 240)'}`,
                            color: responsavel === opcao ? 'oklch(0.82 0.15 260)' : 'oklch(0.62 0.01 240)',
                            transform: responsavel === opcao ? 'scale(1)' : 'scale(0.98)',
                          }}
                        >
                          {opcao}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Intervenção realizada */}
                  <div className="mb-3">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      Intervenção realizada
                    </label>
                    <textarea
                      value={intervencao}
                      onChange={e => setIntervencao(e.target.value)}
                      placeholder="Descreva a intervenção realizada..."
                      rows={2}
                      className="w-full px-3 py-2 rounded text-sm outline-none resize-none transition-colors"
                      style={{
                        background: 'oklch(0.1 0.006 240)',
                        border: '1px solid oklch(0.28 0.01 240)',
                        color: 'oklch(0.88 0.005 240)',
                      }}
                    />
                  </div>

                  {/* Material gasto */}
                  <div className="mb-3">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      Material gasto
                    </label>
                    <textarea
                      value={materialGasto}
                      onChange={e => setMaterialGasto(e.target.value)}
                      placeholder="Liste o material utilizado (peças, consumíveis, quantidades)..."
                      rows={2}
                      className="w-full px-3 py-2 rounded text-sm outline-none resize-none transition-colors"
                      style={{
                        background: 'oklch(0.1 0.006 240)',
                        border: '1px solid oklch(0.28 0.01 240)',
                        color: 'oklch(0.88 0.005 240)',
                      }}
                    />
                  </div>

                  {/* Responsável pela Validação/Libertação */}
                  <div className="mb-3">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      Responsável pela Validação / Libertação
                    </label>
                    <input
                      type="text"
                      value={responsavelValidacao}
                      onChange={e => setResponsavelValidacao(e.target.value)}
                      placeholder="Nome do responsável pela validação (opcional)..."
                      className="w-full px-3 py-2 rounded text-sm outline-none transition-colors"
                      style={{
                        background: 'oklch(0.1 0.006 240)',
                        border: '1px solid oklch(0.28 0.01 240)',
                        color: 'oklch(0.88 0.005 240)',
                      }}
                    />
                  </div>

                  {/* Anexos */}
                  <div className="mb-4">
                    <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      <Paperclip size={11} className="inline mr-1" />
                      Anexos (fotos / documentos)
                    </label>
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept={TIPOS_ACEITES}
                      multiple
                      className="hidden"
                      onChange={handleSelecionarFicheiros}
                    />
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-2 px-3 rounded text-xs font-medium transition-colors hover:bg-white/10 flex items-center justify-center gap-2"
                      style={{ border: '1px dashed oklch(0.35 0.01 240)', color: 'oklch(0.55 0.01 240)' }}
                    >
                      <Paperclip size={12} />
                      Selecionar ficheiros (máx. 10 MB cada)
                    </button>
                    {erroAnexo && (
                      <p className="text-xs mt-1 flex items-center gap-1" style={{ color: '#EF4444' }}>
                        <AlertTriangle size={11} /> {erroAnexo}
                      </p>
                    )}
                    {ficheirosAnexo.length > 0 && (
                      <div className="mt-2 flex flex-col gap-1">
                        {ficheirosAnexo.map((f, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between px-2.5 py-1.5 rounded"
                            style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}
                          >
                            <div className="flex items-center gap-1.5 min-w-0">
                              <span style={{ color: 'oklch(0.55 0.01 240)' }}>{iconeAnexo(f.type)}</span>
                              <span className="text-xs truncate" style={{ color: 'oklch(0.78 0.005 240)' }}>{f.name}</span>
                              <span className="text-xs flex-shrink-0" style={{ color: 'oklch(0.42 0.01 240)' }}>{formatBytes(f.size)}</span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleRemoverFicheiro(idx)}
                              className="p-1 rounded hover:bg-white/10 flex-shrink-0"
                              style={{ color: 'oklch(0.42 0.01 240)' }}
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Botões */}
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={onFechar}
                      disabled={isLoading}
                      className="px-4 py-2 rounded text-xs font-medium transition-colors hover:bg-white/10 disabled:opacity-50"
                      style={{ color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}
                    >
                      Fechar
                    </button>
                    <button
                      onClick={handleAdicionar}
                      disabled={isLoading}
                      className="flex items-center gap-1.5 px-4 py-2 rounded text-xs font-semibold transition-all active:scale-95 disabled:opacity-60 disabled:cursor-not-allowed"
                      style={{ background: 'oklch(0.62 0.18 155 / 0.25)', color: '#10B981', border: '1px solid oklch(0.62 0.18 155 / 0.5)' }}
                    >
                      {isLoading ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                      {uploadingAnexos ? 'A enviar anexos...' : aRegistar ? 'A registar...' : 'Registar'}
                    </button>
                  </div>
                </div>

                {/* Histórico de intervenções */}
                {historico.length > 0 && (
                  <div className="px-5 pb-5 pt-3" style={{ borderTop: '1px solid oklch(0.2 0.008 240)', marginTop: '0.75rem' }}>
                    <p className="text-xs font-semibold uppercase tracking-wider mb-3 flex items-center gap-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                      <ClipboardList size={13} />
                      Histórico de intervenções ({historico.length})
                    </p>
                    <div className="flex flex-col gap-2">
                      {historico.map((item, idx) => (
                        <motion.div
                          key={item.id}
                          initial={{ opacity: 0, x: -8 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: idx * 0.04 }}
                          className="rounded-lg px-3 py-2.5"
                          style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.2 0.008 240)' }}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 mb-1 flex-wrap">
                                <span className="text-xs font-mono font-semibold" style={{ color: '#10B981' }}>
                                  {formatDate(item.dataRealizacao)}
                                </span>
                                {idx === 0 && (
                                  <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'oklch(0.62 0.18 155 / 0.2)', color: '#10B981', fontSize: '10px' }}>
                                    mais recente
                                  </span>
                                )}
                                {item.validadoEm ? (
                                  <span className="text-xs px-1.5 py-0.5 rounded-full flex items-center gap-1" style={{ background: '#22C55E11', color: '#22C55E', border: '1px solid #22C55E33', fontSize: '10px' }}>
                                    <ShieldCheck size={9} /> Validado
                                  </span>
                                ) : (
                                  <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'oklch(0.72 0.18 60 / 0.1)', color: 'oklch(0.72 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.3)', fontSize: '10px' }}>
                                    Por validar
                                  </span>
                                )}
                              </div>
                              {/* Responsável */}
                              {item.responsavel && (
                                <div className="flex items-center gap-1.5 mb-1">
                                  <span className="text-xs font-medium" style={{ color: 'oklch(0.52 0.01 240)' }}>Responsável:</span>
                                  <span className="text-xs font-semibold" style={{ color: 'oklch(0.82 0.12 60)' }}>{item.responsavel}</span>
                                </div>
                              )}
                              {item.responsavelValidacao && (
                                <div className="flex items-center gap-1.5 mb-1">
                                  <span className="text-xs font-medium" style={{ color: 'oklch(0.52 0.01 240)' }}>Resp. validação/libertação:</span>
                                  <span className="text-xs font-semibold" style={{ color: 'oklch(0.78 0.005 240)' }}>{item.responsavelValidacao}</span>
                                </div>
                              )}
                              {item.validadoPor && (
                                <div className="flex items-center gap-1.5 mb-1">
                                  <span className="text-xs font-medium" style={{ color: 'oklch(0.52 0.01 240)' }}>Validado por:</span>
                                  <span className="text-xs font-semibold" style={{ color: '#22C55E' }}>{item.validadoPor}</span>
                                </div>
                              )}
                              {/* Intervenção realizada */}
                              {item.intervencaoRealizada ? (
                                <div className="mb-1">
                                  <span className="text-xs font-medium block mb-0.5" style={{ color: 'oklch(0.52 0.01 240)' }}>Intervenção:</span>
                                  <p className="text-xs leading-relaxed" style={{ color: 'oklch(0.75 0.005 240)' }}>
                                    {item.intervencaoRealizada}
                                  </p>
                                </div>
                              ) : null}
                              {/* Material gasto */}
                              {item.materialGasto ? (
                                <div className="mb-1">
                                  <span className="text-xs font-medium block mb-0.5" style={{ color: 'oklch(0.52 0.01 240)' }}>Material gasto:</span>
                                  <p className="text-xs leading-relaxed" style={{ color: 'oklch(0.75 0.005 240)' }}>
                                    {item.materialGasto}
                                  </p>
                                </div>
                              ) : null}
                              {!item.intervencaoRealizada && !item.materialGasto && !item.responsavel && (
                                <p className="text-xs italic" style={{ color: 'oklch(0.42 0.01 240)' }}>
                                  Sem descrição registada
                                </p>
                              )}
                              {/* Anexos */}
                              {item.anexos && item.anexos.length > 0 && (
                                <div className="mt-2">
                                  <span className="text-xs font-medium block mb-1" style={{ color: 'oklch(0.52 0.01 240)' }}>
                                    <Paperclip size={10} className="inline mr-1" />
                                    Anexos ({item.anexos.length}):
                                  </span>
                                  <div className="flex flex-col gap-1">
                                    {item.anexos.map(anexo => (
                                      <a
                                        key={anexo.id}
                                        href={anexo.storageUrl}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-white/10 transition-colors group"
                                        style={{ border: '1px solid oklch(0.22 0.008 240)' }}
                                      >
                                        <span style={{ color: 'oklch(0.55 0.01 240)' }}>{iconeAnexo(anexo.mimeType)}</span>
                                        <span className="text-xs truncate flex-1" style={{ color: 'oklch(0.72 0.005 240)' }}>{anexo.filename}</span>
                                        {anexo.tamanhoBytes && (
                                          <span className="text-xs flex-shrink-0" style={{ color: 'oklch(0.42 0.01 240)' }}>{formatBytes(anexo.tamanhoBytes)}</span>
                                        )}
                                        <ExternalLink size={10} className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" style={{ color: 'oklch(0.55 0.01 240)' }} />
                                      </a>
                                    ))}
                                  </div>
                                </div>
                              )}
                            </div>
                            {/* Botões: validar + remover */}
                            <div className="flex flex-col gap-1 flex-shrink-0">
                            <button
                              onClick={() => setIntervencaoParaEditar(item)}
                              className="p-1.5 rounded hover:bg-white/10 transition-colors flex-shrink-0"
                              style={{ color: 'oklch(0.72 0.18 60)' }}
                              title="Editar intervenção, material e validação"
                            >
                              <Pencil size={13} />
                            </button>
                            {!item.validadoEm && (
                              <button
                                onClick={() => setIntervencaoParaValidar(item)}
                                className="flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold transition-all active:scale-95"
                                style={{ background: '#22C55E', color: '#0a1a0a' }}
                                title="Validar intervenção"
                              >
                                <ShieldCheck size={11} />
                                Validar
                              </button>
                            )}
                            {confirmarRemover === item.id ? (
                              <div className="flex gap-1 flex-shrink-0">
                                <button
                                  onClick={() => setConfirmarRemover(null)}
                                  className="text-xs px-2 py-1 rounded transition-colors hover:bg-white/10"
                                  style={{ color: 'oklch(0.55 0.01 240)' }}
                                >
                                  Não
                                </button>
                                <button
                                  onClick={async () => { await onRemoverIntervencao(item.id); setConfirmarRemover(null); }}
                                  className="text-xs px-2 py-1 rounded transition-colors"
                                  style={{ background: 'oklch(0.62 0.22 25 / 0.2)', color: '#EF4444' }}
                                >
                                  Sim
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => setConfirmarRemover(item.id)}
                                className="p-1.5 rounded hover:bg-white/10 transition-colors flex-shrink-0"
                                style={{ color: 'oklch(0.42 0.01 240)' }}
                                title="Remover esta intervenção"
                              >
                                <Trash2 size={13} />
                              </button>
                            )}
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {historico.length === 0 && (
                  <div className="px-5 pb-5 pt-1">
                    <div className="rounded-lg px-4 py-3 text-center" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.2 0.008 240)' }}>
                      <p className="text-xs" style={{ color: 'oklch(0.42 0.01 240)' }}>
                        Sem intervenções registadas para este equipamento.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
    {intervencaoParaValidar && (
      <ModalValidacao
        intervencao={{ ...intervencaoParaValidar, nomeEquipamento: equipamento?.equipamento ?? undefined }}
        onValidada={() => setIntervencaoParaValidar(null)}
        onFechar={() => setIntervencaoParaValidar(null)}
      />
    )}
    {intervencaoParaEditar && (
      <ModalEditarIntervencao
        intervencao={intervencaoParaEditar}
        onGuardada={() => setIntervencaoParaEditar(null)}
        onFechar={() => setIntervencaoParaEditar(null)}
      />
    )}
    </>
  );
}
