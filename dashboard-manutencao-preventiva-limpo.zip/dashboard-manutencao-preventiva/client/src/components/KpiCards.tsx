/*
 * KpiCards — Industrial Dark Analytics
 * Exibe 5 KPI cards: Total, Vencidos, Próximos, Em dia, Inativos
 * Cores semáforo: vermelho (vencido) | âmbar (próximo) | verde (em dia) | cinzento (inativo)
 */
import { motion } from 'framer-motion';
import { AlertTriangle, Clock, CheckCircle2, PowerOff, Wrench } from 'lucide-react';

interface KpiCardsProps {
  total: number;
  vencidos: number;
  proximos: number;
  em_dia: number;
  inativos: number;
}

const cards = (p: KpiCardsProps) => [
  {
    label: 'Total de Equipamentos',
    value: p.total,
    icon: Wrench,
    color: 'oklch(0.55 0.15 240)',
    bg: 'oklch(0.55 0.15 240 / 0.12)',
    border: 'oklch(0.55 0.15 240 / 0.3)',
    glow: false,
  },
  {
    label: 'Manutenções Vencidas',
    value: p.vencidos,
    icon: AlertTriangle,
    color: '#EF4444',
    bg: 'oklch(0.62 0.22 25 / 0.15)',
    border: 'oklch(0.62 0.22 25 / 0.4)',
    glow: p.vencidos > 0,
    glowClass: 'glow-red',
  },
  {
    label: 'Próximas (30 dias)',
    value: p.proximos,
    icon: Clock,
    color: '#F59E0B',
    bg: 'oklch(0.72 0.18 60 / 0.15)',
    border: 'oklch(0.72 0.18 60 / 0.4)',
    glow: p.proximos > 0,
    glowClass: 'glow-amber',
  },
  {
    label: 'Em Dia',
    value: p.em_dia,
    icon: CheckCircle2,
    color: '#10B981',
    bg: 'oklch(0.62 0.18 155 / 0.12)',
    border: 'oklch(0.62 0.18 155 / 0.3)',
    glow: false,
  },
  {
    label: 'Inativos',
    value: p.inativos,
    icon: PowerOff,
    color: '#6B7280',
    bg: 'oklch(0.22 0.005 240 / 0.5)',
    border: 'oklch(0.3 0.005 240 / 0.4)',
    glow: false,
  },
];

export function KpiCards(props: KpiCardsProps) {
  const items = cards(props);
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
      {items.map((card, i) => {
        const Icon = card.icon;
        return (
          <motion.div
            key={card.label}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.06, duration: 0.3, ease: [0.23, 1, 0.32, 1] }}
            className={`rounded-lg p-4 flex flex-col gap-2 ${card.glow ? card.glowClass : ''}`}
            style={{ background: card.bg, border: `1px solid ${card.border}` }}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium uppercase tracking-wider" style={{ color: 'oklch(0.55 0.01 240)' }}>
                {card.label}
              </span>
              <Icon size={16} style={{ color: card.color }} />
            </div>
            <div className="font-mono text-3xl font-semibold leading-none" style={{ color: card.color }}>
              {card.value.toLocaleString('pt-PT')}
            </div>
          </motion.div>
        );
      })}
    </div>
  );
}
