import { useEffect, useState } from "react";
import { Download, Share2, X } from "lucide-react";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
}

function isIos() {
  return /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.userAgent.includes("Mac") && navigator.maxTouchPoints > 1);
}

export function InstallPwaButton() {
  const [promptEvent, setPromptEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [mostrarInstrucao, setMostrarInstrucao] = useState(false);
  const [instalada, setInstalada] = useState(false);

  useEffect(() => {
    const capturePrompt = (event: Event) => {
      event.preventDefault();
      setPromptEvent(event as BeforeInstallPromptEvent);
    };
    const installed = () => {
      setInstalada(true);
      setPromptEvent(null);
      setMostrarInstrucao(false);
    };
    window.addEventListener("beforeinstallprompt", capturePrompt);
    window.addEventListener("appinstalled", installed);
    return () => {
      window.removeEventListener("beforeinstallprompt", capturePrompt);
      window.removeEventListener("appinstalled", installed);
    };
  }, []);

  if (instalada || (!promptEvent && !isIos())) return null;

  const instalar = async () => {
    if (!promptEvent) {
      setMostrarInstrucao(true);
      return;
    }
    await promptEvent.prompt();
    const escolha = await promptEvent.userChoice;
    if (escolha.outcome === "accepted") setInstalada(true);
    setPromptEvent(null);
  };

  return (
    <div className="relative">
      <button
        onClick={() => void instalar()}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
        style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.4)', background: 'oklch(0.72 0.18 60 / 0.08)' }}
        title="Instalar aplicação"
      >
        <Download size={13} />
        Instalar
      </button>
      {mostrarInstrucao && (
        <div
          className="absolute right-0 top-full mt-2 w-64 rounded-lg p-3 z-30 shadow-xl"
          style={{ background: 'oklch(0.14 0.007 240)', border: '1px solid oklch(0.3 0.01 240)' }}
        >
          <button className="absolute top-2 right-2" onClick={() => setMostrarInstrucao(false)} aria-label="Fechar instruções">
            <X size={14} style={{ color: 'oklch(0.55 0.01 240)' }} />
          </button>
          <div className="flex gap-2 pr-4">
            <Share2 size={15} className="flex-shrink-0 mt-0.5" style={{ color: 'oklch(0.82 0.16 60)' }} />
            <p className="text-xs leading-relaxed" style={{ color: 'oklch(0.78 0.005 240)' }}>
              No Safari, toque em <strong>Partilhar</strong> e escolha <strong>"Adicionar ao ecrã principal"</strong>.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
