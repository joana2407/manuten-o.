import { useEffect, useState } from "react";
import { useLocation } from "wouter";

function temSessao() {
  try {
    return Boolean(sessionStorage.getItem("app_sessao") || sessionStorage.getItem("validador_sessao"));
  } catch {
    return false;
  }
}

export function AcessoGuard({ children }: { children: React.ReactNode }) {
  const [, setLocation] = useLocation();
  const [autorizado, setAutorizado] = useState(() => temSessao());

  useEffect(() => {
    if (!autorizado) setLocation("/acesso");
  }, [autorizado, setLocation]);

  if (!autorizado) return null;
  return <>{children}</>;
}
