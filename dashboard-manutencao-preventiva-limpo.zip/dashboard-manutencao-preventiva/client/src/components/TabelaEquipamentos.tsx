/*
 * TabelaEquipamentos — Tabela interativa com paginação e registo de realizações
 * Design: Industrial Dark Analytics
 * Funcionalidade: botão "Marcar como Realizado" + modal com histórico de intervenções e anexos
 */
import { useState, useMemo } from 'react';
import { useLocation } from 'wouter';
import { motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, ArrowUpDown, CheckCircle2, Edit2, Download, PlusCircle, PowerOff, Power, Settings2 } from 'lucide-react';
import type { Equipamento, EstadoPrazo } from '@/lib/types';
import { ESTADO_LABELS, ESTADO_BADGE_CLASS, formatDate } from '@/lib/utils';
import { ModalRealizacao } from './ModalRealizacao';
import { ModalNovoEquipamento } from './ModalNovoEquipamento';
import { ModalGestaoEquipamento } from './ModalGestaoEquipamento';
import { calcularProxima } from '@/hooks/useRealizacoes';
import { useRealizacoesContext } from '@/contexts/RealizacoesContext';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface TabelaEquipamentosProps {
  equipamentos: Equipamento[];
  todasAreas: string[];
  areasCustomFabrica?: Record<string, string>;
  overridesInativos: Set<string>; // chave: `${codigo}::${area}`
  onToggleInativo: (codigo: string, area: string, inativo: boolean) => void;
  onEquipamentoAdicionado: () => void;
  podeGerir?: boolean;
  nomeUtilizador?: string;
}

type SortKey = 'area' | 'codigo' | 'equipamento' | 'periodicidade' | 'proxima_manutencao' | 'estado_prazo' | 'dias_ate_vencimento';
type SortDir = 'asc' | 'desc';

const PAGE_SIZE = 20;
const ESTADO_ORDER: Record<EstadoPrazo, number> = { vencido: 0, proximo: 1, em_dia: 2, sem_periodicidade: 3, inativo: 4 };

export function TabelaEquipamentos({ equipamentos, todasAreas, areasCustomFabrica = {}, overridesInativos, onToggleInativo, onEquipamentoAdicionado, podeGerir = false, nomeUtilizador }: TabelaEquipamentosProps) {
  const [pagina, setPagina] = useState(1);
  const [sortKey, setSortKey] = useState<SortKey>('estado_prazo');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [modalEquipamento, setModalEquipamento] = useState<Equipamento | null>(null);
  const [modalNovoEquipamento, setModalNovoEquipamento] = useState(false);
  const [modalGestao, setModalGestao] = useState<Equipamento | null>(null);

  const {
    adicionarIntervencao,
    removerIntervencao,
    uploadAnexo,
    obterIntervencoesPorEquipamento,
    totalEquipamentosComRegisto,
    totalIntervencoes,
  } = useRealizacoesContext();

  // useUtils deve ser chamado no nível do componente, não dentro de callbacks
  const utils = trpc.useUtils();
  const [, setLocation] = useLocation();

  const navegarParaFicha = (e: Equipamento) => {
    const areaB64 = btoa(unescape(encodeURIComponent(e.area)));
    setLocation(`/equipamento/${encodeURIComponent(e.codigo)}/${areaB64}`, { state: { equipamento: e } });
  };

  // O dashboard já consolida intervenções, overrides e estados de prazo.
  // Não recalcular aqui: uma segunda fonte de verdade fazia a tabela divergir
  // dos alertas/KPIs (em particular em equipamentos da Fábrica I vencidos).
  const equipamentosComRealizacoes = equipamentos;

  const sorted = useMemo(() => {
    return [...equipamentosComRealizacoes].sort((a, b) => {
      let va: any = a[sortKey];
      let vb: any = b[sortKey];
      if (sortKey === 'estado_prazo') {
        va = ESTADO_ORDER[a.estado_prazo as EstadoPrazo] ?? 99;
        vb = ESTADO_ORDER[b.estado_prazo as EstadoPrazo] ?? 99;
      }
      if (va === null || va === undefined) va = sortDir === 'asc' ? Infinity : -Infinity;
      if (vb === null || vb === undefined) vb = sortDir === 'asc' ? Infinity : -Infinity;
      if (typeof va === 'string') va = va.toLowerCase();
      if (typeof vb === 'string') vb = vb.toLowerCase();
      if (va < vb) return sortDir === 'asc' ? -1 : 1;
      if (va > vb) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [equipamentosComRealizacoes, sortKey, sortDir]);

  const totalPaginas = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const paginaAtual = Math.min(pagina, totalPaginas);
  const inicio = (paginaAtual - 1) * PAGE_SIZE;
  const pagina_items = sorted.slice(inicio, inicio + PAGE_SIZE);

  const handleSort = (key: SortKey) => {
    if (key === sortKey) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
    setPagina(1);
  };

  const handleAdicionar = async (data: string, intervencao: string, materialGasto: string, responsavel: string): Promise<string> => {
    if (!modalEquipamento) return '';
    return adicionarIntervencao(modalEquipamento.codigo, modalEquipamento.area, data, intervencao, materialGasto, responsavel);
  };

  const handleRemoverIntervencao = async (id: string) => {
    await removerIntervencao(id);
  };

  const handleUploadAnexo = async (intervencaoId: string, file: File) => {
    return uploadAnexo(intervencaoId, file);
  };

  // Exportar para CSV com todas as intervenções
  const exportarCSV = () => {
    const linhas: string[][] = [
      ['Código', 'Equipamento', 'Área', 'Periodicidade', 'Data Realização', 'Próxima Manutenção', 'Estado', 'Intervenção realizada', 'Material gasto', 'Responsável'],
    ];
    equipamentosComRealizacoes.forEach(e => {
      const lista = obterIntervencoesPorEquipamento(e.codigo, e.area);
      if (lista.length > 0) {
        lista.forEach(i => {
          linhas.push([
            e.codigo, e.equipamento, e.area, e.periodicidade,
            i.dataRealizacao,
            calcularProxima(i.dataRealizacao, e.periodicidade_norm) ?? '',
            ESTADO_LABELS[e.estado_prazo],
            i.intervencaoRealizada ?? '',
            i.materialGasto ?? '',
            i.responsavel ?? '',
          ]);
        });
      } else {
        linhas.push([
          e.codigo, e.equipamento, e.area, e.periodicidade,
          '', e.proxima_manutencao ?? '',
          ESTADO_LABELS[e.estado_prazo], '', '', '',
        ]);
      }
    });
    const csv = linhas.map(l => l.map(c => `"${String(c).replace(/"/g, '""')}"`).join(',')).join('\n');
    const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `manutencao_realizacoes_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const SortIcon = ({ k }: { k: SortKey }) => (
    <ArrowUpDown size={12} style={{ opacity: sortKey === k ? 1 : 0.3, color: sortKey === k ? 'oklch(0.72 0.18 60)' : undefined }} />
  );

  const historicoModal = modalEquipamento
    ? obterIntervencoesPorEquipamento(modalEquipamento.codigo, modalEquipamento.area)
    : [];

  return (
    <>
      <div className="rounded-lg overflow-hidden" style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3" style={{ borderBottom: '1px solid oklch(0.22 0.008 240)' }}>
          <div className="flex items-center gap-3">
            <h3 className="text-sm font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>
              Lista de Equipamentos
            </h3>
            {totalEquipamentosComRegisto > 0 && (
              <span
                className="text-xs px-2 py-0.5 rounded-full font-mono"
                style={{ background: 'oklch(0.62 0.18 155 / 0.2)', color: '#10B981', border: '1px solid oklch(0.62 0.18 155 / 0.4)' }}
              >
                {totalIntervencoes} intervenç{totalIntervencoes !== 1 ? 'ões' : 'ão'} registada{totalIntervencoes !== 1 ? 's' : ''}
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setModalNovoEquipamento(true)}
              disabled={!podeGerir}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 disabled:opacity-30"
              style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.4)', background: 'oklch(0.72 0.18 60 / 0.08)' }}
              title="Adicionar novo equipamento"
            >
              <PlusCircle size={12} />
              Novo Equipamento
            </button>
            {totalEquipamentosComRegisto > 0 && (
              <button
                onClick={exportarCSV}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10"
                style={{ color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}
                title="Exportar lista com intervenções para CSV"
              >
                <Download size={12} />
                Exportar CSV
              </button>
            )}
            <span className="font-mono text-xs" style={{ color: 'oklch(0.52 0.01 240)' }}>
              {equipamentos.length} registos
            </span>
          </div>
        </div>

        <div className="lg:hidden p-3 space-y-2">
          {pagina_items.map((e, i) => {
            const listaIntervencoes = obterIntervencoesPorEquipamento(e.codigo, e.area);
            const temRegisto = listaIntervencoes.length > 0;
            return (
              <motion.div
                key={`mobile-${e.codigo}-${e.area}-${i}`}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.02 }}
                className="rounded-lg p-3"
                style={{
                  background: temRegisto ? 'oklch(0.62 0.18 155 / 0.05)' : 'oklch(0.1 0.006 240)',
                  border: '1px solid oklch(0.22 0.008 240)',
                }}
              >
                <div className="flex items-start justify-between gap-3">
                  <button onClick={() => navegarParaFicha(e)} className="min-w-0 text-left">
                    <span className="block font-mono text-xs font-semibold" style={{ color: 'oklch(0.82 0.16 60)' }}>{e.codigo}</span>
                    <span className="mt-0.5 block truncate text-sm font-semibold" style={{ color: 'oklch(0.9 0.005 240)' }}>{e.equipamento}</span>
                  </button>
                  <span className={`shrink-0 inline-block px-2 py-0.5 rounded-full text-xs font-medium ${ESTADO_BADGE_CLASS[e.estado_prazo]}`}>
                    {ESTADO_LABELS[e.estado_prazo]}
                  </span>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-xs" style={{ color: 'oklch(0.58 0.01 240)' }}>
                  <span className="col-span-2 truncate">{e.area}</span>
                  <span>{e.fabrica ?? '—'}</span>
                  <span>{e.periodicidade || '—'}</span>
                  <span style={{ color: e.estado_prazo === 'vencido' ? '#EF4444' : 'inherit' }}>Próx.: {formatDate(e.proxima_manutencao)}</span>
                  <span>{e.dias_ate_vencimento !== null ? `${e.dias_ate_vencimento < 0 ? '' : '+'}${e.dias_ate_vencimento} dias` : '—'}</span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  {e.estado !== 'inativo' && e.periodicidade_norm && (
                    <button
                      onClick={() => setModalEquipamento(e)}
                      className="flex flex-1 items-center justify-center gap-1 px-2.5 py-2 rounded text-xs font-medium active:scale-95"
                      style={{
                        background: temRegisto ? 'oklch(0.62 0.18 155 / 0.12)' : 'oklch(0.22 0.008 240)',
                        color: temRegisto ? '#10B981' : 'oklch(0.82 0.16 60)',
                        border: `1px solid ${temRegisto ? 'oklch(0.62 0.18 155 / 0.35)' : 'oklch(0.72 0.18 60 / 0.3)'}`,
                      }}
                    >
                      {temRegisto ? <><Edit2 size={11} /> {listaIntervencoes.length} registo(s)</> : <><CheckCircle2 size={11} /> Realizado</>}
                    </button>
                  )}
                  <button
                    onClick={() => setModalGestao(e)}
                    disabled={!podeGerir}
                    className="flex items-center justify-center px-2.5 py-2 rounded text-xs font-medium active:scale-95 disabled:opacity-30"
                    style={{ background: 'oklch(0.55 0.18 260 / 0.1)', color: 'oklch(0.72 0.15 260)', border: '1px solid oklch(0.55 0.18 260 / 0.3)' }}
                    title="Gerir equipamento"
                  >
                    <Settings2 size={14} />
                  </button>
                </div>
              </motion.div>
            );
          })}
          {pagina_items.length === 0 && (
            <p className="px-4 py-8 text-center text-sm" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Nenhum equipamento encontrado com os filtros selecionados.
            </p>
          )}
        </div>

        <div className="hidden lg:block overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr style={{ background: 'oklch(0.1 0.006 240)', borderBottom: '1px solid oklch(0.22 0.008 240)' }}>
                {([
                  ['codigo', 'Código'],
                  ['equipamento', 'Equipamento'],
                  ['area', 'Área'],
                  ['periodicidade', 'Periodicidade'],
                  ['proxima_manutencao', 'Próxima manutenção'],
                  ['dias_ate_vencimento', 'Dias'],
                  ['estado_prazo', 'Estado'],
                ] as [SortKey, string][]).map(([key, label]) => (
                  <th
                    key={key}
                    className="text-left px-3 py-2.5 font-medium cursor-pointer select-none hover:bg-white/5 transition-colors"
                    style={{ color: 'oklch(0.55 0.01 240)', whiteSpace: 'nowrap' }}
                    onClick={() => handleSort(key)}
                  >
                    <span className="flex items-center gap-1">{label} <SortIcon k={key} /></span>
                  </th>
                ))}
                <th className="px-3 py-2.5" style={{ color: 'oklch(0.55 0.01 240)', whiteSpace: 'nowrap' }}>
                  Fábrica
                </th>
                <th className="px-3 py-2.5 text-right" style={{ color: 'oklch(0.55 0.01 240)', whiteSpace: 'nowrap' }}>
                  Ação
                </th>
              </tr>
            </thead>
            <tbody>
              {pagina_items.map((e, i) => {
                const listaIntervencoes = obterIntervencoesPorEquipamento(e.codigo, e.area);
                const temRegisto = listaIntervencoes.length > 0;
                const numIntervencoes = listaIntervencoes.length;
                return (
                  <motion.tr
                    key={`${e.codigo}-${e.area}-${i}`}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.012 }}
                    className="hover:bg-white/[0.03] transition-colors"
                    style={{
                      borderBottom: '1px solid oklch(0.18 0.007 240)',
                      background: temRegisto ? 'oklch(0.62 0.18 155 / 0.04)' : undefined,
                    }}
                  >
                    <td className="px-3 py-2.5 font-mono" style={{ color: 'oklch(0.72 0.18 60)' }}>
                      <button
                        onClick={() => navegarParaFicha(e)}
                        className="hover:underline transition-all"
                        style={{ color: 'oklch(0.82 0.16 60)', cursor: 'pointer' }}
                        title="Ver ficha do equipamento"
                      >
                        {e.codigo}
                      </button>
                    </td>
                    <td className="px-3 py-2.5 max-w-[200px]" style={{ color: 'oklch(0.88 0.005 240)' }}>
                      <div className="flex items-center gap-1.5">
                        {temRegisto && <CheckCircle2 size={12} style={{ color: '#10B981', flexShrink: 0 }} />}
                        <div className="min-w-0">
                          <button
                            onClick={() => navegarParaFicha(e)}
                            className="block truncate text-left hover:underline transition-all"
                            style={{ color: 'oklch(0.88 0.005 240)', cursor: 'pointer' }}
                            title={`Ver ficha: ${e.equipamento}`}
                          >
                            {e.equipamento}
                          </button>
                          {(e.modelo || e.numeroSerie) && (
                            <span className="block truncate text-xs" style={{ color: 'oklch(0.48 0.01 240)', fontSize: '10px' }}>
                              {[e.modelo, e.numeroSerie ? `S/N: ${e.numeroSerie}` : null].filter(Boolean).join(' · ')}
                            </span>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 max-w-[140px]" style={{ color: 'oklch(0.65 0.01 240)' }}>
                      <span className="block truncate" title={e.area}>{e.area}</span>
                    </td>
                    <td className="px-3 py-2.5" style={{ color: 'oklch(0.65 0.01 240)' }}>{e.periodicidade || '—'}</td>
                    <td className="px-3 py-2.5 font-mono whitespace-nowrap" style={{ color: e.estado_prazo === 'vencido' ? '#EF4444' : temRegisto ? '#10B981' : 'oklch(0.65 0.01 240)' }}>
                      {formatDate(e.proxima_manutencao)}
                    </td>
                    <td className="px-3 py-2.5 font-mono text-right" style={{ color: e.dias_ate_vencimento !== null && e.dias_ate_vencimento < 0 ? '#EF4444' : e.dias_ate_vencimento !== null && e.dias_ate_vencimento <= 30 ? '#F59E0B' : 'oklch(0.55 0.01 240)' }}>
                      {e.dias_ate_vencimento !== null ? (e.dias_ate_vencimento < 0 ? `${e.dias_ate_vencimento}` : `+${e.dias_ate_vencimento}`) : '—'}
                    </td>
                    <td className="px-3 py-2.5">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${ESTADO_BADGE_CLASS[e.estado_prazo]}`}>
                        {ESTADO_LABELS[e.estado_prazo]}
                      </span>
                    </td>
                    <td className="px-3 py-2.5 whitespace-nowrap" style={{ color: 'oklch(0.52 0.01 240)', fontSize: '11px' }}>
                      {e.fabrica ?? '—'}
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {e.estado !== 'inativo' && e.periodicidade_norm && (
                          <button
                            onClick={() => setModalEquipamento(e)}
                            className="flex items-center gap-1 px-2.5 py-1 rounded text-xs font-medium transition-all active:scale-95 whitespace-nowrap"
                            style={temRegisto ? {
                              background: 'oklch(0.62 0.18 155 / 0.12)',
                              color: '#10B981',
                              border: '1px solid oklch(0.62 0.18 155 / 0.35)',
                            } : {
                              background: 'oklch(0.22 0.008 240)',
                              color: 'oklch(0.72 0.18 60)',
                              border: '1px solid oklch(0.72 0.18 60 / 0.3)',
                            }}
                            title={temRegisto ? `${numIntervencoes} intervenção(ões) registada(s) — clique para ver/adicionar` : 'Marcar como realizado'}
                          >
                            {temRegisto ? (
                              <><Edit2 size={11} /> {numIntervencoes} registo{numIntervencoes !== 1 ? 's' : ''}</>
                            ) : (
                              <><CheckCircle2 size={11} /> Realizado</>
                            )}
                          </button>
                        )}
                        {/* Botão de gestão protegida — para TODOS os equipamentos */}
                        <button
                          onClick={() => setModalGestao(e)}
                          disabled={!podeGerir}
                          className="flex items-center gap-1 px-2 py-1 rounded text-xs font-medium transition-all active:scale-95 whitespace-nowrap disabled:opacity-30"
                          style={{
                            background: 'oklch(0.55 0.18 260 / 0.1)',
                            color: 'oklch(0.72 0.15 260)',
                            border: '1px solid oklch(0.55 0.18 260 / 0.3)',
                          }}
                          title="Gerir equipamento (editar/eliminar/inativar)"
                        >
                          <Settings2 size={11} />
                        </button>
                      </div>
                    </td>
                  </motion.tr>
                );
              })}
              {pagina_items.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-sm" style={{ color: 'oklch(0.45 0.01 240)' }}>
                    Nenhum equipamento encontrado com os filtros selecionados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* Paginação */}
        {totalPaginas > 1 && (
          <div className="flex items-center justify-between px-4 py-3" style={{ borderTop: '1px solid oklch(0.22 0.008 240)' }}>
            <span className="text-xs font-mono" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Pág. {paginaAtual} / {totalPaginas}
            </span>
            <div className="flex gap-1">
              <button
                onClick={() => setPagina(p => Math.max(1, p - 1))}
                disabled={paginaAtual === 1}
                className="p-1.5 rounded transition-colors hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed"
                style={{ color: 'oklch(0.65 0.01 240)' }}
              >
                <ChevronLeft size={14} />
              </button>
              {Array.from({ length: Math.min(7, totalPaginas) }, (_, i) => {
                const p = totalPaginas <= 7 ? i + 1 : paginaAtual <= 4 ? i + 1 : paginaAtual >= totalPaginas - 3 ? totalPaginas - 6 + i : paginaAtual - 3 + i;
                return (
                  <button
                    key={p}
                    onClick={() => setPagina(p)}
                    className="w-7 h-7 rounded text-xs font-mono transition-colors"
                    style={{
                      background: p === paginaAtual ? 'oklch(0.72 0.18 60 / 0.2)' : 'transparent',
                      color: p === paginaAtual ? 'oklch(0.82 0.16 60)' : 'oklch(0.55 0.01 240)',
                      border: p === paginaAtual ? '1px solid oklch(0.72 0.18 60 / 0.4)' : '1px solid transparent',
                    }}
                  >
                    {p}
                  </button>
                );
              })}
              <button
                onClick={() => setPagina(p => Math.min(totalPaginas, p + 1))}
                disabled={paginaAtual === totalPaginas}
                className="p-1.5 rounded transition-colors hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed"
                style={{ color: 'oklch(0.65 0.01 240)' }}
              >
                <ChevronRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal de novo equipamento */}
      {modalNovoEquipamento && (
        <ModalNovoEquipamento
          areas={todasAreas}
          areasCustomFabrica={areasCustomFabrica}
          onFechar={() => setModalNovoEquipamento(false)}
          onCriado={() => {
            setModalNovoEquipamento(false);
            // Invalidar intervenções para refletir imediatamente o registo inicial
            utils.intervencoes.listarTodas.invalidate();
            onEquipamentoAdicionado();
          }}
        />
      )}

      {/* Modal de gestão protegida (todos os equipamentos) */}
      {modalGestao && (
        <ModalGestaoEquipamento
          equipamento={modalGestao}
          todasAreas={todasAreas}
          areasCustomFabrica={areasCustomFabrica}
          nomeUtilizador={nomeUtilizador}
          onFechar={() => setModalGestao(null)}
          onAlterado={() => {
            setModalGestao(null);
            onEquipamentoAdicionado();
          }}
        />
      )}

      {/* Modal de registo e histórico */}
      <ModalRealizacao
        equipamento={modalEquipamento}
        historico={historicoModal}
        onAdicionar={handleAdicionar}
        onRemoverIntervencao={handleRemoverIntervencao}
        onUploadAnexo={handleUploadAnexo}
        onFechar={() => setModalEquipamento(null)}
      />
    </>
  );
}
