/*
 * GraficosPorArea — Gráfico de barras horizontais empilhadas por área
 * Design: Industrial Dark Analytics
 */
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import type { ResumoArea } from '@/lib/types';
import { ESTADO_COLORS } from '@/lib/utils';

interface GraficosPorAreaProps {
  porArea: ResumoArea[];
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg p-3 text-xs" style={{ background: 'oklch(0.13 0.007 240)', border: '1px solid oklch(0.25 0.008 240)', minWidth: 180 }}>
      <p className="font-semibold mb-2" style={{ color: 'oklch(0.88 0.005 240)' }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center justify-between gap-4 py-0.5">
          <span className="flex items-center gap-1.5" style={{ color: 'oklch(0.65 0.01 240)' }}>
            <span className="w-2 h-2 rounded-full inline-block" style={{ background: p.fill }} />
            {p.name}
          </span>
          <span className="font-mono font-semibold" style={{ color: p.fill }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export function GraficosPorArea({ porArea }: GraficosPorAreaProps) {
  // Ordenar por vencidos desc
  const data = [...porArea].sort((a, b) => b.vencidos - a.vencidos);

  return (
    <div className="rounded-lg p-4" style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
      <h3 className="text-sm font-semibold mb-4 uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>
        Estado por Área
      </h3>
      <ResponsiveContainer width="100%" height={340}>
        <BarChart data={data} layout="vertical" margin={{ top: 0, right: 16, left: 8, bottom: 0 }} barSize={10}>
          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.008 240)" horizontal={false} />
          <XAxis type="number" tick={{ fill: 'oklch(0.52 0.01 240)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
          <YAxis type="category" dataKey="area" tick={{ fill: 'oklch(0.65 0.01 240)', fontSize: 10 }} axisLine={false} tickLine={false} width={140} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'oklch(0.18 0.007 240)' }} />
          <Legend wrapperStyle={{ fontSize: 11, color: 'oklch(0.65 0.01 240)' }} />
          <Bar dataKey="vencidos" name="Vencido" fill={ESTADO_COLORS.vencido} radius={[0, 2, 2, 0]} />
          <Bar dataKey="proximos" name="Próximo" fill={ESTADO_COLORS.proximo} radius={[0, 2, 2, 0]} />
          <Bar dataKey="em_dia" name="Em dia" fill={ESTADO_COLORS.em_dia} radius={[0, 2, 2, 0]} />
          <Bar dataKey="inativos" name="Inativo" fill={ESTADO_COLORS.inativo} radius={[0, 2, 2, 0]} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
