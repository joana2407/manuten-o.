import { ClipboardCheck, Wrench } from 'lucide-react';
import { useLocation } from 'wouter';

export function PainelSelector({ compacto = false }: { compacto?: boolean }) {
  const [location, setLocation] = useLocation();
  const corretivaAtiva = location.startsWith('/corretiva');

  return (
    <nav
      aria-label="Seleção de painel"
      className={`painel-selector flex items-center gap-1 rounded-lg p-1 ${compacto ? 'text-xs' : ''}`}
      style={{ background: 'oklch(0.08 0.005 240)', border: '1px solid oklch(0.22 0.008 240)' }}
    >
      <button
        onClick={() => setLocation('/')}
        aria-current={!corretivaAtiva ? 'page' : undefined}
        className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 font-semibold transition-all active:scale-95"
        style={{
          background: !corretivaAtiva ? 'oklch(0.72 0.18 60 / 0.16)' : 'transparent',
          color: !corretivaAtiva ? 'oklch(0.82 0.16 60)' : 'oklch(0.55 0.01 240)',
          border: `1px solid ${!corretivaAtiva ? 'oklch(0.72 0.18 60 / 0.35)' : 'transparent'}`,
        }}
      >
        <ClipboardCheck size={13} />
        Preventiva
      </button>
      <button
        onClick={() => setLocation('/corretiva')}
        aria-current={corretivaAtiva ? 'page' : undefined}
        className="flex items-center gap-1.5 rounded-md px-2.5 py-1.5 font-semibold transition-all active:scale-95"
        style={{
          background: corretivaAtiva ? 'oklch(0.55 0.18 260 / 0.18)' : 'transparent',
          color: corretivaAtiva ? 'oklch(0.75 0.15 260)' : 'oklch(0.55 0.01 240)',
          border: `1px solid ${corretivaAtiva ? 'oklch(0.55 0.18 260 / 0.45)' : 'transparent'}`,
        }}
      >
        <Wrench size={13} />
        Corretiva
      </button>
    </nav>
  );
}
