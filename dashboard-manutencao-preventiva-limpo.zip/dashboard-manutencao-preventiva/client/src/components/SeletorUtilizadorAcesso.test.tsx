/** @vitest-environment jsdom */
import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ useQuery: vi.fn() }));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    intervencoes: {
      listarValidadores: { useQuery: mocks.useQuery },
    },
  },
}));

import { SeletorUtilizadorAcesso } from "./SeletorUtilizadorAcesso";

afterEach(() => cleanup());

const utilizadores = [
  { id: "tecnico", nome: "Alfredo Silva", nomeUtilizador: "alfredo.silva", funcao: "Téc. Manutenção", podeGerir: false, podeGerirPins: false, podeGerirUtilizadores: false, podeValidar: false },
  { id: "qualidade", nome: "Joana Pina", nomeUtilizador: "joana.pina", funcao: "Resp. Qualidade", podeGerir: false, podeGerirPins: true, podeGerirUtilizadores: true, podeValidar: true },
  { id: "gestao", nome: "Gestão", nomeUtilizador: "gestao", funcao: "Gestão", podeGerir: true, podeGerirPins: true, podeGerirUtilizadores: true, podeValidar: true },
];

describe("SeletorUtilizadorAcesso", () => {
  it("permite escolher visualmente um utilizador e devolve a sua identificação", async () => {
    mocks.useQuery.mockReturnValue({ data: utilizadores, isLoading: false, isError: false, refetch: vi.fn() });
    const onChange = vi.fn();
    render(<SeletorUtilizadorAcesso value="" onChange={onChange} />);

    await userEvent.click(screen.getByRole("option", { name: /Joana Pina/i }));
    expect(onChange).toHaveBeenCalledWith("joana.pina", "Joana Pina");
  });

  it("mostra apenas o perfil Gestão e todos os perfis ativos na validação", () => {
    mocks.useQuery.mockReturnValue({ data: utilizadores, isLoading: false, isError: false, refetch: vi.fn() });
    const { rerender } = render(<SeletorUtilizadorAcesso value="" onChange={vi.fn()} apenasGestao />);

    expect(screen.getByRole("option", { name: /Gestão/i })).toBeTruthy();
    expect(screen.queryByRole("option", { name: /Alfredo Silva/i })).toBeNull();

    rerender(<SeletorUtilizadorAcesso value="" onChange={vi.fn()} apenasValidacao />);
    expect(screen.getByRole("option", { name: /Joana Pina/i })).toBeTruthy();
    expect(screen.getByRole("option", { name: /Alfredo Silva/i })).toBeTruthy();
    expect(screen.getByRole("option", { name: /Gestão/i })).toBeTruthy();
  });
});
