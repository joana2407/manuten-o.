/*
 * ModalCodigoAcesso — Prompt simples de código de acesso para operações sensíveis
 * Usado para inativar/reativar equipamentos do JSON base
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Shield, Eye, EyeOff, AlertTriangle, Loader2 } from 'lucide-react';

interface ModalCodigoAcessoProps {
  titulo: string;
  descricao: string;
  acaoBotao: string;
  corBotao?: string;
  carregando?: boolean;
  onConfirmar: (codigo: string) => void;
  onFechar: () => void;
  erroExterno?: string;
}

export function ModalCodigoAcesso({
  titulo,
  descricao,
  acaoBotao,
  corBotao = 'oklch(0.72 0.18 60)',
  carregando = false,
  onConfirmar,
  onFechar,
  erroExterno,
}: ModalCodigoAcessoProps) {
  const [codigo, setCodigo] = useState('');
  const [mostrar, setMostrar] = useState(false);
  const [erro, setErro] = useState('');

  const handleConfirmar = () => {
    if (!codigo.trim()) {
      setErro('Introduza o código de acesso.');
      return;
    }
    setErro('');
    onConfirmar(codigo);
  };

  const erroAtual = erroExterno || erro;

  const inputStyle = {
    background: 'oklch(0.14 0.006 240)',
    border: `1px solid ${erroAtual ? 'oklch(0.62 0.22 25 / 0.7)' : 'oklch(0.28 0.008 240)'}`,
    color: 'oklch(0.92 0.005 240)',
    borderRadius: '6px',
    padding: '8px 36px 8px 12px',
    fontSize: '13px',
    width: '100%',
    outline: 'none',
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-[60] flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.75)' }}
        onClick={(e) => e.target === e.currentTarget && onFechar()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
          className="w-full max-w-sm mx-4 rounded-xl overflow-hidden"
          style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: '1px solid oklch(0.18 0.006 240)' }}
          >
            <div className="flex items-center gap-2">
              <Shield size={15} style={{ color: 'oklch(0.72 0.18 60)' }} />
              <h2 className="font-semibold text-sm" style={{ color: 'oklch(0.92 0.005 240)' }}>
                {titulo}
              </h2>
            </div>
            <button
              onClick={onFechar}
              className="p-1 rounded hover:bg-white/10 transition-colors"
              style={{ color: 'oklch(0.55 0.01 240)' }}
            >
              <X size={15} />
            </button>
          </div>

          {/* Body */}
          <div className="p-5 flex flex-col gap-4">
            <p className="text-xs" style={{ color: 'oklch(0.58 0.01 240)' }}>{descricao}</p>

            <div>
              <label
                className="block text-xs font-semibold uppercase tracking-wider mb-1.5"
                style={{ color: 'oklch(0.52 0.01 240)' }}
              >
                Código de Acesso
              </label>
              <div className="relative">
                <input
                  type={mostrar ? 'text' : 'password'}
                  value={codigo}
                  onChange={(e) => { setCodigo(e.target.value); setErro(''); }}
                  onKeyDown={(e) => e.key === 'Enter' && handleConfirmar()}
                  placeholder="••••••••"
                  style={inputStyle}
                  autoFocus
                />
                <button
                  type="button"
                  onClick={() => setMostrar(v => !v)}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2"
                  style={{ color: 'oklch(0.45 0.01 240)' }}
                >
                  {mostrar ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
              {erroAtual && (
                <p className="text-xs mt-1.5 flex items-center gap-1" style={{ color: '#EF4444' }}>
                  <AlertTriangle size={11} /> {erroAtual}
                </p>
              )}
            </div>

            <div className="flex gap-3">
              <button
                type="button"
                onClick={onFechar}
                className="flex-1 py-2 rounded-lg text-sm font-medium"
                style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={handleConfirmar}
                disabled={!codigo.trim() || carregando}
                className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all"
                style={{
                  background: codigo.trim() && !carregando ? corBotao : 'oklch(0.3 0.01 240)',
                  color: codigo.trim() && !carregando ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)',
                }}
              >
                {carregando ? <Loader2 size={14} className="animate-spin" /> : null}
                {acaoBotao}
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
