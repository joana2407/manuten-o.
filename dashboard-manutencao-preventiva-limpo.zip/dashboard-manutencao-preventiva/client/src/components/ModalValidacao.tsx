/**
 * ModalValidacao — Modal para validar/libertar uma intervenção de manutenção
 * Protegido por PIN individual de um perfil autorizado
 * Design: Industrial Dark Analytics
 */
import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  X, ShieldCheck, KeyRound, CheckCircle2, AlertTriangle, Loader2, User,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';
import { formatDate } from '@/lib/utils';
import { SeletorUtilizadorAcesso } from '@/components/SeletorUtilizadorAcesso';

interface ModalValidacaoProps {
  intervencao: IntervencaoDb & { nomeEquipamento?: string };
  onValidada: () => void;
  onFechar: () => void;
}

export function ModalValidacao({ intervencao, onValidada, onFechar }: ModalValidacaoProps) {
  const [nomeUtilizador, setNomeUtilizador] = useState('');
  const [codigoAcesso, setCodigoAcesso] = useState('');
  const [validadoPor, setValidadoPor] = useState('');
  const [erro, setErro] = useState('');
  const [sucesso, setSucesso] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  const utils = trpc.useUtils();
  const validarMutation = trpc.intervencoes.validar.useMutation({
    onSuccess: () => {
      setSucesso(true);
      utils.intervencoes.listarTodas.invalidate();
      utils.intervencoes.listarPorValidar.invalidate();
      setTimeout(() => {
        onValidada();
        onFechar();
      }, 1200);
    },
    onError: (err) => {
      setErro(err.message ?? 'Erro ao validar. Tente novamente.');
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErro('');
    if (!nomeUtilizador.trim()) {
      setErro('Selecione o responsável pela validação.');
      return;
    }
    if (!codigoAcesso.trim()) {
      setErro('Introduza o PIN do responsável.');
      return;
    }
    validarMutation.mutate({
      id: intervencao.id,
      validadoPor: validadoPor.trim(),
      nomeUtilizador: nomeUtilizador.trim(),
      codigoAcesso,
    });
  };

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-50 flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{ background: 'oklch(0 0 0 / 0.7)' }}
        onClick={(e) => { if (e.target === e.currentTarget) onFechar(); }}
      >
        <motion.div
          className="w-full max-w-md rounded-xl overflow-hidden"
          initial={{ scale: 0.95, opacity: 0, y: 8 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 8 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          style={{ background: cardBg, border: `1px solid ${borderColor}` }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: `1px solid oklch(0.18 0.006 240)` }}
          >
            <div className="flex items-center gap-2">
              <div
                className="w-7 h-7 rounded flex items-center justify-center"
                style={{ background: '#22C55E22', border: '1px solid #22C55E44' }}
              >
                <ShieldCheck size={14} style={{ color: '#22C55E' }} />
              </div>
              <h2 className="text-sm font-semibold" style={{ color: 'oklch(0.92 0.005 240)' }}>
                Validar / Libertar Manutenção
              </h2>
            </div>
            <button
              onClick={onFechar}
              className="p-1.5 rounded transition-all hover:opacity-70 active:scale-95"
              style={{ color: 'oklch(0.45 0.01 240)' }}
            >
              <X size={15} />
            </button>
          </div>

          {/* Resumo da intervenção */}
          <div
            className="mx-5 mt-4 p-3 rounded-lg"
            style={{ background: 'oklch(0.12 0.006 240)', border: `1px solid oklch(0.2 0.008 240)` }}
          >
            <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
              Intervenção a Validar
            </p>
            <p className="text-sm font-semibold" style={{ color: 'oklch(0.88 0.005 240)' }}>
              {intervencao.nomeEquipamento ?? intervencao.codigoEquipamento}
            </p>
            <p className="text-xs mt-0.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
              {intervencao.codigoEquipamento} · {intervencao.area}
            </p>
            <p className="text-xs mt-1" style={{ color: 'oklch(0.55 0.01 240)' }}>
              Realizada em: <span style={{ color: 'oklch(0.78 0.005 240)' }}>{formatDate(intervencao.dataRealizacao)}</span>
              {intervencao.responsavel && (
                <> · Técnico: <span style={{ color: 'oklch(0.78 0.005 240)' }}>{intervencao.responsavel}</span></>
              )}
            </p>
            {intervencao.intervencaoRealizada && (
              <p className="text-xs mt-1 line-clamp-2" style={{ color: 'oklch(0.62 0.005 240)' }}>
                {intervencao.intervencaoRealizada}
              </p>
            )}
          </div>

          {/* Formulário */}
          <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-4">
            <SeletorUtilizadorAcesso
              value={nomeUtilizador}
              onChange={(utilizador, nome) => { setNomeUtilizador(utilizador); setValidadoPor(nome); setErro(''); }}
              apenasValidacao
              disabled={validarMutation.isPending}
            />
            {validadoPor && (
              <p className="text-xs" style={{ color: '#22C55E' }}>
                Responsável pela validação: <strong>{validadoPor}</strong>
              </p>
            )}

            {/* Código de acesso */}
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider flex items-center gap-1.5" style={{ color: 'oklch(0.48 0.01 240)' }}>
                <KeyRound size={11} />
                PIN do responsável
              </label>
              <input
                ref={inputRef}
                type="password"
                value={codigoAcesso}
                onChange={e => { setCodigoAcesso(e.target.value); setErro(''); }}
                placeholder="••••••••"
                autoComplete="off"
                className="w-full px-3 py-2 rounded-lg text-sm outline-none transition-all font-mono tracking-widest"
                style={{
                  background: 'oklch(0.12 0.006 240)',
                  border: `1px solid ${erro ? 'oklch(0.62 0.22 25 / 0.7)' : 'oklch(0.25 0.008 240)'}`,
                  color: 'oklch(0.88 0.005 240)',
                }}
                onFocus={e => (e.target.style.borderColor = '#22C55E88')}
                onBlur={e => (e.target.style.borderColor = erro ? 'oklch(0.62 0.22 25 / 0.7)' : 'oklch(0.25 0.008 240)')}
              />
              <p className="text-xs" style={{ color: 'oklch(0.42 0.01 240)' }}>
                Apenas Joana Pina (Qualidade) ou Gestão podem libertar intervenções. Introduza o PIN individual do responsável.
              </p>
            </div>

            {/* Erro */}
            <AnimatePresence>
              {erro && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg"
                  style={{ background: 'oklch(0.62 0.22 25 / 0.1)', border: '1px solid oklch(0.62 0.22 25 / 0.3)' }}
                >
                  <AlertTriangle size={13} style={{ color: '#EF4444' }} />
                  <p className="text-xs" style={{ color: '#EF4444' }}>{erro}</p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Sucesso */}
            <AnimatePresence>
              {sucesso && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg"
                  style={{ background: '#22C55E11', border: '1px solid #22C55E44' }}
                >
                  <CheckCircle2 size={13} style={{ color: '#22C55E' }} />
                  <p className="text-xs font-semibold" style={{ color: '#22C55E' }}>
                    Manutenção validada com sucesso!
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Botões */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={onFechar}
                className="flex-1 py-2 rounded-lg text-sm font-medium transition-all active:scale-95"
                style={{
                  background: 'oklch(0.15 0.006 240)',
                  color: 'oklch(0.65 0.01 240)',
                  border: '1px solid oklch(0.25 0.008 240)',
                }}
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={validarMutation.isPending || sucesso}
                className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 disabled:opacity-50"
                style={{ background: '#22C55E', color: '#0a1a0a' }}
              >
                {validarMutation.isPending
                  ? <><Loader2 size={14} className="animate-spin" /> A validar...</>
                  : <><ShieldCheck size={14} /> Confirmar Validação</>
                }
              </button>
            </div>
          </form>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
