import React, { useState } from "react";
import { Check, UserRound } from "lucide-react";
import { listarUtilizadoresLocais } from "@/lib/localAccess";

type SeletorUtilizadorAcessoProps = {
  value: string;
  onChange: (nomeUtilizador: string, nome: string) => void;
  apenasGestao?: boolean;
  apenasGestaoPins?: boolean;
  apenasValidacao?: boolean;
  disabled?: boolean;
};

type UtilizadorAcesso = {
  nomeUtilizador: string | null;
  podeGerir: boolean;
  podeGerirPins: boolean;
  podeGerirUtilizadores: boolean;
  podeValidar: boolean;
};

export function filtrarUtilizadoresAcesso<T extends UtilizadorAcesso>(utilizadores: T[], apenasGestao: boolean, apenasValidacao: boolean, apenasGestaoPins = false) {
  return utilizadores.filter(utilizador => {
    if (!utilizador.nomeUtilizador) return false;
    if (apenasGestao) return utilizador.podeGerir;
    if (apenasGestaoPins) return utilizador.podeGerirUtilizadores;
    if (apenasValidacao) return true;
    return true;
  });
}

export function SeletorUtilizadorAcesso({ value, onChange, apenasGestao = false, apenasGestaoPins = false, apenasValidacao = false, disabled = false }: SeletorUtilizadorAcessoProps) {
  const [utilizadores] = useState(() => listarUtilizadoresLocais({ apenasAtivos: true }));
  const visiveis = filtrarUtilizadoresAcesso(utilizadores, apenasGestao, apenasValidacao, apenasGestaoPins);

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between gap-3">
        <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.52 0.01 240)" }}>
          Selecione o utilizador
        </label>
        {value && <span className="text-xs" style={{ color: "#22C55E" }}>Selecionado</span>}
      </div>
      {visiveis.length === 0 ? (
        <div className="flex flex-col items-center gap-2 rounded-lg px-3 py-4 text-center text-xs" style={{ background: "oklch(0.085 0.005 240)", color: "oklch(0.54 0.01 240)", border: "1px solid oklch(0.22 0.008 240)" }}>
          <UserRound size={16} />
          <span>{apenasGestao ? "Não existe um perfil de Gestão ativo." : apenasGestaoPins ? "Não existe um utilizador autorizado a gerir PINs." : apenasValidacao ? "Não existe um utilizador com permissão de validação." : "Não existem utilizadores ativos para acesso."}</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-2 sm:grid-cols-2" role="listbox" aria-label="Utilizadores disponíveis">
          {visiveis.map(utilizador => {
            const selecionado = value === utilizador.nomeUtilizador;
            return (
              <button
                key={utilizador.id}
                type="button"
                role="option"
                aria-selected={selecionado}
                disabled={disabled}
                onClick={() => onChange(utilizador.nomeUtilizador ?? "", utilizador.nome)}
                className="flex min-h-14 items-center gap-3 rounded-xl px-3 py-2 text-left transition-all active:scale-[0.98] disabled:opacity-50"
                style={{
                  background: selecionado ? "#22C55E18" : "oklch(0.085 0.005 240)",
                  border: `1px solid ${selecionado ? "#22C55E" : "oklch(0.22 0.008 240)"}`,
                  color: "oklch(0.9 0.005 240)",
                }}
              >
                <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg text-xs font-bold" style={{ background: selecionado ? "#22C55E" : "oklch(0.15 0.006 240)", color: selecionado ? "#071407" : "oklch(0.72 0.18 60)" }}>
                  {selecionado ? <Check size={15} /> : <UserRound size={15} />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-sm font-semibold">{utilizador.nome}</span>
                  <span className="block truncate text-xs" style={{ color: selecionado ? "#bbf7d0" : "oklch(0.52 0.01 240)" }}>{utilizador.funcao}</span>
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
