import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, Loader2, Pencil, X } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';

interface ModalEditarIntervencaoProps {
  intervencao: IntervencaoDb | null;
  onGuardada: () => void;
  onFechar: () => void;
}

export function ModalEditarIntervencao({ intervencao, onGuardada, onFechar }: ModalEditarIntervencaoProps) {
  const [intervencaoRealizada, setIntervencaoRealizada] = useState('');
  const [materialGasto, setMaterialGasto] = useState('');
  const [responsavelValidacao, setResponsavelValidacao] = useState('');
  const [validadoPor, setValidadoPor] = useState('');
  const [erro, setErro] = useState('');

  useEffect(() => {
    if (!intervencao) return;
    setIntervencaoRealizada(intervencao.intervencaoRealizada ?? '');
    setMaterialGasto(intervencao.materialGasto ?? '');
    setResponsavelValidacao(intervencao.responsavelValidacao ?? '');
    setValidadoPor(intervencao.validadoPor ?? '');
    setErro('');
  }, [intervencao]);

  const editarMutation = trpc.intervencoes.editar.useMutation({
    onSuccess: () => {
      onGuardada();
      onFechar();
    },
    onError: (error) => setErro(error.message || 'Não foi possível guardar a alteração.'),
  });

  if (!intervencao) return null;

  const guardar = (event: React.FormEvent) => {
    event.preventDefault();
    setErro('');
    editarMutation.mutate({
      id: intervencao.id,
      intervencaoRealizada,
      materialGasto,
      responsavelValidacao,
      validadoPor,
    });
  };

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[60] flex items-center justify-center p-4"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        style={{ background: 'oklch(0 0 0 / 0.72)' }}
        onClick={event => { if (event.target === event.currentTarget) onFechar(); }}
      >
        <motion.form
          onSubmit={guardar}
          className="w-full max-w-lg rounded-xl overflow-hidden"
          initial={{ scale: 0.95, opacity: 0, y: 8 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 8 }}
          style={{ background: 'oklch(0.13 0.007 240)', border: '1px solid oklch(0.28 0.01 240)' }}
        >
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid oklch(0.22 0.008 240)' }}>
            <div className="flex items-center gap-2">
              <Pencil size={16} style={{ color: 'oklch(0.72 0.18 60)' }} />
              <h2 className="text-sm font-semibold" style={{ color: 'oklch(0.92 0.005 240)' }}>Editar intervenção</h2>
            </div>
            <button type="button" onClick={onFechar} className="p-1.5 rounded hover:bg-white/10" style={{ color: 'oklch(0.55 0.01 240)' }}>
              <X size={16} />
            </button>
          </div>

          <div className="p-5 flex flex-col gap-4">
            <p className="text-xs" style={{ color: 'oklch(0.55 0.01 240)' }}>
              {intervencao.dataRealizacao} · {intervencao.responsavel || 'Técnico não indicado'}
            </p>

            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>Intervenção realizada</span>
              <textarea value={intervencaoRealizada} onChange={event => setIntervencaoRealizada(event.target.value)} rows={4} className="w-full rounded-lg px-3 py-2 text-sm outline-none resize-y" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.28 0.01 240)', color: 'oklch(0.88 0.005 240)' }} />
            </label>

            <label className="flex flex-col gap-1.5">
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>Material gasto</span>
              <textarea value={materialGasto} onChange={event => setMaterialGasto(event.target.value)} rows={3} className="w-full rounded-lg px-3 py-2 text-sm outline-none resize-y" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.28 0.01 240)', color: 'oklch(0.88 0.005 240)' }} />
            </label>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex flex-col gap-1.5">
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>Resp. validação/libertação</span>
                <input value={responsavelValidacao} onChange={event => setResponsavelValidacao(event.target.value)} className="w-full rounded-lg px-3 py-2 text-sm outline-none" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.28 0.01 240)', color: 'oklch(0.88 0.005 240)' }} />
              </label>
              <label className="flex flex-col gap-1.5">
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>Validado por</span>
                <input value={validadoPor} onChange={event => setValidadoPor(event.target.value)} className="w-full rounded-lg px-3 py-2 text-sm outline-none" style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.28 0.01 240)', color: 'oklch(0.88 0.005 240)' }} />
              </label>
            </div>
            {intervencao.validadoPor && !validadoPor.trim() && <p className="text-xs" style={{ color: '#F59E0B' }}>Ao limpar “Validado por”, a intervenção voltará ao estado “Por validar”.</p>}
            {erro && <p className="text-xs" style={{ color: '#EF4444' }}>{erro}</p>}

            <div className="flex justify-end gap-2 pt-1">
              <button type="button" onClick={onFechar} disabled={editarMutation.isPending} className="px-4 py-2 rounded-lg text-xs font-medium hover:bg-white/10 disabled:opacity-50" style={{ color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>Cancelar</button>
              <button type="submit" disabled={editarMutation.isPending} className="flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold disabled:opacity-60" style={{ background: '#22C55E', color: '#071407' }}>
                {editarMutation.isPending ? <Loader2 size={13} className="animate-spin" /> : <CheckCircle2 size={13} />}
                Guardar alterações
              </button>
            </div>
          </div>
        </motion.form>
      </motion.div>
    </AnimatePresence>
  );
}
