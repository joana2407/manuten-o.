/*
 * Sidebar — Filtros do dashboard com colapso e contagem de equipamentos por área
 * Design: Industrial Dark Analytics
 * Funcionalidades: minimizar/expandir, filtros por estado/área agrupada por fábrica, pesquisa, contagem por área
 */
import React, { useState, useEffect, useRef } from 'react';
import { Search, X, RotateCcw, Filter, ChevronLeft, ChevronRight, User, Factory, ChevronDown, ChevronUp, Settings2, TriangleAlert, Wrench, BookOpen } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'wouter';
import type { FiltrosDashboard } from '@/hooks/useDashboard';
import type { EstadoPrazo, ResumoArea } from '@/lib/types';
import { ESTADO_LABELS, ESTADO_BADGE_CLASS, ESTADO_COLORS } from '@/lib/utils';
import { ModalGestaoArea } from './ModalGestaoArea';
import { trpc } from '@/lib/trpc';

const TECNICOS_FIXOS = ['Alfredo', 'Marco', 'Outro: Externo'] as const;

// Mapeamento de fábrica para cada área do JSON (todas F1 por agora)
// Áreas custom terão a fábrica guardada na BD
function getFabricaDeArea(area: string, areasCustomFabrica: Record<string, string>): string {
  if (areasCustomFabrica[area]) return areasCustomFabrica[area];
  // Todas as áreas do JSON têm prefixo "F1:"
  if (area.startsWith('F1:')) return 'Fábrica I';
  if (area.startsWith('F2:')) return 'Fábrica II';
  return 'Fábrica I';
}

interface SidebarProps {
  areas: string[];
  porArea?: ResumoArea[];
  listaResponsaveis?: { nome: string; total: number }[];
  filtros: FiltrosDashboard;
  setFiltros: (f: FiltrosDashboard) => void;
  totalFiltrado: number;
  totalGlobal: number;
  collapsed: boolean;
  onToggleCollapse: () => void;
  areasCustomFabrica?: Record<string, string>; // área → fábrica
  onAreaAlterada?: () => void; // callback após editar/eliminar/inativar área
  podeGerir?: boolean;
  nomeUtilizador?: string;
}

const ESTADOS: EstadoPrazo[] = ['vencido', 'proximo', 'em_dia', 'inativo', 'sem_periodicidade'];
const FABRICAS = ['Fábrica I', 'Fábrica II'] as const;

export function Sidebar({
  areas,
  porArea = [],
  listaResponsaveis = [],
  filtros,
  setFiltros,
  totalFiltrado,
  totalGlobal,
  collapsed,
  onToggleCollapse,
  areasCustomFabrica = {},
  onAreaAlterada,
  podeGerir = false,
  nomeUtilizador,
}: SidebarProps) {
  const [location, setLocation] = useLocation();
  const [fabricasExpandidas, setFabricasExpandidas] = useState<Record<string, boolean>>({
    'Fábrica I': true,
    'Fábrica II': true,
  });

  // Modal de gestão de área
  const [areaGestao, setAreaGestao] = useState<{ id: string; nome: string; fabrica?: string | null; descricao?: string | null; inativo?: boolean } | null>(null);

  // Carregar dados das áreas custom (inclui áreas base após seed) para obter id e inativo
  const { data: areasCustomData } = trpc.gestao.listarAreas.useQuery();

  // Seed das áreas base na BD (cria registos se não existirem, para permitir gestão)
  const utils = trpc.useUtils();
  const seedMutation = trpc.gestao.seedAreasBase.useMutation({
    onSuccess: () => {
      // Invalidar para refetch imediato — os ícones aparecem sem refresh manual
      utils.gestao.listarAreas.invalidate();
    },
  });
  const seedFeito = useRef(false);

  useEffect(() => {
    if (seedFeito.current || areasCustomData === undefined || !podeGerir) return;
    const areasBaseJSON = areas.filter(a => a.startsWith('F1:') || a.startsWith('F2:'));
    const areasBaseNovas = areasBaseJSON.filter(a => !areasCustomData.some(ac => ac.nome === a));
    seedFeito.current = true;
    if (areasBaseNovas.length > 0) {
      seedMutation.mutate({
        areas: areasBaseNovas.map(a => ({
          nome: a,
          fabrica: a.startsWith('F2:') ? 'Fábrica II' : 'Fábrica I',
        })),
      });
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [areasCustomData]);

  const toggleArea = (area: string) => {
    const novo = filtros.areas.includes(area)
      ? filtros.areas.filter(a => a !== area)
      : [...filtros.areas, area];
    setFiltros({ ...filtros, areas: novo });
  };

  const toggleEstado = (estado: EstadoPrazo) => {
    const novo = filtros.estados.includes(estado)
      ? filtros.estados.filter(e => e !== estado)
      : [...filtros.estados, estado];
    setFiltros({ ...filtros, estados: novo });
  };

  const limparFiltros = () => {
    setFiltros({ areas: [], estados: [], mes: null, busca: '', responsavel: null, fabrica: null });
  };

  const temFiltros = filtros.areas.length > 0 || filtros.estados.length > 0 || filtros.mes !== null || filtros.busca.trim() !== '' || filtros.responsavel !== null || filtros.fabrica !== null;

  // Mapa de contagens por área
  const contagemPorArea: Record<string, number> = {};
  porArea.forEach(r => { contagemPorArea[r.area] = r.total; });

  // Agrupar áreas por fábrica (filtrar pelo filtro rápido se ativo)
  const areasPorFabrica: Record<string, string[]> = { 'Fábrica I': [], 'Fábrica II': [] };
  areas.forEach(area => {
    const fab = getFabricaDeArea(area, areasCustomFabrica);
    if (!areasPorFabrica[fab]) areasPorFabrica[fab] = [];
    areasPorFabrica[fab].push(area);
  });

  // Fábricas a mostrar na sidebar (todas ou apenas a selecionada)
  const fabricasVisiveis = filtros.fabrica ? [filtros.fabrica] : FABRICAS;

  const toggleFabrica = (fab: string) => {
    setFabricasExpandidas(prev => ({ ...prev, [fab]: !prev[fab] }));
  };

  return (
    <aside
      className="dashboard-sidebar flex flex-col h-full overflow-hidden transition-all duration-300"
      data-collapsed={collapsed}
      style={{
        width: collapsed ? 48 : 264,
        minWidth: collapsed ? 48 : 264,
        background: 'oklch(0.1 0.006 240)',
        borderRight: '1px solid oklch(0.22 0.008 240)',
      }}
    >
      {/* Cabeçalho com botão de colapso */}
      <div
        className="flex items-center flex-shrink-0 px-2 py-3"
        style={{ borderBottom: '1px solid oklch(0.22 0.008 240)', minHeight: 52 }}
      >
        <AnimatePresence mode="wait">
          {!collapsed ? (
            <motion.div
              key="expanded-header"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex items-center gap-2 flex-1 min-w-0"
            >
              <div
                className="w-6 h-6 rounded flex items-center justify-center flex-shrink-0"
                style={{ background: 'oklch(0.72 0.18 60 / 0.2)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}
              >
                <Filter size={12} style={{ color: 'oklch(0.82 0.16 60)' }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold leading-tight" style={{ color: 'oklch(0.88 0.005 240)' }}>Filtros</p>
                <p className="text-xs font-mono" style={{ color: 'oklch(0.45 0.01 240)' }}>
                  {totalFiltrado}/{totalGlobal}
                </p>
              </div>
              {temFiltros && (
                <button
                  onClick={limparFiltros}
                  className="p-1 rounded hover:bg-white/10 transition-colors flex-shrink-0"
                  title="Limpar filtros"
                  style={{ color: 'oklch(0.55 0.01 240)' }}
                >
                  <RotateCcw size={12} />
                </button>
              )}
            </motion.div>
          ) : (
            <motion.div
              key="collapsed-header"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.15 }}
              className="flex items-center justify-center w-full"
            >
              <div
                className="w-6 h-6 rounded flex items-center justify-center"
                style={{ background: 'oklch(0.72 0.18 60 / 0.2)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}
              >
                <Filter size={12} style={{ color: 'oklch(0.82 0.16 60)' }} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Botão de colapso */}
        <button
          onClick={onToggleCollapse}
          className="flex-shrink-0 p-1 rounded hover:bg-white/10 transition-colors ml-1"
          title={collapsed ? 'Expandir filtros' : 'Minimizar filtros'}
          style={{ color: 'oklch(0.52 0.01 240)' }}
        >
          {collapsed ? <ChevronRight size={14} /> : <ChevronLeft size={14} />}
        </button>
      </div>

      {/* Atalhos entre os dois contextos de manutenção */}
      <nav
        aria-label="Navegação de manutenção"
        className="flex flex-col gap-1.5 px-2 py-2.5 flex-shrink-0"
        style={{ borderBottom: '1px solid oklch(0.22 0.008 240)' }}
      >
        {!collapsed && (
          <p className="px-1 text-[10px] font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.45 0.01 240)' }}>
            Painéis
          </p>
        )}
        {[
          { label: 'Manutenção Preventiva', destino: '/', icon: Wrench, cor: 'oklch(0.72 0.18 60)' },
          { label: 'Manutenção Corretiva', destino: '/corretiva', icon: TriangleAlert, cor: 'oklch(0.65 0.16 25)' },
          { label: 'Instruções do software', destino: '/instrucoes', icon: BookOpen, cor: 'oklch(0.72 0.15 185)' },
        ].map(({ label, destino, icon: Icon, cor }) => {
          const ativo = location === destino;
          return (
            <button
              key={destino}
              onClick={() => setLocation(destino)}
              aria-current={ativo ? 'page' : undefined}
              title={collapsed ? label : undefined}
              className="flex items-center gap-2 rounded-md px-2 py-2 text-left text-xs font-semibold transition-all active:scale-[0.97]"
              style={{
                justifyContent: collapsed ? 'center' : 'flex-start',
                background: ativo ? `${cor}1F` : 'transparent',
                border: `1px solid ${ativo ? `${cor}66` : 'transparent'}`,
                color: ativo ? cor : 'oklch(0.6 0.01 240)',
              }}
            >
              <Icon size={14} className="flex-shrink-0" />
              {!collapsed && <span className="truncate">{label}</span>}
            </button>
          );
        })}
      </nav>

      {/* Conteúdo dos filtros — apenas visível quando expandido */}
      <AnimatePresence>
        {!collapsed && (
          <motion.div
            key="sidebar-content"
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -10 }}
            transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
            className="flex flex-col gap-4 flex-1 overflow-y-auto"
            style={{ padding: '0.75rem' }}
          >
            {/* Pesquisa */}
            <div>
              <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                Pesquisa
              </label>
              <div className="relative">
                <Search size={12} className="absolute left-2.5 top-1/2 -translate-y-1/2" style={{ color: 'oklch(0.45 0.01 240)' }} />
                <input
                  type="text"
                  placeholder="Código ou equipamento..."
                  value={filtros.busca}
                  onChange={e => setFiltros({ ...filtros, busca: e.target.value })}
                  className="w-full pl-7 pr-7 py-1.5 rounded text-xs outline-none transition-colors"
                  style={{
                    background: 'oklch(0.1 0.006 240)',
                    border: '1px solid oklch(0.25 0.008 240)',
                    color: 'oklch(0.88 0.005 240)',
                  }}
                />
                {filtros.busca && (
                  <button
                    onClick={() => setFiltros({ ...filtros, busca: '' })}
                    className="absolute right-2 top-1/2 -translate-y-1/2"
                    style={{ color: 'oklch(0.45 0.01 240)' }}
                  >
                    <X size={12} />
                  </button>
                )}
              </div>
            </div>

            {/* Filtro rápido por fábrica */}
            <div>
              <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                <Factory size={11} className="inline mr-1" />
                Fábrica
              </label>
              <div className="flex gap-1.5">
                {(['Todas', 'Fábrica I', 'Fábrica II'] as const).map(opcao => {
                  const valor = opcao === 'Todas' ? null : opcao;
                  const ativo = filtros.fabrica === valor;
                  return (
                    <button
                      key={opcao}
                      onClick={() => setFiltros({ ...filtros, fabrica: valor, areas: [] })}
                      className="flex-1 py-1.5 rounded text-xs font-medium transition-all"
                      style={{
                        background: ativo ? 'oklch(0.72 0.18 60 / 0.18)' : 'oklch(0.14 0.006 240)',
                        border: `1px solid ${ativo ? 'oklch(0.72 0.18 60 / 0.5)' : 'oklch(0.25 0.008 240)'}`,
                        color: ativo ? 'oklch(0.82 0.16 60)' : 'oklch(0.55 0.01 240)',
                      }}
                    >
                      {opcao === 'Todas' ? 'Todas' : opcao.replace('Fábrica ', 'F')}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filtro por estado */}
            <div>
              <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                Estado
              </label>
              <div className="flex flex-col gap-1">
                {ESTADOS.map(estado => {
                  const ativo = filtros.estados.includes(estado);
                  return (
                    <button
                      key={estado}
                      onClick={() => toggleEstado(estado)}
                      className="flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-all text-left"
                      style={{
                        background: ativo ? `${ESTADO_COLORS[estado]}18` : 'transparent',
                        border: `1px solid ${ativo ? ESTADO_COLORS[estado] + '60' : 'transparent'}`,
                        color: ativo ? ESTADO_COLORS[estado] : 'oklch(0.65 0.01 240)',
                      }}
                    >
                      <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: ESTADO_COLORS[estado] }} />
                      {ESTADO_LABELS[estado]}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filtro por responsável — técnicos fixos */}
            <div>
              <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                <User size={11} className="inline mr-1" />
                Técnico
              </label>
              <div className="flex flex-col gap-0.5">
                {TECNICOS_FIXOS.map(nome => {
                  const ativo = filtros.responsavel === nome;
                  const totalRegisto = listaResponsaveis.find(r => r.nome === nome)?.total ?? 0;
                  return (
                    <button
                      key={nome}
                      onClick={() => setFiltros({ ...filtros, responsavel: ativo ? null : nome })}
                      className="flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-all text-left hover:bg-white/5"
                      style={{
                        background: ativo ? 'oklch(0.55 0.18 260 / 0.15)' : 'transparent',
                        border: `1px solid ${ativo ? 'oklch(0.55 0.18 260 / 0.5)' : 'transparent'}`,
                        color: ativo ? 'oklch(0.75 0.15 260)' : 'oklch(0.62 0.01 240)',
                      }}
                    >
                      <User size={11} className="flex-shrink-0" style={{ color: ativo ? 'oklch(0.75 0.15 260)' : 'oklch(0.42 0.01 240)' }} />
                      <span className="truncate flex-1">{nome}</span>
                      {totalRegisto > 0 && (
                        <span
                          className="flex-shrink-0 font-mono px-1.5 py-0.5 rounded-full leading-none"
                          style={{
                            background: ativo ? 'oklch(0.55 0.18 260 / 0.25)' : 'oklch(0.18 0.007 240)',
                            color: ativo ? 'oklch(0.82 0.14 260)' : 'oklch(0.48 0.01 240)',
                            fontSize: '10px',
                          }}
                        >
                          {totalRegisto}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Filtro por área — agrupado por fábrica */}
            <div className="flex-1">
              <label className="text-xs font-medium uppercase tracking-wider block mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                Área
              </label>
              <div className="flex flex-col gap-2">
                {fabricasVisiveis.map(fab => {
                  const areasDoGrupo = areasPorFabrica[fab] ?? [];
                  if (areasDoGrupo.length === 0) return null;
                  const expandido = fabricasExpandidas[fab] ?? true;
                  const ativasNoGrupo = areasDoGrupo.filter(a => filtros.areas.includes(a)).length;

                  return (
                    <div key={fab}>
                      {/* Cabeçalho da fábrica */}
                      <button
                        onClick={() => toggleFabrica(fab)}
                        className="w-full flex items-center gap-1.5 px-2 py-1 rounded text-xs font-semibold transition-colors hover:bg-white/5 mb-0.5"
                        style={{ color: 'oklch(0.72 0.18 60)', background: 'oklch(0.72 0.18 60 / 0.06)' }}
                      >
                        <Factory size={11} />
                        <span className="flex-1 text-left">{fab}</span>
                        {ativasNoGrupo > 0 && (
                          <span
                            className="font-mono px-1.5 py-0.5 rounded-full leading-none"
                            style={{ background: 'oklch(0.72 0.18 60 / 0.25)', color: 'oklch(0.88 0.14 60)', fontSize: '10px' }}
                          >
                            {ativasNoGrupo}
                          </span>
                        )}
                        {expandido ? <ChevronUp size={11} /> : <ChevronDown size={11} />}
                      </button>

                      {/* Lista de áreas */}
                      <AnimatePresence>
                        {expandido && (
                          <motion.div
                            initial={{ opacity: 0, height: 0 }}
                            animate={{ opacity: 1, height: 'auto' }}
                            exit={{ opacity: 0, height: 0 }}
                            transition={{ duration: 0.18 }}
                            className="flex flex-col gap-0.5 overflow-hidden pl-2"
                          >
                            {areasDoGrupo.map(area => {
                              const ativo = filtros.areas.includes(area);
                              const count = contagemPorArea[area] ?? 0;
                              const isCustom = !!areasCustomFabrica[area] || (areasCustomData ?? []).some(a => a.nome === area);
                              const areaCustomObj = (areasCustomData ?? []).find(a => a.nome === area);
                              const isInativa = areaCustomObj?.inativo ?? false;
                              return (
                                <div key={area} className="flex items-center gap-1 group/area">
                                  <button
                                    onClick={() => toggleArea(area)}
                                    className="flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-all text-left hover:bg-white/5 flex-1 min-w-0"
                                    style={{
                                      background: ativo ? 'oklch(0.72 0.18 60 / 0.12)' : 'transparent',
                                      border: `1px solid ${ativo ? 'oklch(0.72 0.18 60 / 0.4)' : 'transparent'}`,
                                      color: isInativa ? 'oklch(0.42 0.01 240)' : ativo ? 'oklch(0.82 0.16 60)' : 'oklch(0.62 0.01 240)',
                                      opacity: isInativa ? 0.6 : 1,
                                    }}
                                  >
                                    <span
                                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                                      style={{ background: isInativa ? 'oklch(0.35 0.008 240)' : ativo ? 'oklch(0.72 0.18 60)' : 'oklch(0.35 0.008 240)' }}
                                    />
                                    <span className="truncate flex-1">{area}</span>
                                    {isInativa && (
                                      <span className="flex-shrink-0 text-xs px-1 rounded" style={{ background: 'oklch(0.62 0.22 25 / 0.15)', color: '#EF4444', fontSize: '9px' }}>inativa</span>
                                    )}
                                    {count > 0 && !isInativa && (
                                      <span
                                        className="flex-shrink-0 text-xs font-mono px-1.5 py-0.5 rounded-full leading-none"
                                        style={{
                                          background: ativo ? 'oklch(0.72 0.18 60 / 0.25)' : 'oklch(0.18 0.007 240)',
                                          color: ativo ? 'oklch(0.88 0.14 60)' : 'oklch(0.48 0.01 240)',
                                          fontSize: '10px',
                                        }}
                                      >
                                        {count}
                                      </span>
                                    )}
                                  </button>
                                  {/* Botão de gestão — para todas as áreas (custom e base) */}
                                  {areaCustomObj && podeGerir && (
                                    <button
                                      onClick={(e) => { e.stopPropagation(); setAreaGestao(areaCustomObj); }}
                                      className="flex-shrink-0 p-1 rounded opacity-0 group-hover/area:opacity-100 transition-opacity hover:bg-white/10"
                                      style={{ color: 'oklch(0.55 0.18 260)' }}
                                      title="Gerir área"
                                    >
                                      <Settings2 size={11} />
                                    </button>
                                  )}
                                </div>
                              );
                            })}
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Modal de gestão de área custom */}
      {areaGestao && (
        <ModalGestaoArea
          area={areaGestao}
          nomeUtilizador={nomeUtilizador}
          onFechar={() => setAreaGestao(null)}
          onAlterada={() => {
            setAreaGestao(null);
            onAreaAlterada?.();
          }}
        />
      )}

      {/* Modo colapsado: indicadores de filtros ativos */}
      {collapsed && (filtros.areas.length > 0 || filtros.estados.length > 0) && (
        <div className="flex flex-col items-center gap-1 pt-2">
          <div
            className="w-5 h-5 rounded-full flex items-center justify-center text-xs font-mono font-bold"
            style={{ background: 'oklch(0.62 0.22 25 / 0.3)', color: '#EF4444', fontSize: '9px' }}
            title={`${filtros.areas.length + filtros.estados.length} filtros ativos`}
          >
            {filtros.areas.length + filtros.estados.length}
          </div>
        </div>
      )}
    </aside>
  );
}
