/*
 * MesCorrente — Painel de manutenções do mês corrente
 * Design: Industrial Dark Analytics — acento âmbar
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { CalendarClock, ChevronDown, ChevronUp, ClipboardEdit } from 'lucide-react';
import type { Equipamento } from '@/lib/types';
import { ESTADO_BADGE_CLASS, ESTADO_LABELS, formatDate, nomesMesAtual } from '@/lib/utils';

interface MesCorrenteProps {
  equipamentos: Equipamento[];
  onAbrirModal?: (equipamento: Equipamento) => void;
}

export function MesCorrente({ equipamentos, onAbrirModal }: MesCorrenteProps) {
  const [aberto, setAberto] = useState(true);
  const mesNome = nomesMesAtual();
  const count = equipamentos.length;

  if (count === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: 0.1 }}
      className="rounded-lg overflow-hidden glow-amber"
      style={{ border: '1px solid oklch(0.72 0.18 60 / 0.4)', background: 'oklch(0.72 0.18 60 / 0.07)' }}
    >
      <button
        onClick={() => setAberto(!aberto)}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-white/5 transition-colors"
      >
        <div className="flex items-center gap-2">
          <CalendarClock size={18} style={{ color: '#F59E0B' }} />
          <span className="font-semibold text-sm" style={{ color: '#F59E0B' }}>
            {count} {count !== 1 ? 'manutenções' : 'manutenção'} em {mesNome}
          </span>
          <span className="text-xs px-2 py-0.5 rounded-full font-mono" style={{ background: 'oklch(0.72 0.18 60 / 0.2)', color: '#F59E0B' }}>
            MÊS CORRENTE
          </span>
          {onAbrirModal && (
            <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'oklch(0.72 0.18 60 / 0.1)', color: 'oklch(0.75 0.01 240)' }}>
              Clique numa linha para registar intervenção
            </span>
          )}
        </div>
        {aberto ? <ChevronUp size={16} style={{ color: '#F59E0B' }} /> : <ChevronDown size={16} style={{ color: '#F59E0B' }} />}
      </button>

      <AnimatePresence>
        {aberto && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
            className="overflow-hidden"
          >
            <div className="px-4 pb-3 max-h-48 overflow-y-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr style={{ color: 'oklch(0.55 0.01 240)' }}>
                    <th className="text-left py-1 pr-3 font-medium">Código</th>
                    <th className="text-left py-1 pr-3 font-medium">Equipamento</th>
                    <th className="text-left py-1 pr-3 font-medium">Área</th>
                    <th className="text-left py-1 pr-3 font-medium">Fábrica</th>
                    <th className="text-left py-1 pr-3 font-medium">Periodicidade</th>
                    <th className="text-left py-1 pr-3 font-medium">Data</th>
                    <th className="text-left py-1 font-medium">Estado</th>
                    {onAbrirModal && <th className="text-left py-1 pl-3 font-medium">Ação</th>}
                  </tr>
                </thead>
                <tbody>
                  {equipamentos.map((e, i) => (
                    <tr
                      key={`${e.codigo}-${i}`}
                      className="border-t group"
                      style={{
                        borderColor: 'oklch(0.72 0.18 60 / 0.15)',
                        cursor: onAbrirModal ? 'pointer' : 'default',
                      }}
                      onClick={() => onAbrirModal?.(e)}
                      role={onAbrirModal ? 'button' : undefined}
                      tabIndex={onAbrirModal ? 0 : undefined}
                      onKeyDown={onAbrirModal ? (ev) => ev.key === 'Enter' && onAbrirModal(e) : undefined}
                      title={onAbrirModal ? 'Clique para registar intervenção' : undefined}
                    >
                      <td className="py-1.5 pr-3 font-mono" style={{ color: 'oklch(0.82 0.16 60)' }}>{e.codigo}</td>
                      <td className="py-1.5 pr-3 group-hover:text-white transition-colors" style={{ color: 'oklch(0.88 0.005 240)' }}>{e.equipamento}</td>
                      <td className="py-1.5 pr-3" style={{ color: 'oklch(0.65 0.01 240)' }}>{e.area}</td>
                      <td className="py-1.5 pr-3" style={{ color: 'oklch(0.52 0.01 240)', fontSize: '11px' }}>{e.fabrica ?? '—'}</td>
                      <td className="py-1.5 pr-3" style={{ color: 'oklch(0.65 0.01 240)' }}>{e.periodicidade}</td>
                      <td className="py-1.5 pr-3 font-mono" style={{ color: 'oklch(0.82 0.16 60)' }}>{formatDate(e.proxima_manutencao)}</td>
                      <td className="py-1.5">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${ESTADO_BADGE_CLASS[e.estado_prazo]}`}>
                          {ESTADO_LABELS[e.estado_prazo]}
                        </span>
                      </td>
                      {onAbrirModal && (
                        <td className="py-1.5 pl-3">
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                            style={{ background: 'oklch(0.72 0.18 60 / 0.2)', color: '#F59E0B' }}
                          >
                            <ClipboardEdit size={11} />
                            Registar
                          </span>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
