/*
 * ModalGestaoArea — Gestão protegida por código de acesso para áreas custom
 * Permite: editar nome/fábrica, inativar/reativar, eliminar
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Shield, Eye, EyeOff, AlertTriangle, Loader2, Pencil, Trash2, PowerOff, Power, ChevronRight } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

interface AreaCustom {
  id: string;
  nome: string;
  fabrica?: string | null;
  descricao?: string | null;
  inativo?: boolean;
}

interface ModalGestaoAreaProps {
  area: AreaCustom;
  nomeUtilizador?: string;
  onFechar: () => void;
  onAlterada: () => void;
}

type Passo = 'menu' | 'codigo' | 'editar' | 'confirmar-eliminar';
type Acao = 'editar' | 'inativar' | 'reativar' | 'eliminar';

const FABRICAS = ['Fábrica I', 'Fábrica II'];

const labelAcao: Record<Acao, string> = {
  editar: 'Editar Área',
  inativar: 'Inativar Área',
  reativar: 'Reativar Área',
  eliminar: 'Eliminar Área',
};

const corBotaoAcao: Record<Acao, string> = {
  editar: 'oklch(0.55 0.18 260)',
  inativar: 'oklch(0.52 0.22 25)',
  reativar: 'oklch(0.62 0.18 145)',
  eliminar: 'oklch(0.45 0.22 25)',
};

export function ModalGestaoArea({ area, nomeUtilizador, onFechar, onAlterada }: ModalGestaoAreaProps) {
  const [passo, setPasso] = useState<Passo>('menu');
  const [acaoSelecionada, setAcaoSelecionada] = useState<Acao | null>(null);
  const [codigo, setCodigo] = useState('');
  const [mostrarCodigo, setMostrarCodigo] = useState(false);
  const [erroCodigo, setErroCodigo] = useState('');

  // Campos de edição
  const [nomeEditado, setNomeEditado] = useState(area.nome);
  const [fabricaEditada, setFabricaEditada] = useState(area.fabrica ?? 'Fábrica I');

  const utils = trpc.useUtils();

  const editarMutation = trpc.gestao.editarArea.useMutation({
    onSuccess: () => {
      toast.success('Área atualizada com sucesso.');
      utils.gestao.listarAreas.invalidate();
      onAlterada();
    },
    onError: (err) => {
      if (err.message.includes('inválido')) setErroCodigo('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const eliminarMutation = trpc.gestao.eliminarArea.useMutation({
    onSuccess: () => {
      toast.success('Área eliminada com sucesso.');
      utils.gestao.listarAreas.invalidate();
      onAlterada();
    },
    onError: (err) => {
      if (err.message.includes('inválido')) setErroCodigo('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const toggleMutation = trpc.gestao.toggleInativoArea.useMutation({
    onSuccess: () => {
      const msg = acaoSelecionada === 'inativar' ? 'Área inativada.' : 'Área reativada.';
      toast.success(msg);
      utils.gestao.listarAreas.invalidate();
      onAlterada();
    },
    onError: (err) => {
      if (err.message.includes('inválido')) setErroCodigo('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const isCarregando = editarMutation.isPending || eliminarMutation.isPending || toggleMutation.isPending;

  const handleSelecionarAcao = (acao: Acao) => {
    setAcaoSelecionada(acao);
    setErroCodigo('');
    setCodigo('');
    if (acao === 'editar') {
      setPasso('codigo');
    } else if (acao === 'eliminar') {
      setPasso('codigo');
    } else {
      setPasso('codigo');
    }
  };

  const handleConfirmarCodigo = () => {
    if (!codigo.trim()) { setErroCodigo('Introduza o código de acesso.'); return; }
    setErroCodigo('');
    if (acaoSelecionada === 'editar') {
      setPasso('editar');
    } else if (acaoSelecionada === 'eliminar') {
      setPasso('confirmar-eliminar');
    } else if (acaoSelecionada === 'inativar') {
      toggleMutation.mutate({ id: area.id, codigoAcesso: codigo, nomeUtilizador, inativo: true });
    } else if (acaoSelecionada === 'reativar') {
      toggleMutation.mutate({ id: area.id, codigoAcesso: codigo, nomeUtilizador, inativo: false });
    }
  };

  const handleGuardarEdicao = () => {
    if (!nomeEditado.trim()) { toast.error('O nome da área não pode estar vazio.'); return; }
    editarMutation.mutate({ id: area.id, codigoAcesso: codigo, nomeUtilizador, nome: nomeEditado.trim(), fabrica: fabricaEditada });
  };

  const handleConfirmarEliminar = () => {
    eliminarMutation.mutate({ id: area.id, codigoAcesso: codigo, nomeUtilizador });
  };

  const bg = 'oklch(0.1 0.006 240)';
  const border = '1px solid oklch(0.22 0.008 240)';
  const textPrimary = 'oklch(0.92 0.005 240)';
  const textSecondary = 'oklch(0.55 0.01 240)';
  const inputStyle = {
    background: 'oklch(0.14 0.006 240)',
    border: `1px solid oklch(0.28 0.008 240)`,
    color: textPrimary,
    borderRadius: '6px',
    padding: '8px 12px',
    fontSize: '13px',
    width: '100%',
    outline: 'none',
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-[60] flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.75)' }}
        onClick={(e) => e.target === e.currentTarget && onFechar()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
          className="w-full max-w-sm mx-4 rounded-xl overflow-hidden"
          style={{ background: bg, border }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: border }}>
            <div className="flex items-center gap-2">
              <Shield size={15} style={{ color: 'oklch(0.72 0.18 60)' }} />
              <h2 className="font-semibold text-sm" style={{ color: textPrimary }}>
                Gerir Área
              </h2>
            </div>
            <button onClick={onFechar} className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: textSecondary }}>
              <X size={15} />
            </button>
          </div>

          {/* Body */}
          <div className="p-5">
            {/* Nome da área */}
            <p className="text-xs mb-4" style={{ color: textSecondary }}>
              <span className="font-semibold" style={{ color: textPrimary }}>{area.nome}</span>
              {area.fabrica && <span> · {area.fabrica}</span>}
              {area.inativo && <span className="ml-2 px-1.5 py-0.5 rounded text-xs" style={{ background: 'oklch(0.62 0.22 25 / 0.15)', color: '#EF4444' }}>Inativa</span>}
            </p>

            {/* PASSO: Menu de ações */}
            {passo === 'menu' && (
              <div className="flex flex-col gap-2">
                <button
                  onClick={() => handleSelecionarAcao('editar')}
                  className="flex items-center justify-between w-full px-4 py-3 rounded-lg text-sm font-medium transition-all hover:opacity-90 active:scale-[0.98]"
                  style={{ background: 'oklch(0.55 0.18 260 / 0.12)', color: 'oklch(0.72 0.15 260)', border: '1px solid oklch(0.55 0.18 260 / 0.3)' }}
                >
                  <span className="flex items-center gap-2"><Pencil size={14} /> Editar nome / fábrica</span>
                  <ChevronRight size={14} />
                </button>
                {!area.inativo ? (
                  <button
                    onClick={() => handleSelecionarAcao('inativar')}
                    className="flex items-center justify-between w-full px-4 py-3 rounded-lg text-sm font-medium transition-all hover:opacity-90 active:scale-[0.98]"
                    style={{ background: 'oklch(0.62 0.22 25 / 0.1)', color: 'oklch(0.72 0.15 25)', border: '1px solid oklch(0.62 0.22 25 / 0.3)' }}
                  >
                    <span className="flex items-center gap-2"><PowerOff size={14} /> Inativar área</span>
                    <ChevronRight size={14} />
                  </button>
                ) : (
                  <button
                    onClick={() => handleSelecionarAcao('reativar')}
                    className="flex items-center justify-between w-full px-4 py-3 rounded-lg text-sm font-medium transition-all hover:opacity-90 active:scale-[0.98]"
                    style={{ background: 'oklch(0.62 0.18 145 / 0.1)', color: '#10B981', border: '1px solid oklch(0.62 0.18 145 / 0.3)' }}
                  >
                    <span className="flex items-center gap-2"><Power size={14} /> Reativar área</span>
                    <ChevronRight size={14} />
                  </button>
                )}
                <button
                  onClick={() => handleSelecionarAcao('eliminar')}
                  className="flex items-center justify-between w-full px-4 py-3 rounded-lg text-sm font-medium transition-all hover:opacity-90 active:scale-[0.98]"
                  style={{ background: 'oklch(0.45 0.22 25 / 0.1)', color: '#EF4444', border: '1px solid oklch(0.45 0.22 25 / 0.3)' }}
                >
                  <span className="flex items-center gap-2"><Trash2 size={14} /> Eliminar área</span>
                  <ChevronRight size={14} />
                </button>
              </div>
            )}

            {/* PASSO: Código de acesso */}
            {passo === 'codigo' && acaoSelecionada && (
              <div className="flex flex-col gap-4">
                <p className="text-xs" style={{ color: textSecondary }}>
                  Introduza o código de acesso para <strong style={{ color: textPrimary }}>{labelAcao[acaoSelecionada].toLowerCase()}</strong>.
                </p>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                    Código de Acesso
                  </label>
                  <div className="relative">
                    <input
                      type={mostrarCodigo ? 'text' : 'password'}
                      value={codigo}
                      onChange={(e) => { setCodigo(e.target.value); setErroCodigo(''); }}
                      onKeyDown={(e) => e.key === 'Enter' && handleConfirmarCodigo()}
                      placeholder="••••••••"
                      style={{ ...inputStyle, paddingRight: '36px' }}
                      autoFocus
                    />
                    <button type="button" onClick={() => setMostrarCodigo(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2" style={{ color: 'oklch(0.45 0.01 240)' }}>
                      {mostrarCodigo ? <EyeOff size={14} /> : <Eye size={14} />}
                    </button>
                  </div>
                  {erroCodigo && (
                    <p className="text-xs mt-1.5 flex items-center gap-1" style={{ color: '#EF4444' }}>
                      <AlertTriangle size={11} /> {erroCodigo}
                    </p>
                  )}
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setPasso('menu')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                    Voltar
                  </button>
                  <button
                    onClick={handleConfirmarCodigo}
                    disabled={!codigo.trim() || isCarregando}
                    className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all"
                    style={{ background: codigo.trim() && !isCarregando ? corBotaoAcao[acaoSelecionada] : 'oklch(0.3 0.01 240)', color: codigo.trim() && !isCarregando ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)' }}
                  >
                    {isCarregando ? <Loader2 size={14} className="animate-spin" /> : null}
                    Confirmar
                  </button>
                </div>
              </div>
            )}

            {/* PASSO: Editar campos */}
            {passo === 'editar' && (
              <div className="flex flex-col gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>Nome da Área</label>
                  <input
                    type="text"
                    value={nomeEditado}
                    onChange={(e) => setNomeEditado(e.target.value)}
                    style={inputStyle}
                    autoFocus
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>Fábrica</label>
                  <select
                    value={fabricaEditada}
                    onChange={(e) => setFabricaEditada(e.target.value)}
                    style={{ ...inputStyle, cursor: 'pointer' }}
                  >
                    {FABRICAS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setPasso('menu')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                    Cancelar
                  </button>
                  <button
                    onClick={handleGuardarEdicao}
                    disabled={!nomeEditado.trim() || isCarregando}
                    className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all"
                    style={{ background: nomeEditado.trim() && !isCarregando ? 'oklch(0.55 0.18 260)' : 'oklch(0.3 0.01 240)', color: nomeEditado.trim() && !isCarregando ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)' }}
                  >
                    {isCarregando ? <Loader2 size={14} className="animate-spin" /> : null}
                    Guardar
                  </button>
                </div>
              </div>
            )}

            {/* PASSO: Confirmar eliminação */}
            {passo === 'confirmar-eliminar' && (
              <div className="flex flex-col gap-4">
                <div className="p-3 rounded-lg" style={{ background: 'oklch(0.45 0.22 25 / 0.1)', border: '1px solid oklch(0.45 0.22 25 / 0.3)' }}>
                  <p className="text-xs font-semibold mb-1" style={{ color: '#EF4444' }}>
                    <AlertTriangle size={12} className="inline mr-1" />
                    Atenção: esta ação é irreversível
                  </p>
                  <p className="text-xs" style={{ color: 'oklch(0.65 0.01 240)' }}>
                    A área <strong style={{ color: textPrimary }}>{area.nome}</strong> será eliminada permanentemente. Os equipamentos associados não serão eliminados.
                  </p>
                </div>
                <div className="flex gap-3">
                  <button onClick={() => setPasso('menu')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                    Cancelar
                  </button>
                  <button
                    onClick={handleConfirmarEliminar}
                    disabled={isCarregando}
                    className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2 transition-all"
                    style={{ background: !isCarregando ? '#EF4444' : 'oklch(0.3 0.01 240)', color: !isCarregando ? 'white' : 'oklch(0.45 0.01 240)' }}
                  >
                    {isCarregando ? <Loader2 size={14} className="animate-spin" /> : <Trash2 size={14} />}
                    Eliminar
                  </button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
