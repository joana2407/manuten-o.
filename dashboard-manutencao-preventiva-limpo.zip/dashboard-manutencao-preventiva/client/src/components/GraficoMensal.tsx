/*
 * GraficoMensal — Gráfico de barras agrupadas por mês
 * Destaca o mês corrente com marcador visual
 */
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ReferenceLine } from 'recharts';
import type { ResumoMes } from '@/lib/types';
import { ESTADO_COLORS, mesAtual } from '@/lib/utils';

interface GraficoMensalProps {
  porMes: ResumoMes[];
  mesSelecionado: number | null;
  onMesClick: (mes: number | null) => void;
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg p-3 text-xs" style={{ background: 'oklch(0.13 0.007 240)', border: '1px solid oklch(0.25 0.008 240)', minWidth: 160 }}>
      <p className="font-semibold mb-2" style={{ color: 'oklch(0.88 0.005 240)' }}>{label}</p>
      {payload.map((p: any) => (
        <div key={p.name} className="flex items-center justify-between gap-4 py-0.5">
          <span className="flex items-center gap-1.5" style={{ color: 'oklch(0.65 0.01 240)' }}>
            <span className="w-2 h-2 rounded-full inline-block" style={{ background: p.fill }} />
            {p.name}
          </span>
          <span className="font-mono font-semibold" style={{ color: p.fill }}>{p.value}</span>
        </div>
      ))}
    </div>
  );
};

export function GraficoMensal({ porMes, mesSelecionado, onMesClick }: GraficoMensalProps) {
  const mesHoje = mesAtual();

  const handleClick = (data: any) => {
    if (!data?.activePayload?.[0]) return;
    const mes = data.activePayload[0].payload.mes;
    onMesClick(mesSelecionado === mes ? null : mes);
  };

  return (
    <div className="rounded-lg p-4" style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>
          Manutenções por Mês — 2026
        </h3>
        {mesSelecionado && (
          <button
            onClick={() => onMesClick(null)}
            className="text-xs px-2 py-1 rounded transition-colors hover:bg-white/10"
            style={{ color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}
          >
            Limpar filtro
          </button>
        )}
      </div>
      <ResponsiveContainer width="100%" height={220}>
        <BarChart data={porMes} margin={{ top: 4, right: 8, left: -8, bottom: 0 }} barSize={14} onClick={handleClick} style={{ cursor: 'pointer' }}>
          <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.22 0.008 240)" vertical={false} />
          <XAxis dataKey="label" tick={{ fill: 'oklch(0.65 0.01 240)', fontSize: 11 }} axisLine={false} tickLine={false} />
          <YAxis tick={{ fill: 'oklch(0.52 0.01 240)', fontSize: 11, fontFamily: 'JetBrains Mono' }} axisLine={false} tickLine={false} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: 'oklch(0.18 0.007 240)' }} />
          <Legend wrapperStyle={{ fontSize: 11, color: 'oklch(0.65 0.01 240)' }} />
          <ReferenceLine x={porMes.find(m => m.mes === mesHoje)?.label} stroke="oklch(0.72 0.18 60 / 0.6)" strokeDasharray="4 2" label={{ value: 'Hoje', fill: 'oklch(0.72 0.18 60)', fontSize: 10, position: 'top' }} />
          <Bar dataKey="vencidos" name="Vencido" fill={ESTADO_COLORS.vencido} radius={[2, 2, 0, 0]} />
          <Bar dataKey="proximos" name="Próximo" fill={ESTADO_COLORS.proximo} radius={[2, 2, 0, 0]} />
          <Bar dataKey="em_dia" name="Em dia" fill={ESTADO_COLORS.em_dia} radius={[2, 2, 0, 0]} />
        </BarChart>
      </ResponsiveContainer>
      <p className="text-xs mt-2" style={{ color: 'oklch(0.45 0.01 240)' }}>
        Clique numa barra para filtrar a tabela por mês
      </p>
    </div>
  );
}
