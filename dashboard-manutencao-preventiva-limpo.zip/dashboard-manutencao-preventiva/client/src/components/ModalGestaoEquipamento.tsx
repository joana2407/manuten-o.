/*
 * ModalGestaoEquipamento — Modal protegido por código de acesso
 * Suporta TODOS os equipamentos (JSON base + custom)
 * Ações: Editar, Inativar/Reativar, Eliminar
 * Design: Industrial Dark Analytics — similar ao ModalGestaoArea
 */
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Shield, Edit2, Trash2, PowerOff, Power, Loader2, Eye, EyeOff, AlertTriangle, Factory } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import type { Equipamento } from '@/lib/types';

const PERIODICIDADES = ['Diária', 'Semanal', 'Quinzenal', 'Mensal', 'Bimestral', 'Trimestral', 'Semestral', 'Anual'];
const FABRICAS = ['Fábrica I', 'Fábrica II'];

type Passo = 'menu' | 'codigo' | 'editar' | 'confirmar';
type Acao = 'editar' | 'inativar' | 'eliminar';

function getFabricaDeArea(area: string, areasCustomFabrica: Record<string, string>): string {
  if (areasCustomFabrica[area]) return areasCustomFabrica[area];
  if (area.startsWith('F1:')) return 'Fábrica I';
  if (area.startsWith('F2:')) return 'Fábrica II';
  return 'Fábrica I';
}

interface ModalGestaoEquipamentoProps {
  equipamento: Equipamento;
  todasAreas: string[];
  areasCustomFabrica?: Record<string, string>;
  nomeUtilizador?: string;
  onFechar: () => void;
  onAlterado: () => void;
}

export function ModalGestaoEquipamento({
  equipamento,
  todasAreas,
  areasCustomFabrica = {},
  nomeUtilizador,
  onFechar,
  onAlterado,
}: ModalGestaoEquipamentoProps) {
  const [passo, setPasso] = useState<Passo>('menu');
  const [acaoSelecionada, setAcaoSelecionada] = useState<Acao | null>(null);
  const [codigoAcesso, setCodigoAcesso] = useState('');
  const [mostrarCodigo, setMostrarCodigo] = useState(false);
  const [erroAcesso, setErroAcesso] = useState('');

  // Campos de edição
  const [codigo, setCodigo] = useState(equipamento.codigo);
  const [nomeEquip, setNomeEquip] = useState(equipamento.equipamento);
  const [fabrica, setFabrica] = useState(() => getFabricaDeArea(equipamento.area, areasCustomFabrica));
  const [area, setArea] = useState(equipamento.area);
  const [periodicidade, setPeriodicidade] = useState(equipamento.periodicidade);
  const [modelo, setModelo] = useState(equipamento.modelo ?? '');
  const [numeroSerie, setNumeroSerie] = useState(equipamento.numeroSerie ?? '');
  const [planoIntervencao, setPlanoIntervencao] = useState(equipamento.planoIntervencao ?? '');

  const utils = trpc.useUtils();

  // Áreas filtradas pela fábrica selecionada na edição
  const areasDaFabrica = useMemo(() => {
    return todasAreas.filter(a => getFabricaDeArea(a, areasCustomFabrica) === fabrica);
  }, [todasAreas, fabrica, areasCustomFabrica]);

  const handleFabricaChange = (novaFabrica: string) => {
    setFabrica(novaFabrica);
    const primeira = todasAreas.find(a => getFabricaDeArea(a, areasCustomFabrica) === novaFabrica);
    setArea(primeira ?? '');
  };

  // Mutation para equipamentos CUSTOM
  const editarCustomMutation = trpc.gestao.editarEquipamento.useMutation({
    onSuccess: () => {
      toast.success('Equipamento atualizado com sucesso');
      utils.gestao.listarEquipamentos.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const eliminarCustomMutation = trpc.gestao.eliminarEquipamento.useMutation({
    onSuccess: () => {
      toast.success('Equipamento eliminado');
      utils.gestao.listarEquipamentos.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const toggleInativoCustomMutation = trpc.gestao.toggleInativoCustom.useMutation({
    onSuccess: () => {
      toast.success(isInativo ? 'Equipamento reativado' : 'Equipamento inativado');
      utils.gestao.listarEquipamentos.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  // Mutation para equipamentos do JSON (override)
  const toggleInativoJsonMutation = trpc.gestao.toggleInativo.useMutation({
    onSuccess: () => {
      toast.success(isInativo ? 'Equipamento reativado' : 'Equipamento inativado');
      utils.gestao.listarOverrides.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  // Mutation para eliminar equipamentos do JSON base (override com eliminado=true)
  const eliminarBaseJsonMutation = trpc.gestao.eliminarEquipamentoBase.useMutation({
    onSuccess: () => {
      toast.success('Equipamento eliminado do dashboard');
      utils.gestao.listarOverrides.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err: { message: string }) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  // Mutation para editar equipamentos do JSON (upsert override com campos editados)
  const editarJsonMutation = trpc.gestao.upsertEquipamentoOverride.useMutation({
    onSuccess: () => {
      toast.success('Equipamento atualizado com sucesso');
      utils.gestao.listarOverrides.invalidate();
      onAlterado(); onFechar();
    },
    onError: (err: { message: string }) => {
      if (err.message.includes('acesso')) setErroAcesso('Código de acesso inválido.');
      else toast.error(`Erro: ${err.message}`);
    },
  });

  const isInativo = equipamento.estado_prazo === 'inativo' || equipamento.estado === 'Inativo';
  const isCustom = !!equipamento.isCustom;

  const handleEscolherAcao = (acao: Acao) => {
    setAcaoSelecionada(acao);
    setCodigoAcesso('');
    setErroAcesso('');
    setPasso('codigo');
  };

  const handleValidarCodigo = () => {
    if (!codigoAcesso.trim()) { setErroAcesso('Introduza o código de acesso.'); return; }
    setErroAcesso('');
    if (acaoSelecionada === 'editar') setPasso('editar');
    else setPasso('confirmar');
  };

  const handleConfirmar = () => {
    if (acaoSelecionada === 'inativar') {
      if (isCustom && equipamento.id) {
        toggleInativoCustomMutation.mutate({ id: equipamento.id, codigoAcesso, nomeUtilizador, inativo: !isInativo });
      } else {
        toggleInativoJsonMutation.mutate({ codigoEquipamento: equipamento.codigo, area: equipamento.area, inativo: !isInativo, codigoAcesso, nomeUtilizador });
      }
    } else if (acaoSelecionada === 'eliminar') {
      if (isCustom && equipamento.id) {
        eliminarCustomMutation.mutate({ id: equipamento.id, codigoAcesso, nomeUtilizador });
      } else {
        // Para JSON: marcar como eliminado via override (oculto do dashboard)
        eliminarBaseJsonMutation.mutate({ codigoEquipamento: equipamento.codigo, area: equipamento.area, codigoAcesso, nomeUtilizador });
      }
    }
  };

  const handleGuardarEdicao = () => {
    if (isCustom && equipamento.id) {
      editarCustomMutation.mutate({
        id: equipamento.id,
        codigoAcesso,
        nomeUtilizador,
        codigo,
        equipamento: nomeEquip,
        area,
        periodicidade: periodicidade || undefined,
        modelo: modelo.trim() || undefined,
        numeroSerie: numeroSerie.trim() || undefined,
        planoIntervencao: planoIntervencao.trim() || undefined,
      });
    } else {
      // Para JSON: guardar override de edição
      editarJsonMutation.mutate({
        codigoEquipamento: equipamento.codigo,
        area: equipamento.area,
        codigoAcesso,
        nomeUtilizador,
        novoNome: nomeEquip !== equipamento.equipamento ? nomeEquip : undefined,
        novaArea: area !== equipamento.area ? area : undefined,
        novaPeriodicidade: periodicidade !== equipamento.periodicidade ? periodicidade : undefined,
        modelo: modelo.trim() || undefined,
        numeroSerie: numeroSerie.trim() || undefined,
        planoIntervencao: planoIntervencao.trim() || undefined,
      });
    }
  };

  const inputStyle = {
    background: 'oklch(0.14 0.006 240)',
    border: '1px solid oklch(0.28 0.008 240)',
    color: 'oklch(0.92 0.005 240)',
    borderRadius: '6px',
    padding: '8px 12px',
    fontSize: '13px',
    width: '100%',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '11px',
    fontWeight: 600 as const,
    letterSpacing: '0.05em',
    color: 'oklch(0.55 0.01 240)',
    marginBottom: '6px',
    textTransform: 'uppercase' as const,
  };

  const isPending = editarCustomMutation.isPending || eliminarCustomMutation.isPending ||
    toggleInativoCustomMutation.isPending || toggleInativoJsonMutation.isPending || editarJsonMutation.isPending ||
    eliminarBaseJsonMutation.isPending;

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.75)' }}
        onClick={(e) => e.target === e.currentTarget && onFechar()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="w-full max-w-md mx-4 rounded-xl overflow-hidden"
          style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid oklch(0.18 0.006 240)' }}>
            <div className="flex items-center gap-2">
              <Shield size={16} style={{ color: 'oklch(0.72 0.18 60)' }} />
              <div>
                <h2 className="font-semibold text-sm" style={{ color: 'oklch(0.92 0.005 240)' }}>
                  Gestão de Equipamento
                </h2>
                <p className="text-xs" style={{ color: 'oklch(0.52 0.01 240)' }}>
                  {equipamento.codigo} — {equipamento.equipamento}
                  {equipamento.fabrica && (
                    <span style={{ color: 'oklch(0.45 0.01 240)' }}> · {equipamento.fabrica}</span>
                  )}
                </p>
              </div>
            </div>
            <button onClick={onFechar} className="p-1 rounded hover:bg-white/10 transition-colors" style={{ color: 'oklch(0.55 0.01 240)' }}>
              <X size={16} />
            </button>
          </div>

          {/* Passo 1: Menu de ações */}
          {passo === 'menu' && (
            <div className="p-5 flex flex-col gap-3">
              <p className="text-xs" style={{ color: 'oklch(0.55 0.01 240)' }}>
                Selecione a operação a realizar. Será solicitado um código de acesso.
              </p>
              <button
                onClick={() => handleEscolherAcao('editar')}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all hover:bg-white/5 text-left"
                style={{ border: '1px solid oklch(0.25 0.008 240)', color: 'oklch(0.75 0.15 260)' }}
              >
                <Edit2 size={15} />
                <div>
                  <p className="font-semibold">Editar Equipamento</p>
                  <p className="text-xs" style={{ color: 'oklch(0.48 0.01 240)' }}>Alterar nome, área, fábrica ou periodicidade</p>
                </div>
              </button>
              <button
                onClick={() => handleEscolherAcao('inativar')}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all hover:bg-white/5 text-left"
                style={{ border: '1px solid oklch(0.25 0.008 240)', color: isInativo ? 'oklch(0.72 0.18 145)' : 'oklch(0.72 0.18 60)' }}
              >
                {isInativo ? <Power size={15} /> : <PowerOff size={15} />}
                <div>
                  <p className="font-semibold">{isInativo ? 'Reativar Equipamento' : 'Inativar Equipamento'}</p>
                  <p className="text-xs" style={{ color: 'oklch(0.48 0.01 240)' }}>
                    {isInativo ? 'Repor o equipamento como ativo' : 'Marcar como inativo (não aparece nos alertas)'}
                  </p>
                </div>
              </button>
              <button
                onClick={() => handleEscolherAcao('eliminar')}
                className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all hover:bg-white/5 text-left"
                style={{ border: '1px solid oklch(0.62 0.22 25 / 0.4)', color: '#EF4444' }}
              >
                <Trash2 size={15} />
                <div>
                  <p className="font-semibold">Eliminar Equipamento</p>
                  <p className="text-xs" style={{ color: 'oklch(0.48 0.01 240)' }}>
                    {isCustom ? 'Remover permanentemente da base de dados' : 'Remover definitivamente do plano (não aparecerá em nenhuma lista)'}
                  </p>
                </div>
              </button>
            </div>
          )}

          {/* Passo 2: Código de acesso */}
          {passo === 'codigo' && (
            <div className="p-5 flex flex-col gap-4">
              <div className="flex items-center gap-2 p-3 rounded-lg" style={{ background: 'oklch(0.72 0.18 60 / 0.08)', border: '1px solid oklch(0.72 0.18 60 / 0.2)' }}>
                <Shield size={14} style={{ color: 'oklch(0.72 0.18 60)' }} />
                <p className="text-xs" style={{ color: 'oklch(0.75 0.12 60)' }}>Introduza o código de acesso para continuar.</p>
              </div>
              <div>
                <label style={labelStyle}>Código de Acesso</label>
                <div className="relative">
                  <input
                    type={mostrarCodigo ? 'text' : 'password'}
                    value={codigoAcesso}
                    onChange={(e) => { setCodigoAcesso(e.target.value); setErroAcesso(''); }}
                    onKeyDown={(e) => e.key === 'Enter' && handleValidarCodigo()}
                    placeholder="••••••••"
                    style={{ ...inputStyle, paddingRight: '36px' }}
                    autoFocus
                  />
                  <button type="button" onClick={() => setMostrarCodigo(v => !v)} className="absolute right-2.5 top-1/2 -translate-y-1/2" style={{ color: 'oklch(0.45 0.01 240)' }}>
                    {mostrarCodigo ? <EyeOff size={14} /> : <Eye size={14} />}
                  </button>
                </div>
                {erroAcesso && (
                  <p className="text-xs mt-1.5 flex items-center gap-1" style={{ color: '#EF4444' }}>
                    <AlertTriangle size={11} /> {erroAcesso}
                  </p>
                )}
              </div>
              <div className="flex gap-3">
                <button onClick={() => setPasso('menu')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                  Voltar
                </button>
                <button
                  onClick={handleValidarCodigo}
                  disabled={!codigoAcesso.trim()}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all"
                  style={{ background: codigoAcesso.trim() ? 'oklch(0.72 0.18 60)' : 'oklch(0.3 0.01 240)', color: codigoAcesso.trim() ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)' }}
                >
                  Continuar
                </button>
              </div>
            </div>
          )}

          {/* Passo 3a: Formulário de edição */}
          {passo === 'editar' && (
            <div className="p-5 flex flex-col gap-4">
              <div>
                <label style={labelStyle}>Código</label>
                <input type="text" value={codigo} onChange={e => setCodigo(e.target.value)} style={inputStyle} maxLength={32} disabled={!isCustom} />
                {!isCustom && <p className="text-xs mt-1" style={{ color: 'oklch(0.45 0.01 240)' }}>O código não pode ser alterado em equipamentos do plano base.</p>}
              </div>
              <div>
                <label style={labelStyle}>Designação</label>
                <input type="text" value={nomeEquip} onChange={e => setNomeEquip(e.target.value)} style={inputStyle} maxLength={256} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label style={labelStyle}><Factory size={10} className="inline mr-1" />Fábrica</label>
                  <select value={fabrica} onChange={e => handleFabricaChange(e.target.value)} style={{ ...inputStyle, cursor: 'pointer' }}>
                    {FABRICAS.map(f => <option key={f} value={f}>{f}</option>)}
                  </select>
                </div>
                <div>
                  <label style={labelStyle}>Área</label>
                  <select value={area} onChange={e => setArea(e.target.value)} style={{ ...inputStyle, cursor: 'pointer' }}>
                    {areasDaFabrica.length === 0
                      ? <option value="" disabled>Sem áreas</option>
                      : areasDaFabrica.map(a => <option key={a} value={a}>{a}</option>)
                    }
                  </select>
                </div>
              </div>
              <div>
                <label style={labelStyle}>Periodicidade</label>
                <select value={periodicidade} onChange={e => setPeriodicidade(e.target.value)} style={{ ...inputStyle, cursor: 'pointer' }}>
                  <option value="">— Sem periodicidade —</option>
                  {PERIODICIDADES.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Plano de Intervenção</label>
                <textarea
                  value={planoIntervencao}
                  onChange={e => setPlanoIntervencao(e.target.value)}
                  placeholder="Descreva as tarefas a realizar nesta manutenção..."
                  rows={4}
                  style={{ ...inputStyle, resize: 'vertical', lineHeight: '1.5' }}
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label style={labelStyle}>Modelo</label>
                  <input type="text" value={modelo} onChange={e => setModelo(e.target.value)} placeholder="Ex: Atlas Copco GA15" style={inputStyle} maxLength={256} />
                </div>
                <div>
                  <label style={labelStyle}>Nº Série</label>
                  <input type="text" value={numeroSerie} onChange={e => setNumeroSerie(e.target.value)} placeholder="Ex: SN-2024-00123" style={inputStyle} maxLength={128} />
                </div>
              </div>
              {erroAcesso && (
                <p className="text-xs flex items-center gap-1" style={{ color: '#EF4444' }}>
                  <AlertTriangle size={11} /> {erroAcesso}
                </p>
              )}
              <div className="flex gap-3">
                <button onClick={() => setPasso('codigo')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                  Voltar
                </button>
                <button
                  onClick={handleGuardarEdicao}
                  disabled={isPending || !nomeEquip.trim()}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
                  style={{ background: 'oklch(0.72 0.18 60)', color: 'oklch(0.1 0.006 240)' }}
                >
                  {isPending ? <Loader2 size={14} className="animate-spin" /> : <Edit2 size={14} />}
                  Guardar
                </button>
              </div>
            </div>
          )}

          {/* Passo 3b: Confirmação de eliminar/inativar */}
          {passo === 'confirmar' && (
            <div className="p-5 flex flex-col gap-4">
              <div
                className="flex items-start gap-3 p-3 rounded-lg"
                style={{
                  background: acaoSelecionada === 'eliminar' ? 'oklch(0.62 0.22 25 / 0.12)' : 'oklch(0.72 0.18 60 / 0.08)',
                  border: `1px solid ${acaoSelecionada === 'eliminar' ? 'oklch(0.62 0.22 25 / 0.4)' : 'oklch(0.72 0.18 60 / 0.2)'}`,
                }}
              >
                <AlertTriangle size={16} style={{ color: acaoSelecionada === 'eliminar' ? '#EF4444' : 'oklch(0.72 0.18 60)', flexShrink: 0, marginTop: 2 }} />
                <div>
                  <p className="text-sm font-semibold" style={{ color: acaoSelecionada === 'eliminar' ? '#EF4444' : 'oklch(0.82 0.16 60)' }}>
                    {acaoSelecionada === 'eliminar' ? 'Confirmar eliminação' : isInativo ? 'Confirmar reativação' : 'Confirmar inativação'}
                  </p>
                  <p className="text-xs mt-1" style={{ color: 'oklch(0.58 0.01 240)' }}>
                    {acaoSelecionada === 'eliminar'
                      ? isCustom
                        ? `O equipamento "${equipamento.equipamento}" será removido permanentemente.`
                        : `O equipamento "${equipamento.equipamento}" será eliminado definitivamente e não aparecerá em nenhuma lista. Esta ação não pode ser revertida.`
                      : isInativo
                        ? `O equipamento "${equipamento.equipamento}" será reativado.`
                        : `O equipamento "${equipamento.equipamento}" será marcado como inativo.`}
                  </p>
                </div>
              </div>
              {erroAcesso && (
                <p className="text-xs flex items-center gap-1" style={{ color: '#EF4444' }}>
                  <AlertTriangle size={11} /> {erroAcesso}
                </p>
              )}
              <div className="flex gap-3">
                <button onClick={() => setPasso('codigo')} className="flex-1 py-2 rounded-lg text-sm font-medium" style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
                  Cancelar
                </button>
                <button
                  onClick={handleConfirmar}
                  disabled={isPending}
                  className="flex-1 py-2 rounded-lg text-sm font-semibold flex items-center justify-center gap-2"
                  style={{ background: acaoSelecionada === 'eliminar' ? 'oklch(0.52 0.22 25)' : 'oklch(0.72 0.18 60)', color: 'oklch(0.98 0.005 240)' }}
                >
                  {isPending ? (
                    <Loader2 size={14} className="animate-spin" />
                  ) : acaoSelecionada === 'eliminar' ? (
                    <><Trash2 size={14} /> Eliminar definitivamente</>
                  ) : isInativo ? (
                    <><Power size={14} /> Reativar</>
                  ) : (
                    <><PowerOff size={14} /> Inativar</>
                  )}
                </button>
              </div>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
