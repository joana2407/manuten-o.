/*
 * ModalNovaArea — Modal para criar uma nova área de manutenção
 * Inclui selector de fábrica (Fábrica I / Fábrica II)
 */
import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, FolderPlus, Loader2, Factory } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';

const FABRICAS = ['Fábrica I', 'Fábrica II'] as const;
type Fabrica = typeof FABRICAS[number];

interface ModalNovaAreaProps {
  onFechar: () => void;
  onCriada: (nome: string) => void;
}

export function ModalNovaArea({ onFechar, onCriada }: ModalNovaAreaProps) {
  const [nome, setNome] = useState('');
  const [descricao, setDescricao] = useState('');
  const [fabrica, setFabrica] = useState<Fabrica>('Fábrica I');

  const criarArea = trpc.gestao.criarArea.useMutation({
    onSuccess: () => {
      toast.success(`Área "${nome}" criada com sucesso em ${fabrica}`);
      onCriada(nome);
      onFechar();
    },
    onError: (err) => {
      toast.error(`Erro ao criar área: ${err.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nome.trim()) return;
    criarArea.mutate({ nome: nome.trim(), descricao: descricao.trim() || undefined, fabrica });
  };

  const inputStyle = {
    background: 'oklch(0.14 0.006 240)',
    border: '1px solid oklch(0.28 0.008 240)',
    color: 'oklch(0.92 0.005 240)',
    borderRadius: '6px',
    padding: '8px 12px',
    fontSize: '13px',
    width: '100%',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.05em',
    color: 'oklch(0.55 0.01 240)',
    marginBottom: '6px',
    textTransform: 'uppercase' as const,
  };

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.7)' }}
        onClick={(e) => e.target === e.currentTarget && onFechar()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="w-full max-w-md mx-4 rounded-xl overflow-hidden"
          style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: '1px solid oklch(0.18 0.006 240)' }}
          >
            <div className="flex items-center gap-2">
              <FolderPlus size={18} style={{ color: 'oklch(0.82 0.16 60)' }} />
              <h2 className="font-semibold text-sm" style={{ color: 'oklch(0.92 0.005 240)' }}>
                Nova Área
              </h2>
            </div>
            <button
              onClick={onFechar}
              className="p-1 rounded hover:bg-white/10 transition-colors"
              style={{ color: 'oklch(0.55 0.01 240)' }}
            >
              <X size={16} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-4">
            {/* Selector de Fábrica */}
            <div>
              <label style={labelStyle}>
                <Factory size={11} className="inline mr-1" />
                Fábrica *
              </label>
              <div className="flex gap-2">
                {FABRICAS.map(f => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFabrica(f)}
                    className="flex-1 py-2 rounded-lg text-xs font-semibold transition-all"
                    style={{
                      background: fabrica === f ? 'oklch(0.72 0.18 60 / 0.2)' : 'oklch(0.14 0.006 240)',
                      border: `1px solid ${fabrica === f ? 'oklch(0.72 0.18 60 / 0.6)' : 'oklch(0.28 0.008 240)'}`,
                      color: fabrica === f ? 'oklch(0.82 0.16 60)' : 'oklch(0.62 0.01 240)',
                    }}
                  >
                    {f}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label style={labelStyle}>Nome da Área *</label>
              <input
                type="text"
                value={nome}
                onChange={(e) => setNome(e.target.value)}
                placeholder="Ex: F2: 01-Produção"
                style={inputStyle}
                autoFocus
                required
                maxLength={128}
              />
            </div>

            <div>
              <label style={labelStyle}>Descrição (opcional)</label>
              <textarea
                value={descricao}
                onChange={(e) => setDescricao(e.target.value)}
                placeholder="Descrição da área..."
                rows={2}
                style={{ ...inputStyle, resize: 'none' }}
                maxLength={512}
              />
            </div>

            <div className="flex gap-3 pt-1">
              <button
                type="button"
                onClick={onFechar}
                className="flex-1 py-2 rounded-lg text-sm font-medium transition-colors"
                style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!nome.trim() || criarArea.isPending}
                className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all flex items-center justify-center gap-2"
                style={{
                  background: nome.trim() ? 'oklch(0.72 0.18 60)' : 'oklch(0.3 0.01 240)',
                  color: nome.trim() ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)',
                  cursor: nome.trim() ? 'pointer' : 'not-allowed',
                }}
              >
                {criarArea.isPending ? <Loader2 size={14} className="animate-spin" /> : <FolderPlus size={14} />}
                Criar Área
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
