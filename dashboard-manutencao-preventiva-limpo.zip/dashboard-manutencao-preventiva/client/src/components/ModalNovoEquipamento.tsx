/*
 * ModalNovoEquipamento — Modal para adicionar um novo equipamento
 * Permite selecionar fábrica, área filtrada por fábrica,
 * e data da última intervenção (para cálculo automático da próxima manutenção)
 */
import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, PlusCircle, Loader2, Factory, Calendar, ArrowRight } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { calcularProxima } from '@/hooks/useRealizacoes';

const PERIODICIDADES = ['Mensal', 'Bimestral', 'Trimestral', 'Semestral', 'Anual', 'Semanal', 'Quinzenal'];
const FABRICAS = ['Fábrica I', 'Fábrica II'] as const;

function getFabricaDeArea(area: string, areasCustomFabrica: Record<string, string>): string {
  if (areasCustomFabrica[area]) return areasCustomFabrica[area];
  if (area.startsWith('F1:')) return 'Fábrica I';
  if (area.startsWith('F2:')) return 'Fábrica II';
  return 'Fábrica I';
}

function formatDatePT(iso: string): string {
  const [y, m, d] = iso.split('-');
  return `${d}/${m}/${y}`;
}

interface ModalNovoEquipamentoProps {
  areas: string[];
  areaInicial?: string;
  areasCustomFabrica?: Record<string, string>;
  onFechar: () => void;
  onCriado: () => void;
}

export function ModalNovoEquipamento({
  areas,
  areaInicial,
  areasCustomFabrica = {},
  onFechar,
  onCriado,
}: ModalNovoEquipamentoProps) {
  const fabricaInicial = areaInicial
    ? getFabricaDeArea(areaInicial, areasCustomFabrica)
    : 'Fábrica I';

  const [codigo, setCodigo] = useState('');
  const [equipamento, setEquipamento] = useState('');
  const [fabrica, setFabrica] = useState<string>(fabricaInicial);
  const [area, setArea] = useState(areaInicial ?? '');
  const [periodicidade, setPeriodicidade] = useState('Anual');
  const [estado, setEstado] = useState('Ativo');
  const [dataUltimaIntervencao, setDataUltimaIntervencao] = useState('');
  const [modelo, setModelo] = useState('');
  const [numeroSerie, setNumeroSerie] = useState('');
  const [planoIntervencao, setPlanoIntervencao] = useState('');

  // Filtrar áreas pela fábrica selecionada
  const areasDaFabrica = useMemo(() => {
    return areas.filter(a => getFabricaDeArea(a, areasCustomFabrica) === fabrica);
  }, [areas, fabrica, areasCustomFabrica]);

  // Calcular próxima manutenção em tempo real
  const proximaManutenção = useMemo(() => {
    if (!dataUltimaIntervencao) return null;
    return calcularProxima(dataUltimaIntervencao, periodicidade);
  }, [dataUltimaIntervencao, periodicidade]);

  const handleFabricaChange = (novaFabrica: string) => {
    setFabrica(novaFabrica);
    const primeiraArea = areas.find(a => getFabricaDeArea(a, areasCustomFabrica) === novaFabrica);
    setArea(primeiraArea ?? '');
  };

  const criarEquipamento = trpc.gestao.criarEquipamento.useMutation({
    onSuccess: () => {
      toast.success(`Equipamento "${equipamento}" adicionado com sucesso`);
      onCriado();
      onFechar();
    },
    onError: (err) => {
      toast.error(`Erro ao criar equipamento: ${err.message}`);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!codigo.trim() || !equipamento.trim() || !area) return;
    criarEquipamento.mutate({
      codigo: codigo.trim(),
      equipamento: equipamento.trim(),
      area,
      periodicidade,
      estado,
      dataUltimaIntervencao: dataUltimaIntervencao || undefined,
      modelo: modelo.trim() || undefined,
      numeroSerie: numeroSerie.trim() || undefined,
      planoIntervencao: planoIntervencao.trim() || undefined,
    });
  };

  const inputStyle = {
    background: 'oklch(0.14 0.006 240)',
    border: '1px solid oklch(0.28 0.008 240)',
    color: 'oklch(0.92 0.005 240)',
    borderRadius: '6px',
    padding: '8px 12px',
    fontSize: '13px',
    width: '100%',
    outline: 'none',
  };

  const labelStyle = {
    display: 'block',
    fontSize: '11px',
    fontWeight: 600,
    letterSpacing: '0.05em',
    color: 'oklch(0.55 0.01 240)',
    marginBottom: '6px',
    textTransform: 'uppercase' as const,
  };

  const isValid = codigo.trim() && equipamento.trim() && area;

  return (
    <AnimatePresence>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center"
        style={{ background: 'rgba(0,0,0,0.7)' }}
        onClick={(e) => e.target === e.currentTarget && onFechar()}
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
          className="w-full max-w-lg mx-4 rounded-xl overflow-hidden"
          style={{ background: 'oklch(0.1 0.006 240)', border: '1px solid oklch(0.22 0.008 240)' }}
        >
          {/* Header */}
          <div
            className="flex items-center justify-between px-5 py-4"
            style={{ borderBottom: '1px solid oklch(0.18 0.006 240)' }}
          >
            <div className="flex items-center gap-2">
              <PlusCircle size={18} style={{ color: 'oklch(0.82 0.16 60)' }} />
              <h2 className="font-semibold text-sm" style={{ color: 'oklch(0.92 0.005 240)' }}>
                Novo Equipamento
              </h2>
            </div>
            <button
              onClick={onFechar}
              className="p-1 rounded hover:bg-white/10 transition-colors"
              style={{ color: 'oklch(0.55 0.01 240)' }}
            >
              <X size={16} />
            </button>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="p-5 flex flex-col gap-4">
            {/* Código + Estado */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label style={labelStyle}>Código *</label>
                <input
                  type="text"
                  value={codigo}
                  onChange={(e) => setCodigo(e.target.value)}
                  placeholder="Ex: 01050"
                  style={inputStyle}
                  autoFocus
                  required
                  maxLength={32}
                />
              </div>
              <div>
                <label style={labelStyle}>Estado</label>
                <select
                  value={estado}
                  onChange={(e) => setEstado(e.target.value)}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                >
                  <option value="Ativo">Ativo</option>
                  <option value="Inativo">Inativo</option>
                </select>
              </div>
            </div>

            {/* Designação */}
            <div>
              <label style={labelStyle}>Designação do Equipamento *</label>
              <input
                type="text"
                value={equipamento}
                onChange={(e) => setEquipamento(e.target.value)}
                placeholder="Ex: Compressor de Ar"
                style={inputStyle}
                required
                maxLength={256}
              />
            </div>

            {/* Fábrica + Área */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label style={labelStyle}>
                  <Factory size={10} className="inline mr-1" />
                  Fábrica *
                </label>
                <select
                  value={fabrica}
                  onChange={(e) => handleFabricaChange(e.target.value)}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                  required
                >
                  {FABRICAS.map((f) => (
                    <option key={f} value={f}>{f}</option>
                  ))}
                </select>
              </div>
              <div>
                <label style={labelStyle}>Área *</label>
                <select
                  value={area}
                  onChange={(e) => setArea(e.target.value)}
                  style={{ ...inputStyle, cursor: 'pointer' }}
                  required
                >
                  {areasDaFabrica.length === 0 ? (
                    <option value="" disabled>Sem áreas disponíveis</option>
                  ) : (
                    areasDaFabrica.map((a) => (
                      <option key={a} value={a}>{a}</option>
                    ))
                  )}
                </select>
              </div>
            </div>

            {/* Periodicidade */}
            <div>
              <label style={labelStyle}>Periodicidade</label>
              <select
                value={periodicidade}
                onChange={(e) => setPeriodicidade(e.target.value)}
                style={{ ...inputStyle, cursor: 'pointer' }}
              >
                {PERIODICIDADES.map((p) => (
                  <option key={p} value={p}>{p}</option>
                ))}
              </select>
            </div>

            {/* Modelo + Nº Série */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label style={labelStyle}>Modelo</label>
                <input
                  type="text"
                  value={modelo}
                  onChange={(e) => setModelo(e.target.value)}
                  placeholder="Ex: Atlas Copco GA15"
                  style={inputStyle}
                  maxLength={256}
                />
              </div>
              <div>
                <label style={labelStyle}>Nº Série</label>
                <input
                  type="text"
                  value={numeroSerie}
                  onChange={(e) => setNumeroSerie(e.target.value)}
                  placeholder="Ex: SN-2024-00123"
                  style={inputStyle}
                  maxLength={128}
                />
              </div>
            </div>

            {/* Data da última intervenção */}
            <div>
              <label style={labelStyle}>
                <Calendar size={10} className="inline mr-1" />
                Data da Última Intervenção
                <span style={{ color: 'oklch(0.45 0.01 240)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}> (opcional)</span>
              </label>
              <input
                type="date"
                value={dataUltimaIntervencao}
                onChange={(e) => setDataUltimaIntervencao(e.target.value)}
                max={new Date().toISOString().split('T')[0]}
                style={{
                  ...inputStyle,
                  cursor: 'pointer',
                  colorScheme: 'dark',
                }}
              />
              {/* Pré-visualização da próxima manutenção */}
              {proximaManutenção && (
                <div
                  className="flex items-center gap-2 mt-2 px-3 py-2 rounded-lg"
                  style={{ background: 'oklch(0.72 0.18 60 / 0.08)', border: '1px solid oklch(0.72 0.18 60 / 0.25)' }}
                >
                  <Calendar size={12} style={{ color: 'oklch(0.72 0.18 60)', flexShrink: 0 }} />
                  <span className="text-xs" style={{ color: 'oklch(0.65 0.01 240)' }}>
                    Próxima manutenção:
                  </span>
                  <ArrowRight size={11} style={{ color: 'oklch(0.45 0.01 240)', flexShrink: 0 }} />
                  <span className="text-xs font-semibold font-mono" style={{ color: 'oklch(0.82 0.16 60)' }}>
                    {formatDatePT(proximaManutenção)}
                  </span>
                  <span className="text-xs ml-auto" style={{ color: 'oklch(0.48 0.01 240)' }}>
                    ({periodicidade.toLowerCase()})
                  </span>
                </div>
              )}
              {dataUltimaIntervencao && !proximaManutenção && (
                <p className="text-xs mt-1.5" style={{ color: 'oklch(0.52 0.01 240)' }}>
                  A periodicidade selecionada não permite calcular a próxima data.
                </p>
              )}
            </div>

            {/* Plano de Intervenção */}
            <div>
              <label style={labelStyle}>Plano de Intervenção
                <span style={{ color: 'oklch(0.45 0.01 240)', fontWeight: 400, textTransform: 'none', letterSpacing: 0 }}> (opcional)</span>
              </label>
              <textarea
                value={planoIntervencao}
                onChange={(e) => setPlanoIntervencao(e.target.value)}
                placeholder="Descreva as tarefas a realizar na intervenção..."
                rows={4}
                style={{
                  ...inputStyle,
                  resize: 'vertical',
                  minHeight: '80px',
                  fontFamily: 'inherit',
                  lineHeight: '1.5',
                }}
              />
            </div>

            {/* Botões */}
            <div className="flex gap-3 pt-1">
              <button
                type="button"
                onClick={onFechar}
                className="flex-1 py-2 rounded-lg text-sm font-medium transition-colors"
                style={{ background: 'oklch(0.18 0.006 240)', color: 'oklch(0.65 0.01 240)', border: '1px solid oklch(0.25 0.008 240)' }}
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!isValid || criarEquipamento.isPending}
                className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all flex items-center justify-center gap-2"
                style={{
                  background: isValid ? 'oklch(0.72 0.18 60)' : 'oklch(0.3 0.01 240)',
                  color: isValid ? 'oklch(0.1 0.006 240)' : 'oklch(0.45 0.01 240)',
                  cursor: isValid ? 'pointer' : 'not-allowed',
                }}
              >
                {criarEquipamento.isPending ? <Loader2 size={14} className="animate-spin" /> : <PlusCircle size={14} />}
                Adicionar Equipamento
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
