/*
 * GraficoDonut — Distribuição de estados (vencido/próximo/em dia/inativo)
 */
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { ESTADO_COLORS, ESTADO_LABELS } from '@/lib/utils';
import type { EstadoPrazo } from '@/lib/types';

interface GraficoDonutProps {
  vencidos: number;
  proximos: number;
  em_dia: number;
  inativos: number;
  sem_periodicidade: number;
}

const CustomTooltip = ({ active, payload }: any) => {
  if (!active || !payload?.length) return null;
  const p = payload[0];
  return (
    <div className="rounded-lg p-3 text-xs" style={{ background: 'oklch(0.13 0.007 240)', border: '1px solid oklch(0.25 0.008 240)' }}>
      <span className="flex items-center gap-2" style={{ color: p.payload.color }}>
        <span className="w-2 h-2 rounded-full" style={{ background: p.payload.color }} />
        {p.name}: <span className="font-mono font-semibold">{p.value}</span>
      </span>
    </div>
  );
};

export function GraficoDonut({ vencidos, proximos, em_dia, inativos, sem_periodicidade }: GraficoDonutProps) {
  const data = [
    { name: ESTADO_LABELS.vencido, value: vencidos, color: ESTADO_COLORS.vencido },
    { name: ESTADO_LABELS.proximo, value: proximos, color: ESTADO_COLORS.proximo },
    { name: ESTADO_LABELS.em_dia, value: em_dia, color: ESTADO_COLORS.em_dia },
    { name: ESTADO_LABELS.inativo, value: inativos, color: ESTADO_COLORS.inativo },
    { name: ESTADO_LABELS.sem_periodicidade, value: sem_periodicidade, color: ESTADO_COLORS.sem_periodicidade },
  ].filter(d => d.value > 0);

  const total = data.reduce((s, d) => s + d.value, 0);

  return (
    <div className="rounded-lg p-4" style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}>
      <h3 className="text-sm font-semibold mb-4 uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>
        Distribuição de Estados
      </h3>
      <div className="relative">
        <ResponsiveContainer width="100%" height={220}>
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={90}
              paddingAngle={2}
              dataKey="value"
              strokeWidth={0}
            >
              {data.map((entry, i) => (
                <Cell key={i} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
            <Legend
              wrapperStyle={{ fontSize: 11, color: 'oklch(0.65 0.01 240)' }}
              formatter={(value) => <span style={{ color: 'oklch(0.65 0.01 240)' }}>{value}</span>}
            />
          </PieChart>
        </ResponsiveContainer>
        {/* Total no centro */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none" style={{ paddingBottom: 36 }}>
          <div className="text-center">
            <div className="font-mono text-2xl font-semibold" style={{ color: 'oklch(0.88 0.005 240)' }}>{total}</div>
            <div className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>total</div>
          </div>
        </div>
      </div>
    </div>
  );
}
