import { useCallback, useEffect, useState } from "react";

type UseAuthOptions = {
  redirectOnUnauthenticated?: boolean;
  redirectPath?: string;
};

type LocalSession = {
  id?: string;
  nome?: string;
  name?: string;
  email?: string | null;
  nomeUtilizador?: string;
  funcao?: string;
};

function readSession(): LocalSession | null {
  if (typeof window === "undefined") return null;
  try {
    const value = sessionStorage.getItem("app_sessao");
    return value ? (JSON.parse(value) as LocalSession) : null;
  } catch {
    return null;
  }
}

export function useAuth(options?: UseAuthOptions) {
  const { redirectOnUnauthenticated = false, redirectPath = "/acesso" } = options ?? {};
  const [user, setUser] = useState<LocalSession | null>(() => readSession());

  useEffect(() => {
    const refresh = () => setUser(readSession());
    window.addEventListener("storage", refresh);
    window.addEventListener("focus", refresh);
    return () => {
      window.removeEventListener("storage", refresh);
      window.removeEventListener("focus", refresh);
    };
  }, []);

  useEffect(() => {
    if (redirectOnUnauthenticated && !user && window.location.pathname !== redirectPath) {
      window.location.href = redirectPath;
    }
  }, [redirectOnUnauthenticated, redirectPath, user]);

  const logout = useCallback(async () => {
    sessionStorage.removeItem("app_sessao");
    sessionStorage.removeItem("validador_sessao");
    setUser(null);
  }, []);

  return {
    user,
    loading: false,
    error: null,
    isAuthenticated: Boolean(user),
    refresh: () => setUser(readSession()),
    logout,
  };
}
