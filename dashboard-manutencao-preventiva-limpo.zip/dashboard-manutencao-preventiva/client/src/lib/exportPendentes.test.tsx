import { describe, expect, it } from 'vitest';
import type { Equipamento } from '@/lib/types';
import { gerarCsvPendentes, prepararPendentesParaExportacao, selecionarPendentes } from './exportPendentes';

const equipamento = (overrides: Partial<Equipamento>): Equipamento => ({
  area: 'F1: 04-Serviços',
  codigo: '04010',
  equipamento: 'Detetores de incêndios',
  estado: 'ativo',
  periodicidade: 'Anual',
  periodicidade_norm: 'anual',
  proxima_manutencao: '2026-01-01',
  estado_prazo: 'vencido',
  dias_ate_vencimento: -10,
  fabrica: 'Fábrica I',
  planoIntervencao: 'Verificar central e testar sinalização',
  ...overrides,
});

describe('exportação de pendentes', () => {
  it('seleciona apenas vencidos e próximos 30 dias', () => {
    const resultado = selecionarPendentes([
      equipamento({ estado_prazo: 'vencido' }),
      equipamento({ codigo: '05001', estado_prazo: 'proximo', dias_ate_vencimento: 5 }),
      equipamento({ codigo: '06001', estado_prazo: 'em_dia', dias_ate_vencimento: 90 }),
      equipamento({ codigo: '07001', estado_prazo: 'inativo', dias_ate_vencimento: null }),
    ]);
    expect(resultado.map(item => item.codigo)).toEqual(['04010', '05001']);
  });

  it('gera as colunas pedidas, incluindo a data da próxima manutenção', () => {
    const linhas = prepararPendentesParaExportacao([equipamento({})]);
    expect(linhas[0]).toMatchObject({
      fabrica: 'Fábrica I',
      zona: '04-Serviços',
      equipamento: 'Detetores de incêndios',
      tarefa: 'Verificar central e testar sinalização',
      data: '2026-01-01',
    });
    const csv = gerarCsvPendentes([equipamento({})]);
    expect(csv).toContain('Fábrica');
    expect(csv).toContain('Zona');
    expect(csv).toContain('Equipamento');
    expect(csv).toContain('Tarefa a executar');
    expect(csv).toContain('Data');
    expect(csv).toContain('2026-01-01');
  });
});
