export type EstadoPrazo = 'vencido' | 'proximo' | 'em_dia' | 'inativo' | 'sem_periodicidade';

export interface Equipamento {
  area: string;
  codigo: string;
  equipamento: string;
  estado: string;
  periodicidade: string;
  periodicidade_norm: string;
  proxima_manutencao: string | null;
  estado_prazo: EstadoPrazo;
  dias_ate_vencimento: number | null;
  fabrica?: string;   // Fábrica derivada da área (ex: 'Fábrica I', 'Fábrica II')
  // Campos extra para equipamentos custom (criados pelo utilizador)
  id?: string;        // ID da BD (apenas equipamentos custom)
  isCustom?: boolean; // true = criado pelo utilizador, false/undefined = do JSON
  modelo?: string;    // Modelo do equipamento
  numeroSerie?: string; // Número de série do equipamento
  planoIntervencao?: string; // Plano de intervenção (tarefas a realizar)
}

export interface ResumoArea {
  area: string;
  total: number;
  ativos: number;
  vencidos: number;
  proximos: number;
  em_dia: number;
  inativos: number;
  sem_periodicidade: number;
}

export interface ResumoMes {
  label: string;
  mes: number;
  total: number;
  vencidos: number;
  proximos: number;
  em_dia: number;
}

export interface ResumoPeriodo {
  periodo: string;
  total: number;
}

export interface DashboardData {
  gerado_em: string;
  data_base: string;
  hoje: string;
  resumo: {
    total: number;
    ativos: number;
    vencidos: number;
    proximos: number;
    em_dia: number;
    inativos: number;
  };
  equipamentos: Equipamento[];
  por_area: ResumoArea[];
  por_mes: ResumoMes[];
  por_periodo: ResumoPeriodo[];
}
