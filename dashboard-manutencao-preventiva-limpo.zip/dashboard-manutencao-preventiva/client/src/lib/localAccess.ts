import { obterPerfilPorNome, type PerfilAcesso } from "@shared/access";

export type UtilizadorLocal = {
  id: string;
  nome: string;
  nomeUtilizador: string;
  pin: string;
  perfil: PerfilAcesso;
  funcao: string;
  podeRegistar: boolean;
  podeValidar: boolean;
  podeGerir: boolean;
  podeGerirEquipamentos: boolean;
  podeGerirPins: boolean;
  podeGerirUtilizadores: boolean;
  ativo: boolean;
  criadoEm: string;
};

const STORAGE_KEY = "manutencao_utilizadores_mock_v1";

const utilizadoresIniciais: UtilizadorLocal[] = [
  { nome: "Vítor Morgado", nomeUtilizador: "vitor.morgado", pin: "0000" },
  { nome: "Rafael Ramos", nomeUtilizador: "rafael.ramos", pin: "0000" },
  { nome: "Joana Pina", nomeUtilizador: "joana.pina", pin: "1709" },
  { nome: "Marco Monteiro", nomeUtilizador: "marco.monteiro", pin: "0205" },
  { nome: "Alfredo Silva", nomeUtilizador: "alfredo.silva", pin: "0206" },
  { nome: "Nuno Ventura", nomeUtilizador: "nuno.ventura", pin: "0000" },
  { nome: "Olga Baptista", nomeUtilizador: "olga.baptista", pin: "0000" },
  { nome: "Normélia Pais", nomeUtilizador: "normelia.pais", pin: "0000" },
  { nome: "Gestão", nomeUtilizador: "gestao", pin: "2403" },
].map((utilizador, index) => {
  const perfil = obterPerfilPorNome(utilizador.nome);
  return {
    ...utilizador,
    id: `mock-${index + 1}`,
    ...perfil,
    ativo: true,
    criadoEm: new Date().toISOString(),
  };
});

function disponivel() {
  return typeof window !== "undefined" && typeof window.localStorage !== "undefined";
}

function clonar(utilizadores: UtilizadorLocal[]) {
  return utilizadores.map(utilizador => ({ ...utilizador }));
}

export function lerUtilizadoresLocais(): UtilizadorLocal[] {
  if (!disponivel()) return clonar(utilizadoresIniciais);
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      guardarUtilizadoresLocais(utilizadoresIniciais);
      return clonar(utilizadoresIniciais);
    }
    const parsed = JSON.parse(raw) as unknown;
    if (!Array.isArray(parsed)) throw new Error("Formato inválido");
    return parsed
      .filter(item => item && typeof item === "object" && "nomeUtilizador" in item)
      .map(item => {
        const atual = item as Partial<UtilizadorLocal>;
        const perfil = obterPerfilPorNome(atual.nome ?? "");
        return { ...perfil, ...atual, podeGerirEquipamentos: atual.podeGerirEquipamentos ?? perfil.podeGerirEquipamentos } as UtilizadorLocal;
      });
  } catch {
    guardarUtilizadoresLocais(utilizadoresIniciais);
    return clonar(utilizadoresIniciais);
  }
}

export function guardarUtilizadoresLocais(utilizadores: UtilizadorLocal[]) {
  if (disponivel()) window.localStorage.setItem(STORAGE_KEY, JSON.stringify(utilizadores));
}

export function listarUtilizadoresLocais(opcoes?: { apenasAtivos?: boolean; apenasGestaoPins?: boolean }) {
  let utilizadores = lerUtilizadoresLocais();
  if (opcoes?.apenasAtivos) utilizadores = utilizadores.filter(utilizador => utilizador.ativo);
  if (opcoes?.apenasGestaoPins) utilizadores = utilizadores.filter(utilizador => utilizador.podeGerirUtilizadores);
  return clonar(utilizadores);
}

export function autenticarUtilizadorLocal(nomeUtilizador: string, pin: string) {
  const utilizador = lerUtilizadoresLocais().find(item => item.ativo && item.nomeUtilizador === nomeUtilizador && item.pin === pin);
  if (!utilizador) throw new Error("Credenciais inválidas");
  return { ...utilizador };
}

export function criarUtilizadorLocal(nome: string, nomeUtilizador: string, pin: string) {
  const utilizadores = lerUtilizadoresLocais();
  if (utilizadores.some(item => item.nomeUtilizador.toLowerCase() === nomeUtilizador.toLowerCase())) {
    throw new Error("Já existe um utilizador com esse identificador.");
  }
  const perfil = obterPerfilPorNome(nome);
  const novo: UtilizadorLocal = {
    id: `mock-${crypto.randomUUID?.() ?? Date.now()}`,
    nome,
    nomeUtilizador,
    pin,
    ...perfil,
    ativo: true,
    criadoEm: new Date().toISOString(),
  };
  guardarUtilizadoresLocais([...utilizadores, novo]);
  return novo;
}

export function alterarPinUtilizadorLocal(id: string, pin: string) {
  const utilizadores = lerUtilizadoresLocais();
  const atualizados = utilizadores.map(item => item.id === id ? { ...item, pin } : item);
  if (!atualizados.some(item => item.id === id)) throw new Error("Utilizador não encontrado.");
  guardarUtilizadoresLocais(atualizados);
}

export function alterarEstadoUtilizadorLocal(id: string, ativo: boolean) {
  const utilizadores = lerUtilizadoresLocais();
  guardarUtilizadoresLocais(utilizadores.map(item => item.id === id ? { ...item, ativo } : item));
}

export function eliminarUtilizadorLocal(id: string) {
  const utilizadores = lerUtilizadoresLocais();
  guardarUtilizadoresLocais(utilizadores.filter(item => item.id !== id));
}
