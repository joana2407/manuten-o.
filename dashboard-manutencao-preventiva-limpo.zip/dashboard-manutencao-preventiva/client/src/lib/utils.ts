import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { EstadoPrazo } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const ESTADO_LABELS: Record<EstadoPrazo, string> = {
  vencido: 'Vencido',
  proximo: 'Próximo (30 dias)',
  em_dia: 'Em dia',
  inativo: 'Inativo',
  sem_periodicidade: 'Sem periodicidade',
};

export const ESTADO_BADGE_CLASS: Record<EstadoPrazo, string> = {
  vencido: 'badge-vencido',
  proximo: 'badge-proximo',
  em_dia: 'badge-em-dia',
  inativo: 'badge-inativo',
  sem_periodicidade: 'badge-sem-periodicidade',
};

export const ESTADO_COLORS: Record<EstadoPrazo, string> = {
  vencido: '#EF4444',
  proximo: '#F59E0B',
  em_dia: '#10B981',
  inativo: '#6B7280',
  sem_periodicidade: '#4B5563',
};

export const MESES_PT = ['Jan','Fev','Mar','Abr','Mai','Jun','Jul','Ago','Set','Out','Nov','Dez'];

export function formatDate(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('pt-PT', { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function mesAtual(): number {
  return new Date().getMonth() + 1;
}

export function nomesMesAtual(): string {
  return MESES_PT[mesAtual() - 1];
}
