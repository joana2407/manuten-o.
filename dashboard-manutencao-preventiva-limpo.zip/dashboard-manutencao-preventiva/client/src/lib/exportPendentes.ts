import type { Equipamento } from '@/lib/types';

export interface PendenteExportacao {
  estado: 'Vencido' | 'Próximo (30 dias)';
  fabrica: string;
  zona: string;
  equipamento: string;
  tarefa: string;
  codigo: string;
  data: string;
}

export function selecionarPendentes(equipamentos: Equipamento[]): Equipamento[] {
  return equipamentos
    .filter(e => e.estado_prazo === 'vencido' || e.estado_prazo === 'proximo')
    .sort((a, b) => {
      if (a.estado_prazo !== b.estado_prazo) return a.estado_prazo === 'vencido' ? -1 : 1;
      return (a.dias_ate_vencimento ?? Number.MAX_SAFE_INTEGER) - (b.dias_ate_vencimento ?? Number.MAX_SAFE_INTEGER);
    });
}

function escaparCsv(valor: string): string {
  return `"${valor.replace(/"/g, '""')}"`;
}

function zonaDaArea(area: string): string {
  return area.replace(/^F\d:\s*/i, '').trim() || area;
}

function tarefaDoEquipamento(equipamento: Equipamento): string {
  const plano = equipamento.planoIntervencao?.trim();
  return plano || `Executar manutenção preventiva (${equipamento.periodicidade || 'periodicidade definida no plano'})`;
}

export function prepararPendentesParaExportacao(equipamentos: Equipamento[]): PendenteExportacao[] {
  return selecionarPendentes(equipamentos).map(equipamento => ({
    estado: equipamento.estado_prazo === 'vencido' ? 'Vencido' : 'Próximo (30 dias)',
    fabrica: equipamento.fabrica || 'Não definida',
    zona: zonaDaArea(equipamento.area),
    equipamento: equipamento.equipamento,
    tarefa: tarefaDoEquipamento(equipamento),
    codigo: equipamento.codigo,
    data: equipamento.proxima_manutencao || '',
  }));
}

export function gerarCsvPendentes(equipamentos: Equipamento[]): string {
  const linhas = prepararPendentesParaExportacao(equipamentos);
  const cabecalho = ['Estado', 'Fábrica', 'Zona', 'Equipamento', 'Tarefa a executar', 'Código', 'Data'];
  const conteudo = [
    cabecalho,
    ...linhas.map(linha => [linha.estado, linha.fabrica, linha.zona, linha.equipamento, linha.tarefa, linha.codigo, linha.data]),
  ];
  return `\uFEFF${conteudo.map(colunas => colunas.map(valor => escaparCsv(valor)).join(';')).join('\r\n')}\r\n`;
}

export function descarregarCsvPendentes(equipamentos: Equipamento[], data = new Date()): number {
  const blob = new Blob([gerarCsvPendentes(equipamentos)], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = `lista-pendentes-${data.toISOString().slice(0, 10)}.csv`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  return selecionarPendentes(equipamentos).length;
}
