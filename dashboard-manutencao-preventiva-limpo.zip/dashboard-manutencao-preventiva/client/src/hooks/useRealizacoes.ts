/*
 * useRealizacoes — Gere o registo e histórico de realizações de manutenção
 * Estrutura: cada equipamento tem uma lista de intervenções ordenadas por data desc
 * Persistência: localStorage (chave "manutencao_realizacoes_v2")
 * Recálculo: próxima manutenção = data da última intervenção + periodicidade
 */
import { useState, useCallback, useMemo } from 'react';

const STORAGE_KEY = 'manutencao_realizacoes_v2';

export interface Intervencao {
  id: string;                  // nanoid único
  dataRealizacao: string;      // ISO date YYYY-MM-DD
  intervencao: string;         // descrição da intervenção realizada
  materialGasto: string;       // material gasto na intervenção
  responsavel: string;         // responsável pela intervenção
  registadoEm: string;         // ISO datetime
}

export interface RegistoEquipamento {
  codigo: string;
  area: string;
  intervencoes: Intervencao[]; // ordenadas por data desc (mais recente primeiro)
}

// Chave única por equipamento
export function chaveEquipamento(codigo: string, area: string): string {
  return `${area}::${codigo}`;
}

// Calcula a próxima manutenção a partir de uma data de realização e periodicidade
export function calcularProxima(dataRealizacao: string, periodicidadeNorm: string): string | null {
  const norm = periodicidadeNorm.toLowerCase();
  const base = new Date(dataRealizacao + 'T00:00:00');

  // Periodicidades em dias (semanal, quinzenal)
  const diasMap: Record<string, number> = {
    semanal: 7,
    quinzenal: 15,
  };
  if (diasMap[norm]) {
    const result = new Date(base);
    result.setDate(result.getDate() + diasMap[norm]);
    return result.toISOString().split('T')[0];
  }

  // Periodicidades em meses
  const mesesMap: Record<string, number> = {
    mensal: 1,
    bimestral: 2,
    trimestral: 3,
    semestral: 6,
    anual: 12,
  };
  const meses = mesesMap[norm];
  if (!meses) return null;

  const totalMeses = base.getMonth() + meses;
  const year = base.getFullYear() + Math.floor(totalMeses / 12);
  const month = totalMeses % 12;
  const day = Math.min(base.getDate(), new Date(year, month + 1, 0).getDate());
  return new Date(year, month, day).toISOString().split('T')[0];
}

// Calcula o estado do prazo a partir da próxima manutenção
export function calcularEstadoPrazo(proximaIso: string | null): string {
  if (!proximaIso) return 'sem_periodicidade';
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const proxima = new Date(proximaIso + 'T00:00:00');
  const diff = Math.floor((proxima.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
  if (diff < 0) return 'vencido';
  if (diff <= 30) return 'proximo';
  return 'em_dia';
}

// Gera um ID simples baseado em timestamp + random
function gerarId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function carregarDoStorage(): Record<string, RegistoEquipamento> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

function guardarNoStorage(registos: Record<string, RegistoEquipamento>) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(registos));
  } catch { /* silencioso */ }
}

export function useRealizacoes() {
  const [registos, setRegistos] = useState<Record<string, RegistoEquipamento>>(carregarDoStorage);

  // Adicionar nova intervenção (sempre cria novo registo no histórico)
  const adicionarIntervencao = useCallback((
    codigo: string,
    area: string,
    dataRealizacao: string,
    intervencao: string,
    materialGasto: string,
    responsavel: string
  ) => {
    const chave = chaveEquipamento(codigo, area);
    const novaIntervencao: Intervencao = {
      id: gerarId(),
      dataRealizacao,
      intervencao,
      materialGasto,
      responsavel,
      registadoEm: new Date().toISOString(),
    };
    setRegistos(prev => {
      const existente = prev[chave];
      const novasIntervencoes = existente
        ? [novaIntervencao, ...existente.intervencoes]
        : [novaIntervencao];
      // Ordenar por data desc
      novasIntervencoes.sort((a, b) => b.dataRealizacao.localeCompare(a.dataRealizacao));
      const atualizado = {
        ...prev,
        [chave]: { codigo, area, intervencoes: novasIntervencoes },
      };
      guardarNoStorage(atualizado);
      return atualizado;
    });
  }, []);

  // Remover uma intervenção específica do histórico
  const removerIntervencao = useCallback((codigo: string, area: string, id: string) => {
    const chave = chaveEquipamento(codigo, area);
    setRegistos(prev => {
      const existente = prev[chave];
      if (!existente) return prev;
      const novasIntervencoes = existente.intervencoes.filter(i => i.id !== id);
      let atualizado: Record<string, RegistoEquipamento>;
      if (novasIntervencoes.length === 0) {
        atualizado = { ...prev };
        delete atualizado[chave];
      } else {
        atualizado = { ...prev, [chave]: { ...existente, intervencoes: novasIntervencoes } };
      }
      guardarNoStorage(atualizado);
      return atualizado;
    });
  }, []);

  // Obter o registo completo de um equipamento
  const obterRegisto = useCallback((codigo: string, area: string): RegistoEquipamento | null => {
    return registos[chaveEquipamento(codigo, area)] ?? null;
  }, [registos]);

  // Obter a última intervenção (para recálculo de estado)
  const obterUltimaIntervencao = useCallback((codigo: string, area: string): Intervencao | null => {
    const registo = registos[chaveEquipamento(codigo, area)];
    if (!registo || registo.intervencoes.length === 0) return null;
    return registo.intervencoes[0]; // já ordenado desc
  }, [registos]);

  const totalEquipamentosComRegisto = useMemo(
    () => Object.keys(registos).length,
    [registos]
  );

  const totalIntervencoes = useMemo(
    () => Object.values(registos).reduce((s, r) => s + r.intervencoes.length, 0),
    [registos]
  );

  // Lista de responsáveis únicos com contagem de intervenções
  const listaResponsaveis = useMemo((): { nome: string; total: number }[] => {
    const mapa: Record<string, number> = {};
    Object.values(registos).forEach(r => {
      r.intervencoes.forEach(i => {
        const nome = i.responsavel?.trim();
        if (nome) mapa[nome] = (mapa[nome] ?? 0) + 1;
      });
    });
    return Object.entries(mapa)
      .map(([nome, total]) => ({ nome, total }))
      .sort((a, b) => a.nome.localeCompare(b.nome, 'pt'));
  }, [registos]);

  // Mapa: chave do equipamento → set de responsáveis que intervieram
  const responsaveisPorEquipamento = useMemo((): Record<string, Set<string>> => {
    const mapa: Record<string, Set<string>> = {};
    Object.entries(registos).forEach(([chave, r]) => {
      const nomes = new Set<string>();
      r.intervencoes.forEach(i => { if (i.responsavel?.trim()) nomes.add(i.responsavel.trim()); });
      if (nomes.size > 0) mapa[chave] = nomes;
    });
    return mapa;
  }, [registos]);

  return {
    registos,
    adicionarIntervencao,
    removerIntervencao,
    obterRegisto,
    listaResponsaveis,
    responsaveisPorEquipamento,
    obterUltimaIntervencao,
    totalEquipamentosComRegisto,
    totalIntervencoes,
  };
}
