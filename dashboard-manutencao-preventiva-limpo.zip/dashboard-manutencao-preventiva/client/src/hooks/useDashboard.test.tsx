import { describe, expect, it } from 'vitest';
import { aplicarOverrides, normalizarEstadoEPrazo } from './useDashboard';
import type { Equipamento } from '@/lib/types';

const equipamentoBase: Equipamento = {
  area: 'F1: 04-Serviços',
  codigo: '04010',
  equipamento: 'Detetores de incêndios',
  estado: 'ativo',
  periodicidade: 'Anual',
  periodicidade_norm: 'anual',
  proxima_manutencao: '2000-01-01',
  estado_prazo: 'em_dia',
  dias_ate_vencimento: 999,
};

describe('normalizarEstadoEPrazo', () => {
  it('corrige um equipamento vencido mesmo que o estado vindo do plano esteja desatualizado', () => {
    const resultado = normalizarEstadoEPrazo(equipamentoBase);
    expect(resultado.estado_prazo).toBe('vencido');
    expect(resultado.dias_ate_vencimento).toBeLessThan(0);
  });

  it('mantém equipamentos inativos fora dos estados de prazo', () => {
    const resultado = normalizarEstadoEPrazo({
      ...equipamentoBase,
      estado: 'Inativo',
      estado_prazo: 'vencido',
      dias_ate_vencimento: -100,
    });
    expect(resultado.estado_prazo).toBe('inativo');
    expect(resultado.dias_ate_vencimento).toBeNull();
  });

  it('aplica a inativação depois de uma alteração de área encadeada', () => {
    const [resultado] = aplicarOverrides(
      [{ ...equipamentoBase, area: 'F1: 04-Serviços' }],
      [
        { codigoEquipamento: '04010', area: 'F1: 04-Serviços', inativo: false, novaArea: 'F1: 01-Administrativo', atualizadoEm: 1 },
        { codigoEquipamento: '04010', area: 'F1: 01-Administrativo', inativo: true, atualizadoEm: 2 },
      ],
    );
    expect(resultado.area).toBe('F1: 01-Administrativo');
    expect(resultado.estado_prazo).toBe('inativo');
  });
});
