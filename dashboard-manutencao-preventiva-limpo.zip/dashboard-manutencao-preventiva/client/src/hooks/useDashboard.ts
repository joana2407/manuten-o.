import { useMemo } from 'react';
import type { DashboardData, Equipamento, EstadoPrazo, ResumoArea, ResumoMes } from '@/lib/types';
import { mesAtual } from '@/lib/utils';
import { calcularProxima, calcularEstadoPrazo, chaveEquipamento } from './useRealizacoes';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';
import { trpc } from '@/lib/trpc';
import { useState, useEffect } from 'react';

export interface FiltrosDashboard {
  areas: string[];
  estados: EstadoPrazo[];
  mes: number | null; // 1-12 ou null (todos)
  busca: string;
  responsavel: string | null; // nome do técnico ou null (todos)
  fabrica: string | null; // 'Fábrica I' | 'Fábrica II' | null (todas)
}

const FILTROS_INICIAIS: FiltrosDashboard = {
  areas: [],
  estados: [],
  mes: null,
  busca: '',
  responsavel: null,
  fabrica: null,
};

// Data base do plano
const BASE_DATE = '2026-01-01';

// Deriva a fábrica a partir do prefixo da área ou do mapeamento custom
function derivarFabrica(area: string, areasCustomFabrica: Record<string, string>): string {
  if (areasCustomFabrica[area]) return areasCustomFabrica[area];
  if (area.startsWith('F1:')) return 'Fábrica I';
  if (area.startsWith('F2:')) return 'Fábrica II';
  return 'Fábrica I'; // default
}

export function normalizarEstadoEPrazo(equipamento: Equipamento): Equipamento {
  if (equipamento.estado.trim().toLowerCase() === 'inativo') {
    return { ...equipamento, estado_prazo: 'inativo', dias_ate_vencimento: null };
  }
  if (!equipamento.proxima_manutencao) {
    return { ...equipamento, estado_prazo: 'sem_periodicidade', dias_ate_vencimento: null };
  }
  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  const proxima = new Date(equipamento.proxima_manutencao + 'T00:00:00');
  return {
    ...equipamento,
    estado_prazo: calcularEstadoPrazo(equipamento.proxima_manutencao) as EstadoPrazo,
    dias_ate_vencimento: Math.floor((proxima.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24)),
  };
}

/**
 * Converte um equipamento custom da BD para o tipo Equipamento do dashboard.
 */
function equipamentoCustomParaDashboard(eq: {
  codigo: string;
  equipamento: string;
  area: string;
  periodicidade: string | null;
  estado: string | null;
  modelo?: string | null;
  numeroSerie?: string | null;
  planoIntervencao?: string | null;
}): Equipamento {
  const periNorm = eq.periodicidade?.toLowerCase().trim() ?? '';
  const proxima = calcularProxima(BASE_DATE, periNorm);
  const estadoPrazo = eq.estado === 'Inativo'
    ? 'inativo'
    : (proxima ? calcularEstadoPrazo(proxima) as EstadoPrazo : 'sem_periodicidade');

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);
  let dias: number | null = null;
  if (proxima) {
    const proxDate = new Date(proxima + 'T00:00:00');
    dias = Math.floor((proxDate.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));
  }

  return {
    area: eq.area,
    codigo: eq.codigo,
    equipamento: eq.equipamento,
    estado: eq.estado ?? 'Ativo',
    periodicidade: eq.periodicidade ?? '',
    periodicidade_norm: periNorm,
    proxima_manutencao: proxima,
    estado_prazo: estadoPrazo,
    dias_ate_vencimento: dias,
    id: (eq as { id?: string }).id,
    isCustom: true,
    modelo: eq.modelo ?? undefined,
    numeroSerie: eq.numeroSerie ?? undefined,
    planoIntervencao: (eq as { planoIntervencao?: string | null }).planoIntervencao ?? undefined,
  };
}

/**
 * Aplica as intervenções registadas sobre os equipamentos,
 * recalculando proxima_manutencao, estado_prazo e dias_ate_vencimento.
 */
function aplicarIntervencoes(
  equipamentos: Equipamento[],
  todasIntervencoes: IntervencaoDb[],
): Equipamento[] {
  if (todasIntervencoes.length === 0) return equipamentos;

  const ultimaPorChave = new Map<string, IntervencaoDb>();
  for (const iv of todasIntervencoes) {
    const chave = chaveEquipamento(iv.codigoEquipamento, iv.area);
    const existente = ultimaPorChave.get(chave);
    if (!existente || iv.dataRealizacao > existente.dataRealizacao) {
      ultimaPorChave.set(chave, iv);
    }
  }

  const hoje = new Date();
  hoje.setHours(0, 0, 0, 0);

  return equipamentos.map(eq => {
    const chave = chaveEquipamento(eq.codigo, eq.area);
    const ultima = ultimaPorChave.get(chave);
    if (!ultima || !eq.periodicidade_norm || eq.estado.trim().toLowerCase() === 'inativo') return eq;

    const novaProxima = calcularProxima(ultima.dataRealizacao, eq.periodicidade_norm);
    if (!novaProxima) return eq;

    const novoEstado = calcularEstadoPrazo(novaProxima) as EstadoPrazo;
    const proxDate = new Date(novaProxima + 'T00:00:00');
    const novosDias = Math.floor((proxDate.getTime() - hoje.getTime()) / (1000 * 60 * 60 * 24));

    return {
      ...eq,
      proxima_manutencao: novaProxima,
      estado_prazo: novoEstado,
      dias_ate_vencimento: novosDias,
    };
  });
}

/**
 * Aplica overrides de inativos e de edição: equipamentos marcados como inativos na BD
 * têm o estado_prazo forçado para 'inativo'. Overrides de edição aplicam novoNome/novaArea/novaPeriodicidade.
 */
export function aplicarOverrides(
  equipamentos: Equipamento[],
  overrides: { codigoEquipamento: string; area: string; inativo: boolean; atualizadoEm?: number; novoNome?: string | null; novaArea?: string | null; novaPeriodicidade?: string | null; modelo?: string | null; numeroSerie?: string | null; planoIntervencao?: string | null }[],
): Equipamento[] {
  if (overrides.length === 0) return equipamentos;

  // Manter apenas o override mais recente por chave. A tabela antiga permitia
  // vários registos para a mesma chave, o que tornava o resultado dependente
  // da ordem devolvida pela base de dados.
  const overrideMap = new Map<string, typeof overrides[0]>();
  for (const o of [...overrides].sort((a, b) => (a.atualizadoEm ?? 0) - (b.atualizadoEm ?? 0))) {
    overrideMap.set(chaveEquipamento(o.codigoEquipamento, o.area), o);
  }

  return equipamentos.map(eq => {
    let updated = { ...eq };
    let areaAtual = eq.area;
    for (let passo = 0; passo < 5; passo++) {
      const o = overrideMap.get(chaveEquipamento(eq.codigo, areaAtual));
      if (!o) break;
      if (o.novoNome) updated.equipamento = o.novoNome;
      if (o.novaPeriodicidade) {
        updated.periodicidade = o.novaPeriodicidade;
        updated.periodicidade_norm = o.novaPeriodicidade.toLowerCase().trim();
      }
      if (o.modelo) updated.modelo = o.modelo;
      if (o.numeroSerie) updated.numeroSerie = o.numeroSerie;
      if (o.planoIntervencao) updated.planoIntervencao = o.planoIntervencao;
      if (o.novaArea && o.novaArea !== areaAtual) {
        areaAtual = o.novaArea;
        updated.area = areaAtual;
      }
      if (o.inativo) {
        updated = { ...updated, estado: 'Inativo', estado_prazo: 'inativo' as EstadoPrazo };
      } else if (updated.estado_prazo === 'inativo' && !eq.isCustom) {
        updated = { ...updated, estado: 'Ativo' };
      }
    }
    return updated;
  });
}

export function useDashboard(todasIntervencoes: IntervencaoDb[] = []) {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [filtros, setFiltros] = useState<FiltrosDashboard>(FILTROS_INICIAIS);

  // Carregar JSON estático
  useEffect(() => {
    fetch('/manutencao.json')
      .then(r => r.json())
      .then((d: DashboardData) => { setData(d); setLoading(false); })
      .catch(e => { setError(String(e)); setLoading(false); });
  }, []);

  // Carregar equipamentos custom, áreas custom e overrides da BD
  const { data: equipamentosCustomData } = trpc.gestao.listarEquipamentos.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  const { data: areasCustomData } = trpc.gestao.listarAreas.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });
  const { data: overridesData } = trpc.gestao.listarOverrides.useQuery(undefined, {
    refetchOnWindowFocus: false,
  });

  // Converter equipamentos custom para o tipo Equipamento
  const equipamentosCustom: Equipamento[] = useMemo(() => {
    if (!equipamentosCustomData) return [];
    return equipamentosCustomData.map(equipamentoCustomParaDashboard);
  }, [equipamentosCustomData]);

  // Áreas custom (nomes)
  const areasCustomNomes: string[] = useMemo(() => {
    if (!areasCustomData) return [];
    return areasCustomData.map(a => a.nome);
  }, [areasCustomData]);

  // Mapa de fábrica por área custom
  const areasCustomFabrica: Record<string, string> = useMemo(() => {
    if (!areasCustomData) return {};
    const mapa: Record<string, string> = {};
    areasCustomData.forEach(a => { if (a.fabrica) mapa[a.nome] = a.fabrica; });
    return mapa;
  }, [areasCustomData]);

  // Lista completa de equipamentos (JSON + custom) com campo fábrica injetado
  const todosEquipamentos: Equipamento[] = useMemo(() => {
    const custom = equipamentosCustom.map(e => ({
      ...e,
      fabrica: derivarFabrica(e.area, areasCustomFabrica),
    }));
    if (!data) return custom;
    const json = data.equipamentos.map(e => ({
      ...e,
      fabrica: derivarFabrica(e.area, areasCustomFabrica),
    }));
    return [...json, ...custom];
  }, [data, equipamentosCustom, areasCustomFabrica]);

  // Aplicar intervenções e overrides
  const equipamentosAtualizados = useMemo(() => {
    // Filtrar equipamentos do JSON que foram marcados como eliminados
    const overrides = overridesData ?? [];
    const eliminadosSet = new Set(
      overrides
        .filter((o: { eliminado?: boolean }) => o.eliminado)
        .map((o: { codigoEquipamento: string; area: string }) => `${o.codigoEquipamento}||${o.area}`)
    );
    const semEliminados = todosEquipamentos.filter(e =>
      e.isCustom || !eliminadosSet.has(`${e.codigo}||${e.area}`)
    );
    const comOverrides = aplicarOverrides(semEliminados, overrides);
    const comIntervencoes = aplicarIntervencoes(comOverrides, todasIntervencoes);
    return comIntervencoes.map(normalizarEstadoEPrazo);
  }, [todosEquipamentos, todasIntervencoes, overridesData]);

  // Áreas: JSON + custom
  const areas = useMemo(() => {
    const areasJson = data ? Array.from(new Set(data.equipamentos.map(e => e.area))) : [];
    const todas = Array.from(new Set([...areasJson, ...areasCustomNomes])).sort();
    return todas;
  }, [data, areasCustomNomes]);

  const equipamentosFiltradosBase = useMemo(() => {
    let eq: Equipamento[] = equipamentosAtualizados;
    // Filtro por fábrica (rápido)
    if (filtros.fabrica) {
      eq = eq.filter(e => e.fabrica === filtros.fabrica);
    }
    if (filtros.areas.length > 0) {
      eq = eq.filter(e => filtros.areas.includes(e.area));
    }
    if (filtros.estados.length > 0) {
      eq = eq.filter(e => filtros.estados.includes(e.estado_prazo));
    }
    if (filtros.mes !== null) {
      eq = eq.filter(e => {
        if (!e.proxima_manutencao) return false;
        const m = new Date(e.proxima_manutencao + 'T00:00:00').getMonth() + 1;
        return m === filtros.mes;
      });
    }
    return eq;
  }, [equipamentosAtualizados, filtros]);

  // A pesquisa textual afeta a lista, mas não deve apagar os KPIs.
  // Assim, uma pesquisa sem resultados continua a mostrar a dimensão real
  // do conjunto selecionado e evita o falso estado "não há dados".
  const equipamentosFiltrados = useMemo(() => {
    const q = filtros.busca.trim().toLowerCase();
    if (!q) return equipamentosFiltradosBase;
    return equipamentosFiltradosBase.filter(e =>
      e.equipamento.toLowerCase().includes(q) ||
      e.codigo.toLowerCase().includes(q) ||
      e.area.toLowerCase().includes(q)
    );
  }, [equipamentosFiltradosBase, filtros.busca]);

  // KPIs filtrados
  const kpis = useMemo(() => {
    const eq = equipamentosFiltradosBase;
    return {
      total: eq.length,
      vencidos: eq.filter(e => e.estado_prazo === 'vencido').length,
      proximos: eq.filter(e => e.estado_prazo === 'proximo').length,
      em_dia: eq.filter(e => e.estado_prazo === 'em_dia').length,
      inativos: eq.filter(e => e.estado_prazo === 'inativo').length,
      sem_periodicidade: eq.filter(e => e.estado_prazo === 'sem_periodicidade').length,
    };
  }, [equipamentosFiltradosBase]);

  // Equipamentos filtrados por fábrica (para painéis globais)
  const equipamentosParaPaineis = useMemo(() => {
    if (!filtros.fabrica) return equipamentosAtualizados;
    return equipamentosAtualizados.filter(e => e.fabrica === filtros.fabrica);
  }, [equipamentosAtualizados, filtros.fabrica]);

  // Equipamentos do mês corrente
  const doMesCorrente = useMemo(() => {
    const m = mesAtual();
    return equipamentosParaPaineis.filter(e => {
      if (!e.proxima_manutencao) return false;
      const mes = new Date(e.proxima_manutencao + 'T00:00:00').getMonth() + 1;
      return mes === m;
    });
  }, [equipamentosParaPaineis]);

  // Vencidos globais
  const vencidosGlobal = useMemo(() => {
    return equipamentosParaPaineis.filter(e => e.estado_prazo === 'vencido');
  }, [equipamentosParaPaineis]);

  // Lista operacional para exportação: não depende da pesquisa textual nem
  // do filtro de responsável, mas respeita a fábrica selecionada.
  const pendentesExportacao = useMemo(() => {
    return equipamentosParaPaineis.filter(e => e.estado_prazo === 'vencido' || e.estado_prazo === 'proximo');
  }, [equipamentosParaPaineis]);

  // Recalcular por_area com todos os equipamentos (JSON + custom)
  const porAreaAtualizado = useMemo(() => {
    const mapa: Record<string, ResumoArea> = {};
    for (const eq of equipamentosParaPaineis) {
      if (!mapa[eq.area]) {
        mapa[eq.area] = { area: eq.area, total: 0, ativos: 0, vencidos: 0, proximos: 0, em_dia: 0, inativos: 0, sem_periodicidade: 0 };
      }
      const r = mapa[eq.area];
      r.total++;
      if (eq.estado !== 'Inativo') r.ativos++;
      if (eq.estado_prazo === 'vencido') r.vencidos++;
      else if (eq.estado_prazo === 'proximo') r.proximos++;
      else if (eq.estado_prazo === 'em_dia') r.em_dia++;
      else if (eq.estado_prazo === 'inativo') r.inativos++;
      else if (eq.estado_prazo === 'sem_periodicidade') r.sem_periodicidade++;
    }
    // Incluir áreas do JSON original + áreas custom (mesmo que vazias)
    const todasAreas = Array.from(new Set([
      ...(data?.por_area.map(a => a.area) ?? []),
      ...areasCustomNomes,
    ]));
    return todasAreas
      .map(area => mapa[area] ?? { area, total: 0, ativos: 0, vencidos: 0, proximos: 0, em_dia: 0, inativos: 0, sem_periodicidade: 0 })
      .filter(a => a.total > 0); // só mostrar áreas com equipamentos
  }, [data, equipamentosParaPaineis, areasCustomNomes]);

  // Recalcular por_mes
  const porMesAtualizado = useMemo(() => {
    const mapa: Record<number, { total: number; vencidos: number; proximos: number; em_dia: number }> = {};
    for (const eq of equipamentosParaPaineis) {
      if (!eq.proxima_manutencao) continue;
      const m = new Date(eq.proxima_manutencao + 'T00:00:00').getMonth() + 1;
      if (!mapa[m]) mapa[m] = { total: 0, vencidos: 0, proximos: 0, em_dia: 0 };
      mapa[m].total++;
      if (eq.estado_prazo === 'vencido') mapa[m].vencidos++;
      else if (eq.estado_prazo === 'proximo') mapa[m].proximos++;
      else if (eq.estado_prazo === 'em_dia') mapa[m].em_dia++;
    }
    const MESES = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    return Array.from({ length: 12 }, (_, i) => ({
      label: MESES[i],
      mes: i + 1,
      ...(mapa[i + 1] ?? { total: 0, vencidos: 0, proximos: 0, em_dia: 0 }),
    })) as ResumoMes[];
  }, [equipamentosParaPaineis]);

  // Resumo global
  const resumoAtualizado = useMemo(() => ({
    total: equipamentosParaPaineis.length,
    ativos: equipamentosParaPaineis.filter(e => e.estado !== 'Inativo').length,
    vencidos: equipamentosParaPaineis.filter(e => e.estado_prazo === 'vencido').length,
    proximos: equipamentosParaPaineis.filter(e => e.estado_prazo === 'proximo').length,
    em_dia: equipamentosParaPaineis.filter(e => e.estado_prazo === 'em_dia').length,
    inativos: equipamentosParaPaineis.filter(e => e.estado_prazo === 'inativo').length,
  }), [equipamentosParaPaineis]);

  const dataAtualizada = useMemo(() => {
    if (!data) return null;
    return {
      ...data,
      equipamentos: equipamentosAtualizados,
      por_area: porAreaAtualizado,
      por_mes: porMesAtualizado,
      resumo: resumoAtualizado,
    };
  }, [data, equipamentosAtualizados, porAreaAtualizado, porMesAtualizado, resumoAtualizado]);

  return {
    data: dataAtualizada,
    loading,
    error,
    filtros,
    setFiltros,
    areas,
    areasCustomFabrica,
    equipamentosFiltrados,
    equipamentosAtualizados,
    kpis,
    doMesCorrente,
    vencidosGlobal,
    pendentesExportacao,
  };
}
