import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { RealizacoesProvider } from "./contexts/RealizacoesContext";
import Home from "./pages/Home";
import FichaEquipamento from "./pages/FichaEquipamento";
import PainelValidacoes from "./pages/PainelValidacoes";
import PainelGestaoValidadores from "./pages/PainelGestaoValidadores";
import PainelCorretiva from "./pages/PainelCorretiva";
import AcessoAplicacao from "./pages/AcessoAplicacao";
import { AcessoGuard } from "./components/AcessoGuard";
import PainelBackups from "./pages/PainelBackups";
import InstrucoesSoftware from "./pages/InstrucoesSoftware";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"}>{() => <AcessoGuard><Home /></AcessoGuard>}</Route>
      <Route path={"/equipamento/:codigo/:area"}>{() => <AcessoGuard><FichaEquipamento /></AcessoGuard>}</Route>
      <Route path={"/validacoes"} component={PainelValidacoes} />
      <Route path={"/gestao-validadores"} component={PainelGestaoValidadores} />
      <Route path={"/corretiva"} component={PainelCorretiva} />
      <Route path={"/backups"}>{() => <AcessoGuard><PainelBackups /></AcessoGuard>}</Route>
      <Route path={"/instrucoes"}>{() => <AcessoGuard><InstrucoesSoftware /></AcessoGuard>}</Route>
      <Route path={"/acesso"} component={AcessoAplicacao} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="dark"
        // switchable
      >
        <RealizacoesProvider>
          <TooltipProvider>
            <Toaster />
            <Router />
          </TooltipProvider>
        </RealizacoesProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
