import { motion } from 'framer-motion';
import { AlertTriangle, ArrowLeft, ClipboardList, Clock3, Coins, History, PackageSearch, Settings2, Wrench } from 'lucide-react';
import { useLocation } from 'wouter';
import { PainelSelector } from '@/components/PainelSelector';

const secoes = [
  {
    icon: AlertTriangle,
    titulo: 'Registo de avaria',
    descricao: 'Abertura de ocorrências, prioridade, equipamento afetado e descrição da anomalia.',
    cor: '#EF4444',
  },
  {
    icon: ClipboardList,
    titulo: 'Ordens de trabalho',
    descricao: 'Atribuição de responsáveis, acompanhamento do trabalho e estado da intervenção.',
    cor: '#F4A623',
  },
  {
    icon: PackageSearch,
    titulo: 'Peças e custos',
    descricao: 'Materiais utilizados, fornecedores, tempos de paragem e custos associados.',
    cor: '#60A5FA',
  },
  {
    icon: History,
    titulo: 'Histórico corretivo',
    descricao: 'Consulta das avarias resolvidas, causas identificadas e ações tomadas.',
    cor: '#32C985',
  },
];

function EstadoCard({ icon: Icon, label }: { icon: typeof Clock3; label: string }) {
  return (
    <div
      className="flex min-h-[112px] flex-col justify-between rounded-xl p-4"
      style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
          {label}
        </span>
        <Icon size={16} style={{ color: 'oklch(0.42 0.01 240)' }} />
      </div>
      <div>
        <p className="font-mono text-3xl font-bold" style={{ color: 'oklch(0.5 0.01 240)' }}>—</p>
        <p className="mt-1 text-xs" style={{ color: 'oklch(0.42 0.01 240)' }}>A configurar</p>
      </div>
    </div>
  );
}

export default function PainelCorretiva() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen" style={{ background: 'oklch(0.085 0.005 240)' }}>
      <header
        className="corretiva-header sticky top-0 z-20 flex flex-wrap items-center gap-4 px-5 py-3"
        style={{ background: 'oklch(0.1 0.006 240)', borderBottom: '1px solid oklch(0.22 0.008 240)' }}
      >
        <button
          onClick={() => setLocation('/')}
          className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium transition-all active:scale-95"
          style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.15 260)', border: '1px solid oklch(0.3 0.08 260 / 0.5)' }}
        >
          <ArrowLeft size={14} />
          Voltar
        </button>
        <div className="flex items-center gap-2">
          <div
            className="flex h-8 w-8 items-center justify-center rounded"
            style={{ background: 'oklch(0.55 0.18 260 / 0.18)', border: '1px solid oklch(0.55 0.18 260 / 0.45)' }}
          >
            <Wrench size={15} style={{ color: 'oklch(0.75 0.15 260)' }} />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Manutenção Corretiva
            </h1>
            <p className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Avarias e intervenções não planeadas
            </p>
          </div>
        </div>
        <div className="ml-auto">
          <PainelSelector compacto />
        </div>
      </header>

      <main className="corretiva-main mx-auto flex w-full max-w-6xl flex-col gap-5 p-5">
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl p-5 sm:p-6"
          style={{ background: 'linear-gradient(135deg, oklch(0.13 0.025 260), oklch(0.115 0.007 240))', border: '1px solid oklch(0.55 0.18 260 / 0.35)' }}
        >
          <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
            <div className="max-w-2xl">
              <div className="mb-3 flex items-center gap-2">
                <span className="rounded-full px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider" style={{ background: 'oklch(0.55 0.18 260 / 0.2)', color: 'oklch(0.75 0.15 260)', border: '1px solid oklch(0.55 0.18 260 / 0.4)' }}>
                  Área em preparação
                </span>
              </div>
              <h2 className="text-2xl font-bold" style={{ color: 'oklch(0.92 0.005 240)' }}>
                Manutenção Corretiva
              </h2>
              <p className="mt-2 text-sm leading-relaxed" style={{ color: 'oklch(0.62 0.01 240)' }}>
                Este painel será utilizado para registar, acompanhar e analisar intervenções originadas por avarias ou necessidades não planeadas. A informação operacional será definida na próxima fase do projeto.
              </p>
            </div>
            <Settings2 className="hidden shrink-0 sm:block" size={38} style={{ color: 'oklch(0.55 0.18 260 / 0.55)' }} />
          </div>
        </motion.section>

        <section>
          <div className="mb-3 flex items-center gap-2">
            <Coins size={15} style={{ color: 'oklch(0.72 0.18 60)' }} />
            <h2 className="text-sm font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>Resumo operacional</h2>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <EstadoCard icon={AlertTriangle} label="Avarias abertas" />
            <EstadoCard icon={Wrench} label="Em intervenção" />
            <EstadoCard icon={Clock3} label="A aguardar peças" />
            <EstadoCard icon={History} label="Resolvidas" />
          </div>
        </section>

        <section>
          <div className="mb-3 flex items-center gap-2">
            <ClipboardList size={15} style={{ color: 'oklch(0.72 0.18 60)' }} />
            <h2 className="text-sm font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.65 0.01 240)' }}>Estrutura a construir</h2>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {secoes.map(({ icon: Icon, titulo, descricao, cor }, index) => (
              <motion.article
                key={titulo}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.04 }}
                className="flex gap-3 rounded-xl p-4"
                style={{ background: 'oklch(0.115 0.007 240)', border: '1px solid oklch(0.22 0.008 240)' }}
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg" style={{ background: `${cor}18`, border: `1px solid ${cor}44` }}>
                  <Icon size={17} style={{ color: cor }} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold" style={{ color: 'oklch(0.84 0.005 240)' }}>{titulo}</h3>
                  <p className="mt-1 text-xs leading-relaxed" style={{ color: 'oklch(0.52 0.01 240)' }}>{descricao}</p>
                </div>
              </motion.article>
            ))}
          </div>
        </section>

        <div className="rounded-lg px-4 py-3 text-center text-xs" style={{ background: 'oklch(0.12 0.006 240)', border: '1px dashed oklch(0.28 0.01 240)', color: 'oklch(0.48 0.01 240)' }}>
          O painel Preventivo mantém toda a informação existente. Use o seletor no topo para alternar entre os dois contextos.
        </div>
      </main>
    </div>
  );
}
