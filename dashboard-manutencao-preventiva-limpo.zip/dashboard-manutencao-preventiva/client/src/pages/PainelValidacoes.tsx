/*
 * PainelValidacoes — Painel com todos os registos de manutenção por validar
 * Design: Industrial Dark Analytics
 * Acesso: qualquer utilizador pode ver; validação requer autenticação por PIN
 * Sessão: após login com PIN, o utilizador pode validar sem re-introduzir PIN
 */
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, ShieldCheck, ShieldAlert, Shield, Clock, Wrench, Search,
  CheckCircle2, RefreshCw, Paperclip, ChevronDown, ChevronUp,
  Filter, LogOut, User, Eye, EyeOff, Lock,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';
import { formatDate } from '@/lib/utils';
import { SeletorUtilizadorAcesso } from '@/components/SeletorUtilizadorAcesso';
import { autenticarUtilizadorLocal } from '@/lib/localAccess';

// ─── Tipos de sessão ──────────────────────────────────────────────────────────

interface SessaoValidador {
  id: string;
  nome: string;
  nomeUtilizador: string;
  pin: string; // guardado em memória para verificação server-side
  perfil: string;
  funcao: string;
  podeRegistar: boolean;
  podeValidar: boolean;
  podeGerir: boolean;
  podeGerirEquipamentos: boolean;
  podeGerirPins: boolean;
  podeGerirUtilizadores: boolean;
}

const SESSAO_KEY = 'validador_sessao';

function guardarSessao(sessao: SessaoValidador) {
  const valor = JSON.stringify(sessao);
  sessionStorage.setItem(SESSAO_KEY, valor);
  sessionStorage.setItem('app_sessao', valor);
}

function carregarSessao(): SessaoValidador | null {
  try {
    const raw = sessionStorage.getItem(SESSAO_KEY);
    if (!raw) return null;
    const sessao = JSON.parse(raw) as SessaoValidador;
    return sessao.nomeUtilizador && typeof sessao.podeGerirUtilizadores === 'boolean' ? sessao : null;
  } catch {
    return null;
  }
}

function limparSessao() {
  sessionStorage.removeItem(SESSAO_KEY);
  sessionStorage.removeItem('app_sessao');
}

// ─── Helpers de UI ────────────────────────────────────────────────────────────

function BadgeEstado({ validado }: { validado: boolean }) {
  if (validado) {
    return (
      <span
        className="text-xs font-semibold px-2 py-0.5 rounded-full flex items-center gap-1"
        style={{ background: '#22C55E11', color: '#22C55E', border: '1px solid #22C55E33' }}
      >
        <CheckCircle2 size={10} />
        Validado
      </span>
    );
  }
  return (
    <span
      className="text-xs font-semibold px-2 py-0.5 rounded-full flex items-center gap-1 animate-pulse"
      style={{ background: 'oklch(0.72 0.18 60 / 0.12)', color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.35)' }}
    >
      <Clock size={10} />
      Por validar
    </span>
  );
}

// ─── Ecrã de Login ────────────────────────────────────────────────────────────

function EcraNLogin({ onLogin }: { onLogin: (sessao: SessaoValidador) => void }) {
  const [nomeUtilizador, setNomeUtilizador] = useState('');
  const [pin, setPin] = useState('');
  const [mostrarPin, setMostrarPin] = useState(false);
  const [erro, setErro] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  const [aAutenticar, setAAutenticar] = useState(false);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeUtilizador.trim() || !pin.trim()) return;
    setErro('');
    setAAutenticar(true);
    try {
      const resultado = autenticarUtilizadorLocal(nomeUtilizador.trim(), pin.trim());
      const sessao: SessaoValidador = {
        id: resultado.id,
        nome: resultado.nome,
        nomeUtilizador: resultado.nomeUtilizador,
        pin: pin.trim(),
        perfil: resultado.perfil,
        funcao: resultado.funcao,
        podeRegistar: resultado.podeRegistar,
        podeValidar: resultado.podeValidar,
        podeGerir: resultado.podeGerir,
        podeGerirEquipamentos: resultado.podeGerirEquipamentos,
        podeGerirPins: resultado.podeGerirPins,
        podeGerirUtilizadores: resultado.podeGerirUtilizadores,
      };
      guardarSessao(sessao);
      onLogin(sessao);
    } catch {
      setErro('O PIN não corresponde ao utilizador selecionado. Tente novamente.');
      setPin('');
      inputRef.current?.focus();
    } finally {
      setAAutenticar(false);
    }
  };

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  return (
    <div className="min-h-screen flex flex-col items-center justify-center" style={{ background: bg }}>
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
        className="w-full max-w-sm mx-4"
      >
        {/* Cabeçalho */}
        <div className="flex flex-col items-center gap-3 mb-8">
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center"
            style={{ background: '#22C55E22', border: '1px solid #22C55E44' }}
          >
            <Lock size={24} style={{ color: '#22C55E' }} />
          </div>
          <div className="text-center">
            <h1 className="text-lg font-bold" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Validação de Manutenções
            </h1>
            <p className="text-sm mt-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
              Selecione o utilizador e introduza o PIN para continuar
            </p>
          </div>
        </div>

        {/* Formulário */}
        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 p-6 rounded-2xl"
          style={{ background: cardBg, border: `1px solid ${borderColor}` }}
        >
          <SeletorUtilizadorAcesso value={nomeUtilizador} onChange={utilizador => { setNomeUtilizador(utilizador); setErro(''); }} disabled={aAutenticar} />
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
              PIN de Acesso
            </label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg"
              style={{ background: 'oklch(0.085 0.005 240)', border: `1px solid ${erro ? '#EF4444' : borderColor}` }}
            >
              <Lock size={14} style={{ color: 'oklch(0.45 0.01 240)' }} />
              <input
                ref={inputRef}
                type={mostrarPin ? 'text' : 'password'}
                value={pin}
                onChange={e => { setPin(e.target.value); setErro(''); }}
                placeholder="Introduza o seu PIN"
                className="flex-1 bg-transparent text-sm outline-none"
                style={{ color: 'oklch(0.88 0.005 240)' }}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setMostrarPin(v => !v)}
                className="transition-opacity hover:opacity-70"
                style={{ color: 'oklch(0.45 0.01 240)' }}
              >
                {mostrarPin ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            {erro && (
              <motion.p
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs"
                style={{ color: '#EF4444' }}
              >
                {erro}
              </motion.p>
            )}
          </div>

          <button
            type="submit"
            disabled={!nomeUtilizador.trim() || !pin.trim() || aAutenticar}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all active:scale-95 disabled:opacity-50"
            style={{ background: '#22C55E', color: '#0a1a0a' }}
          >
            {aAutenticar ? (
              <RefreshCw size={14} className="animate-spin" />
            ) : (
              <ShieldCheck size={14} />
            )}
            {aAutenticar ? 'A verificar...' : 'Entrar'}
          </button>
        </form>

        <p className="text-center text-xs mt-4" style={{ color: 'oklch(0.38 0.008 240)' }}>
          O PIN é pessoal e intransmissível. Contacte o administrador se não tiver acesso.
        </p>
      </motion.div>
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function PainelValidacoes() {
  const [, setLocation] = useLocation();
  const [sessao, setSessao] = useState<SessaoValidador | null>(() => carregarSessao());
  const [pesquisa, setPesquisa] = useState('');
  const [expandidos, setExpandidos] = useState<Set<string>>(new Set());
  // Mostrar o histórico completo por defeito; o utilizador pode filtrar para pendentes.
  const [mostrarValidados, setMostrarValidados] = useState(true);
  const [validandoId, setValidandoId] = useState<string | null>(null);
  const [feedbackId, setFeedbackId] = useState<string | null>(null);
  const [erroValidacao, setErroValidacao] = useState<string | null>(null);

  // Carregar intervenções por validar
  const { data: porValidar = [], isLoading: loadingPorValidar, refetch } = trpc.intervencoes.listarPorValidar.useQuery(
    undefined,
    { refetchOnWindowFocus: true }
  );

  // Carregar todas para mostrar validadas (opcional)
  const { data: todas = [], isLoading: loadingTodas } = trpc.intervencoes.listarTodas.useQuery(
    undefined,
    { enabled: mostrarValidados }
  );

  const validarComSessao = trpc.intervencoes.validarComSessao.useMutation();

  const isLoading = loadingPorValidar || (mostrarValidados && loadingTodas);

  // Filtrar por pesquisa
  const listaBase = mostrarValidados ? todas : porValidar;
  const listaFiltrada = useMemo(() => {
    const q = pesquisa.toLowerCase().trim();
    if (!q) return listaBase;
    return listaBase.filter(i =>
      i.codigoEquipamento.toLowerCase().includes(q) ||
      i.area.toLowerCase().includes(q) ||
      (i.responsavel ?? '').toLowerCase().includes(q) ||
      (i.responsavelValidacao ?? '').toLowerCase().includes(q) ||
      (i.intervencaoRealizada ?? '').toLowerCase().includes(q) ||
      ((i as { nomeEquipamento?: string | null }).nomeEquipamento ?? '').toLowerCase().includes(q)
    );
  }, [listaBase, pesquisa]);

  const toggleExpandido = (id: string) => {
    setExpandidos(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleLogout = () => {
    limparSessao();
    setSessao(null);
  };

  const handleValidar = async (intervencao: IntervencaoDb & { nomeEquipamento?: string | null }) => {
    if (!sessao) return;
    setValidandoId(intervencao.id);
    setErroValidacao(null);
    try {
      await validarComSessao.mutateAsync({
        id: intervencao.id,
        validadoPor: sessao.nome,
        validadorId: sessao.id,
        nomeUtilizador: sessao.nomeUtilizador,
        pin: sessao.pin,
      });
      setFeedbackId(intervencao.id);
      setTimeout(() => setFeedbackId(null), 2000);
      refetch();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Erro ao validar';
      if (msg.includes('Sessão inválida') || msg.includes('PIN')) {
        // Sessão expirou — forçar novo login
        limparSessao();
        setSessao(null);
      } else {
        setErroValidacao(msg || 'Não foi possível validar esta intervenção.');
      }
    } finally {
      setValidandoId(null);
    }
  };

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  // Se não há sessão, mostrar ecrã de login
  if (!sessao) {
    return <EcraNLogin onLogin={setSessao} />;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: bg }}>
      {/* Header */}
      <header
        className="validacoes-header flex flex-wrap items-center gap-3 px-5 py-3 flex-shrink-0 sticky top-0 z-10"
        style={{ background: cardBg, borderBottom: `1px solid ${borderColor}` }}
      >
        <button
          onClick={() => setLocation('/')}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all active:scale-95"
          style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
        >
          <ArrowLeft size={14} />
          Voltar
        </button>
        <div className="flex items-center gap-2 ml-1">
          <div
            className="w-7 h-7 rounded flex items-center justify-center"
            style={{ background: '#22C55E22', border: '1px solid #22C55E44' }}
          >
            <ShieldCheck size={13} style={{ color: '#22C55E' }} />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Validação de Manutenções
            </h1>
            <p className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Histórico completo: pendentes e validados
            </p>
          </div>
        </div>
        <div className="validacoes-header-actions ml-auto flex items-center gap-2">
          {/* Utilizador autenticado */}
          <div
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg"
            style={{ background: '#22C55E11', border: '1px solid #22C55E33' }}
          >
            <User size={12} style={{ color: '#22C55E' }} />
            <span className="text-xs font-semibold" style={{ color: '#22C55E' }}>
              {sessao.nome} · {sessao.funcao}
            </span>
          </div>
          {/* Contador pendentes */}
          {porValidar.length > 0 && (
            <div
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full"
              style={{ background: 'oklch(0.72 0.18 60 / 0.12)', border: '1px solid oklch(0.72 0.18 60 / 0.35)' }}
            >
              <ShieldAlert size={13} style={{ color: 'oklch(0.82 0.16 60)' }} />
              <span className="text-xs font-bold font-mono" style={{ color: 'oklch(0.82 0.16 60)' }}>
                {porValidar.length} por validar
              </span>
            </div>
          )}
          <button
            onClick={() => refetch()}
            className="p-1.5 rounded transition-all hover:opacity-70 active:scale-95"
            style={{ color: 'oklch(0.52 0.01 240)' }}
            title="Atualizar"
          >
            <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
          </button>
          {/* Gestão de PINs — Gestão e Responsável de Qualidade */}
          {sessao.podeGerirUtilizadores && <button
            onClick={() => setLocation('/gestao-validadores')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95"
            style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
            title="Gestão de PINs de utilizadores"
          >
            <Shield size={12} />
            Gestão de PINs
          </button>}
          {/* Logout */}
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95"
            style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.55 0.01 240)', border: '1px solid oklch(0.22 0.008 240)' }}
            title="Terminar sessão"
          >
            <LogOut size={12} />
            Sair
          </button>
        </div>
      </header>

      {/* Body */}
      <main className="validacoes-main flex-1 p-5 flex flex-col gap-4 max-w-4xl mx-auto w-full">

        {/* Barra de ferramentas */}
        <div className="validacoes-toolbar flex items-center gap-3">
          <div
            className="flex-1 flex items-center gap-2 px-3 py-2 rounded-lg"
            style={{ background: cardBg, border: `1px solid ${borderColor}` }}
          >
            <Search size={13} style={{ color: 'oklch(0.45 0.01 240)' }} />
            <input
              type="text"
              value={pesquisa}
              onChange={e => setPesquisa(e.target.value)}
              placeholder="Pesquisar por código, equipamento, área, técnico..."
              className="flex-1 bg-transparent text-sm outline-none"
              style={{ color: 'oklch(0.88 0.005 240)' }}
            />
          </div>
          <button
            onClick={() => setMostrarValidados(v => !v)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium transition-all active:scale-95"
            style={{
              background: mostrarValidados ? '#22C55E22' : 'oklch(0.15 0.006 240)',
              color: mostrarValidados ? '#22C55E' : 'oklch(0.62 0.01 240)',
              border: `1px solid ${mostrarValidados ? '#22C55E44' : 'oklch(0.25 0.008 240)'}`,
            }}
          >
            <Filter size={12} />
            {mostrarValidados ? 'Mostrar só pendentes' : 'Incluir validados'}
          </button>
        </div>

        {erroValidacao && (
          <div className="flex items-center justify-between gap-3 rounded-lg px-3 py-2 text-xs" style={{ background: '#EF444411', border: '1px solid #EF444433', color: '#FCA5A5' }}>
            <span>{erroValidacao}</span>
            <button type="button" onClick={() => setErroValidacao(null)} className="font-semibold hover:opacity-70">Fechar</button>
          </div>
        )}

        {/* Sumário */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { label: 'Por Validar', value: porValidar.length, color: 'oklch(0.82 0.16 60)', bg: 'oklch(0.72 0.18 60 / 0.08)', border: 'oklch(0.72 0.18 60 / 0.25)' },
            { label: 'Validados (total)', value: (todas.length || 0) - porValidar.length, color: '#22C55E', bg: '#22C55E0a', border: '#22C55E33' },
            { label: 'Total de Registos', value: todas.length || porValidar.length, color: 'oklch(0.65 0.01 240)', bg: 'oklch(0.12 0.006 240)', border: 'oklch(0.22 0.008 240)' },
          ].map(({ label, value, color, bg: cbg, border }) => (
            <div
              key={label}
              className="flex flex-col gap-1 p-3 rounded-lg text-center"
              style={{ background: cbg, border: `1px solid ${border}` }}
            >
              <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.48 0.01 240)' }}>{label}</span>
              <span className="text-2xl font-bold" style={{ color }}>{value}</span>
            </div>
          ))}
        </div>

        {/* Lista de intervenções */}
        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <RefreshCw size={24} className="animate-spin" style={{ color: 'oklch(0.72 0.18 60)' }} />
          </div>
        ) : listaFiltrada.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-16 gap-3"
          >
            <div
              className="w-14 h-14 rounded-full flex items-center justify-center"
              style={{ background: '#22C55E11', border: '1px solid #22C55E33' }}
            >
              <ShieldCheck size={24} style={{ color: '#22C55E' }} />
            </div>
            <p className="text-base font-semibold" style={{ color: 'oklch(0.78 0.005 240)' }}>
              {pesquisa ? 'Sem resultados para a pesquisa' : 'Sem manutenções por validar'}
            </p>
            <p className="text-sm" style={{ color: 'oklch(0.48 0.01 240)' }}>
              {pesquisa ? 'Tente outros termos de pesquisa.' : 'Todos os registos estão validados.'}
            </p>
          </motion.div>
        ) : (
          <div className="flex flex-col gap-3">
            {listaFiltrada.map((intervencao, idx) => {
              const isValidado = !!intervencao.validadoEm;
              const expandido = expandidos.has(intervencao.id);
              const esteValidando = validandoId === intervencao.id;
              const esteFeedback = feedbackId === intervencao.id;
              return (
                <motion.div
                  key={intervencao.id}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.2, delay: idx * 0.03, ease: [0.23, 1, 0.32, 1] }}
                  className="rounded-xl overflow-hidden"
                  style={{
                    background: cardBg,
                    border: `1px solid ${esteFeedback ? '#22C55E66' : isValidado ? '#22C55E22' : 'oklch(0.72 0.18 60 / 0.25)'}`,
                    transition: 'border-color 0.3s ease',
                  }}
                >
                  {/* Linha principal */}
                  <div className="validacao-card-header flex items-center gap-3 px-4 py-3">
                    <div
                      className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                      style={{
                        background: isValidado ? '#22C55E22' : 'oklch(0.72 0.18 60 / 0.12)',
                        border: `1px solid ${isValidado ? '#22C55E44' : 'oklch(0.72 0.18 60 / 0.3)'}`,
                      }}
                    >
                      {isValidado
                        ? <CheckCircle2 size={14} style={{ color: '#22C55E' }} />
                        : <Wrench size={14} style={{ color: 'oklch(0.82 0.16 60)' }} />
                      }
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-semibold font-mono" style={{ color: 'oklch(0.88 0.005 240)' }}>
                          {intervencao.codigoEquipamento}
                        </span>
                        {(intervencao as { nomeEquipamento?: string | null }).nomeEquipamento && (
                          <span className="text-sm font-medium" style={{ color: 'oklch(0.82 0.005 240)' }}>
                            — {(intervencao as { nomeEquipamento?: string | null }).nomeEquipamento}
                          </span>
                        )}
                        <BadgeEstado validado={isValidado} />
                      </div>
                      <div className="flex items-center gap-1 mt-0.5">
                        <span className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
                          {intervencao.area}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 mt-0.5 flex-wrap">
                        <span className="text-xs" style={{ color: 'oklch(0.55 0.01 240)' }}>
                          Realizada: <span style={{ color: 'oklch(0.72 0.005 240)' }}>{formatDate(intervencao.dataRealizacao)}</span>
                        </span>
                        {intervencao.responsavel && (
                          <span className="text-xs" style={{ color: 'oklch(0.55 0.01 240)' }}>
                            Técnico: <span style={{ color: 'oklch(0.72 0.005 240)' }}>{intervencao.responsavel}</span>
                          </span>
                        )}
                        {intervencao.responsavelValidacao && (
                          <span className="text-xs" style={{ color: 'oklch(0.55 0.01 240)' }}>
                            Resp. Validação: <span style={{ color: 'oklch(0.72 0.005 240)' }}>{intervencao.responsavelValidacao}</span>
                          </span>
                        )}
                        {intervencao.anexos.length > 0 && (
                          <span className="text-xs flex items-center gap-1" style={{ color: 'oklch(0.52 0.01 240)' }}>
                            <Paperclip size={10} />
                            {intervencao.anexos.length} anexo{intervencao.anexos.length !== 1 ? 's' : ''}
                          </span>
                        )}
                      </div>
                      {isValidado && intervencao.validadoPor && (
                        <p className="text-xs mt-0.5" style={{ color: '#22C55E88' }}>
                          Validado por: <span style={{ color: '#22C55E' }}>{intervencao.validadoPor}</span>
                        </p>
                      )}
                    </div>

                    <div className="validacao-card-actions flex items-center gap-2 flex-shrink-0">
                      {!isValidado && sessao.podeValidar && (
                        <button
                          onClick={() => handleValidar(intervencao)}
                          disabled={esteValidando}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-95 disabled:opacity-60"
                          style={{ background: esteFeedback ? '#16A34A' : '#22C55E', color: '#0a1a0a' }}
                        >
                          {esteValidando ? (
                            <RefreshCw size={12} className="animate-spin" />
                          ) : esteFeedback ? (
                            <CheckCircle2 size={12} />
                          ) : (
                            <ShieldCheck size={12} />
                          )}
                          {esteValidando ? 'A validar...' : esteFeedback ? 'Validado!' : 'Validar'}
                        </button>
                      )}
                      <button
                        onClick={() => toggleExpandido(intervencao.id)}
                        className="p-1.5 rounded transition-all hover:opacity-70"
                        style={{ color: 'oklch(0.45 0.01 240)' }}
                      >
                        {expandido ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                      </button>
                    </div>
                  </div>

                  {/* Detalhe expandido */}
                  <AnimatePresence>
                    {expandido && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
                        style={{ overflow: 'hidden' }}
                      >
                        <div
                          className="px-4 pb-4 pt-2 flex flex-col gap-3"
                          style={{ borderTop: '1px solid oklch(0.18 0.006 240)' }}
                        >
                          {intervencao.intervencaoRealizada && (
                            <div>
                              <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
                                Intervenção Realizada
                              </p>
                              <p className="text-sm whitespace-pre-wrap" style={{ color: 'oklch(0.78 0.005 240)' }}>
                                {intervencao.intervencaoRealizada}
                              </p>
                            </div>
                          )}
                          {intervencao.materialGasto && (
                            <div>
                              <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
                                Material Gasto
                              </p>
                              <p className="text-sm whitespace-pre-wrap" style={{ color: 'oklch(0.78 0.005 240)' }}>
                                {intervencao.materialGasto}
                              </p>
                            </div>
                          )}
                          {intervencao.anexos.length > 0 && (
                            <div>
                              <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: 'oklch(0.48 0.01 240)' }}>
                                Anexos
                              </p>
                              <div className="flex flex-wrap gap-2">
                                {intervencao.anexos.map(a => (
                                  <a
                                    key={a.id}
                                    href={a.storageUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-all hover:opacity-80"
                                    style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
                                  >
                                    <Paperclip size={10} />
                                    {a.filename}
                                  </a>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        )}
      </main>
    </div>
  );
}
