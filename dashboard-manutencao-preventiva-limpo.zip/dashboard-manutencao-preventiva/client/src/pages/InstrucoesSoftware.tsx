import { useLocation } from 'wouter';
import { ArrowLeft, BookOpen, CheckCircle2, KeyRound, MonitorCog, ShieldCheck, TriangleAlert, Wrench } from 'lucide-react';

const passos = [
  {
    numero: '01',
    titulo: 'Entrar na aplicação',
    texto: 'Selecione o seu nome na grelha de utilizadores e introduza o seu PIN pessoal. Não partilhe o PIN nem utilize o perfil de outra pessoa.',
    icon: KeyRound,
    cor: 'oklch(0.72 0.18 60)',
  },
  {
    numero: '02',
    titulo: 'Escolher o painel',
    texto: 'Use Manutenção Preventiva para tarefas planeadas e Manutenção Corretiva para avarias e ordens de trabalho não planeadas.',
    icon: MonitorCog,
    cor: 'oklch(0.65 0.16 25)',
  },
  {
    numero: '03',
    titulo: 'Registar a intervenção',
    texto: 'Confirme sempre o equipamento, área, data e trabalho realizado. Registe medições, peças, anomalias e ações pendentes com detalhe suficiente.',
    icon: Wrench,
    cor: 'oklch(0.66 0.16 185)',
  },
  {
    numero: '04',
    titulo: 'Enviar para validação',
    texto: 'Depois de guardar, confirme que a intervenção aparece na lista de intervenções por validar. A libertação do equipamento é feita por um responsável autorizado.',
    icon: ShieldCheck,
    cor: '#22C55E',
  },
];

export default function InstrucoesSoftware() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen px-4 py-5 sm:px-8" style={{ background: 'oklch(0.085 0.005 240)', color: 'oklch(0.9 0.005 240)' }}>
      <div className="mx-auto max-w-6xl">
        <header className="mb-6 flex flex-wrap items-center justify-between gap-4 border-b pb-5" style={{ borderColor: 'oklch(0.22 0.008 240)' }}>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg" style={{ background: 'oklch(0.72 0.18 60 / 0.16)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}>
              <BookOpen size={20} style={{ color: 'oklch(0.82 0.16 60)' }} />
            </div>
            <div>
              <p className="text-[11px] font-semibold uppercase tracking-[0.18em]" style={{ color: 'oklch(0.55 0.01 240)' }}>Painel explicativo</p>
              <h1 className="text-xl font-semibold sm:text-2xl">Instruções de utilização do software</h1>
            </div>
          </div>
          <button onClick={() => setLocation('/')} className="flex items-center gap-2 rounded-md px-3 py-2 text-xs font-semibold transition-colors hover:bg-white/10 active:scale-[0.97]" style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.35)' }}>
            <ArrowLeft size={14} /> Voltar ao dashboard
          </button>
        </header>

        <section className="mb-6 rounded-xl p-5 sm:p-6" style={{ background: 'linear-gradient(135deg, oklch(0.14 0.012 240), oklch(0.105 0.008 240))', border: '1px solid oklch(0.3 0.015 240)' }}>
          <div className="mb-2 flex items-center gap-2 text-sm font-semibold" style={{ color: 'oklch(0.82 0.16 60)' }}>
            <CheckCircle2 size={17} /> Regra essencial
          </div>
          <p className="max-w-4xl text-sm leading-6" style={{ color: 'oklch(0.72 0.01 240)' }}>
            Registe a informação logo após a intervenção, confirme o equipamento correto e mantenha os registos objetivos e rastreáveis. A validação e libertação do equipamento só podem ser feitas por um responsável autorizado.
          </p>
        </section>

        <div className="grid gap-4 md:grid-cols-2">
          {passos.map(({ numero, titulo, texto, icon: Icon, cor }) => (
            <article key={numero} className="rounded-xl p-5 transition-transform hover:-translate-y-0.5" style={{ background: 'oklch(0.115 0.008 240)', border: '1px solid oklch(0.23 0.01 240)' }}>
              <div className="mb-4 flex items-start justify-between">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg" style={{ color: cor, background: `${cor}1A`, border: `1px solid ${cor}55` }}><Icon size={18} /></div>
                <span className="font-mono text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>{numero}</span>
              </div>
              <h2 className="mb-2 text-base font-semibold">{titulo}</h2>
              <p className="text-sm leading-6" style={{ color: 'oklch(0.63 0.01 240)' }}>{texto}</p>
            </article>
          ))}
        </div>

        <section className="mt-6 grid gap-4 lg:grid-cols-2">
          <article className="rounded-xl p-5" style={{ background: 'oklch(0.115 0.008 240)', border: '1px solid oklch(0.23 0.01 240)' }}>
            <h2 className="mb-3 flex items-center gap-2 text-base font-semibold"><KeyRound size={17} style={{ color: 'oklch(0.82 0.16 60)' }} /> Utilizadores e PINs</h2>
            <ul className="space-y-2 text-sm leading-6" style={{ color: 'oklch(0.67 0.01 240)' }}>
              <li>• Cada utilizador utiliza exclusivamente o seu próprio perfil e PIN.</li>
              <li>• A <strong style={{ color: 'oklch(0.84 0.01 240)' }}>administração dos utilizadores e dos PINs é da responsabilidade da Responsável de Qualidade</strong>.</li>
              <li>• A Responsável de Qualidade pode consultar utilizadores e alterar PINs, sem gerir as operações exclusivas de Gestão.</li>
              <li>• A Gestão mantém o acesso integral à administração, backups e recuperação de dados.</li>
            </ul>
          </article>
          <article className="rounded-xl p-5" style={{ background: 'oklch(0.115 0.008 240)', border: '1px solid oklch(0.23 0.01 240)' }}>
            <h2 className="mb-3 flex items-center gap-2 text-base font-semibold"><TriangleAlert size={17} style={{ color: 'oklch(0.72 0.16 25)' }} /> Em caso de problema</h2>
            <ul className="space-y-2 text-sm leading-6" style={{ color: 'oklch(0.67 0.01 240)' }}>
              <li>• Não valide uma intervenção associada ao equipamento errado.</li>
              <li>• Se o PIN for rejeitado, contacte a Responsável de Qualidade ou a Gestão.</li>
              <li>• Se a aplicação estiver indisponível, registe a ocorrência em suporte controlado e transcreva-a quando o serviço voltar.</li>
              <li>• Para dúvidas sobre o conteúdo técnico, contacte o Responsável de Manutenção.</li>
            </ul>
          </article>
        </section>

        <footer className="mt-6 border-t pt-4 text-xs" style={{ borderColor: 'oklch(0.22 0.008 240)', color: 'oklch(0.46 0.01 240)' }}>
          Estas instruções estão disponíveis para todos os utilizadores autenticados. Consulte também o procedimento de qualidade P9.
        </footer>
      </div>
    </div>
  );
}
