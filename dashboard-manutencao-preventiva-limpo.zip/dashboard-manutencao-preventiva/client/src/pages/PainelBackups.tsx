import { useMemo, useState } from "react";
import { ArchiveRestore, ArrowLeft, CalendarClock, DatabaseBackup, Download, FileSpreadsheet, HardDriveDownload, Loader2, RefreshCw, ShieldAlert } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type SessaoAcesso = {
  nome: string;
  nomeUtilizador: string;
  pin: string;
  podeGerir: boolean;
};

function lerSessao(): SessaoAcesso | null {
  try {
    const raw = sessionStorage.getItem("app_sessao") ?? sessionStorage.getItem("validador_sessao");
    const sessao = raw ? (JSON.parse(raw) as SessaoAcesso) : null;
    return sessao?.nomeUtilizador && sessao?.pin ? sessao : null;
  } catch {
    return null;
  }
}

function formatarData(valor: number) {
  return new Date(valor).toLocaleString("pt-PT", { dateStyle: "medium", timeStyle: "short" });
}

export default function PainelBackups() {
  const [, setLocation] = useLocation();
  const [sessao] = useState<SessaoAcesso | null>(() => lerSessao());
  const [aRecuperar, setARecuperar] = useState<string | null>(null);
  const [confirmacao, setConfirmacao] = useState("");
  const credenciais = useMemo(
    () => ({ nomeUtilizador: sessao?.nomeUtilizador ?? "", pin: sessao?.pin ?? "" }),
    [sessao?.nomeUtilizador, sessao?.pin],
  );
  const utils = trpc.useUtils();
  const backups = trpc.backups.listar.useQuery(credenciais, { enabled: Boolean(sessao) });
  const download = trpc.backups.obterDownloadExcel.useMutation();
  const criarAgora = trpc.backups.criarAgora.useMutation({
    onSuccess: () => {
      toast.success("Backup criado e guardado com sucesso.");
      utils.backups.listar.invalidate();
    },
    onError: erro => toast.error(erro.message),
  });
  const restaurar = trpc.backups.restaurar.useMutation({
    onSuccess: () => {
      toast.success("Backup recuperado. Foi criada uma cópia de segurança antes da recuperação.");
      setARecuperar(null);
      setConfirmacao("");
      utils.backups.listar.invalidate();
    },
    onError: erro => toast.error(erro.message),
  });

  async function descarregar(id: string) {
    try {
      const resultado = await download.mutateAsync({ ...credenciais, id });
      const resposta = await fetch(resultado.url);
      if (!resposta.ok) throw new Error("Não foi possível obter o ficheiro de backup.");
      const ficheiro = await resposta.blob();
      const objectUrl = URL.createObjectURL(ficheiro);
      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = resultado.nomeFicheiro;
      document.body.appendChild(link);
      link.click();
      link.remove();
      URL.revokeObjectURL(objectUrl);
    } catch (erro) {
      toast.error(erro instanceof Error ? erro.message : "Não foi possível preparar a transferência.");
    }
  }

  if (!sessao) return null;

  return (
    <div className="min-h-screen" style={{ background: "oklch(0.085 0.005 240)" }}>
      <header className="validacoes-header flex flex-wrap items-center gap-3 px-5 py-3" style={{ background: "oklch(0.1 0.006 240)", borderBottom: "1px solid oklch(0.22 0.008 240)" }}>
        <button onClick={() => setLocation("/")} className="flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm font-medium active:scale-95" style={{ color: "oklch(0.72 0.18 60)", border: "1px solid oklch(0.28 0.01 240)" }}>
          <ArrowLeft size={14} /> Dashboard
        </button>
        <div className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded" style={{ background: "oklch(0.72 0.18 60 / 0.15)", border: "1px solid oklch(0.72 0.18 60 / 0.4)" }}><DatabaseBackup size={16} style={{ color: "oklch(0.82 0.16 60)" }} /></div>
          <div><h1 className="text-sm font-semibold" style={{ color: "oklch(0.92 0.005 240)" }}>Backups de manutenção</h1><p className="text-xs" style={{ color: "oklch(0.48 0.01 240)" }}>Cópias semanais privadas · exportação e consulta em Excel · 12 semanas</p></div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button onClick={() => backups.refetch()} className="rounded-lg p-2 active:scale-95" aria-label="Atualizar lista de backups" title="Atualizar" style={{ color: "oklch(0.7 0.01 240)", border: "1px solid oklch(0.25 0.008 240)" }}><RefreshCw size={14} className={backups.isFetching ? "animate-spin" : ""} /></button>
          {sessao.podeGerir && <button onClick={() => criarAgora.mutate(credenciais)} disabled={criarAgora.isPending} className="flex items-center gap-2 rounded-lg px-3 py-2 text-xs font-semibold disabled:opacity-60 active:scale-95" style={{ background: "oklch(0.72 0.18 60)", color: "oklch(0.12 0.006 240)" }}><HardDriveDownload size={14} />{criarAgora.isPending ? "A criar…" : "Criar agora"}</button>}
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-5xl flex-col gap-5 p-4 sm:p-6">
        <section className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div className="rounded-xl p-4" style={{ background: "oklch(0.115 0.007 240)", border: "1px solid oklch(0.22 0.008 240)" }}><CalendarClock size={17} style={{ color: "oklch(0.82 0.16 60)" }} /><p className="mt-3 text-xs font-semibold uppercase tracking-wide" style={{ color: "oklch(0.48 0.01 240)" }}>Frequência</p><p className="mt-1 text-sm font-semibold" style={{ color: "oklch(0.86 0.005 240)" }}>Domingo, 03:00 UTC</p></div>
          <div className="rounded-xl p-4" style={{ background: "oklch(0.115 0.007 240)", border: "1px solid oklch(0.22 0.008 240)" }}><ArchiveRestore size={17} style={{ color: "#22C55E" }} /><p className="mt-3 text-xs font-semibold uppercase tracking-wide" style={{ color: "oklch(0.48 0.01 240)" }}>Retenção</p><p className="mt-1 text-sm font-semibold" style={{ color: "oklch(0.86 0.005 240)" }}>12 semanas</p></div>
          <div className="rounded-xl p-4" style={{ background: "oklch(0.115 0.007 240)", border: "1px solid oklch(0.22 0.008 240)" }}><FileSpreadsheet size={17} style={{ color: "#22C55E" }} /><p className="mt-3 text-xs font-semibold uppercase tracking-wide" style={{ color: "oklch(0.48 0.01 240)" }}>Formato</p><p className="mt-1 text-sm font-semibold" style={{ color: "oklch(0.86 0.005 240)" }}>Excel (.xlsx)</p></div>
        </section>

        <section className="overflow-hidden rounded-xl" style={{ background: "oklch(0.1 0.006 240)", border: "1px solid oklch(0.22 0.008 240)" }}>
          <div className="flex items-center justify-between gap-3 px-4 py-3" style={{ borderBottom: "1px solid oklch(0.22 0.008 240)" }}><div><h2 className="text-sm font-semibold" style={{ color: "oklch(0.9 0.005 240)" }}>Cópias disponíveis</h2><p className="mt-0.5 text-xs" style={{ color: "oklch(0.48 0.01 240)" }}>Todos os utilizadores autenticados podem exportar estas cópias para Excel e consultar as folhas de dados.</p></div><span className="rounded-full px-2 py-1 font-mono text-xs" style={{ background: "oklch(0.72 0.18 60 / 0.14)", color: "oklch(0.82 0.16 60)" }}>{backups.data?.length ?? 0}</span></div>
          {backups.isLoading ? <div className="flex items-center justify-center gap-2 p-10 text-sm" style={{ color: "oklch(0.5 0.01 240)" }}><Loader2 size={17} className="animate-spin" /> A carregar backups…</div> : backups.error ? <div className="p-6 text-sm" style={{ color: "#EF7777" }}>{backups.error.message}</div> : backups.data?.length === 0 ? <div className="p-10 text-center"><DatabaseBackup size={28} className="mx-auto" style={{ color: "oklch(0.35 0.008 240)" }} /><p className="mt-3 text-sm font-medium" style={{ color: "oklch(0.68 0.01 240)" }}>Ainda não há backups disponíveis.</p><p className="mt-1 text-xs" style={{ color: "oklch(0.45 0.01 240)" }}>A primeira cópia será criada na rotina semanal ou pelo perfil Gestão.</p></div> : <div className="divide-y" style={{ borderColor: "oklch(0.2 0.008 240)" }}>{backups.data?.map(backup => <article key={backup.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center"><div className="flex min-w-0 flex-1 items-center gap-3"><div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg" style={{ background: "oklch(0.72 0.18 60 / 0.12)", color: "oklch(0.82 0.16 60)" }}><FileSpreadsheet size={17} /></div><div className="min-w-0"><p className="truncate text-sm font-medium" style={{ color: "oklch(0.86 0.005 240)" }}>{backup.nomeFicheiro.replace(/\.json$/i, ".xlsx")}</p><p className="mt-0.5 text-xs" style={{ color: "oklch(0.48 0.01 240)" }}>{formatarData(backup.criadoEm)} · exportação Excel · disponível até {new Date(backup.expiraEm).toLocaleDateString("pt-PT")}</p></div></div><div className="flex gap-2"><button onClick={() => descarregar(backup.id)} disabled={download.isPending} className="flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold disabled:opacity-60" style={{ border: "1px solid #22C55E55", color: "#4ADE80" }}><FileSpreadsheet size={13} /> Exportar Excel</button>{sessao.podeGerir && <button onClick={() => { setARecuperar(backup.id); setConfirmacao(""); }} className="flex items-center justify-center gap-1.5 rounded-lg px-3 py-2 text-xs font-semibold" style={{ border: "1px solid #EF444455", color: "#EF7777" }}><ArchiveRestore size={13} /> Recuperar</button>}</div></article>)}</div>}
        </section>
      </main>

      {aRecuperar && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4"><section className="w-full max-w-md rounded-2xl p-5" style={{ background: "oklch(0.12 0.008 240)", border: "1px solid #EF444466" }}><div className="flex items-center gap-2"><ShieldAlert size={18} style={{ color: "#EF7777" }} /><h2 className="font-semibold" style={{ color: "oklch(0.92 0.005 240)" }}>Recuperar backup</h2></div><p className="mt-3 text-sm leading-relaxed" style={{ color: "oklch(0.66 0.01 240)" }}>Esta ação substitui intervenções, anexos, áreas e equipamentos personalizados pelos dados da cópia escolhida. Antes disso, será criado automaticamente um backup de segurança.</p><label className="mt-4 block text-xs font-semibold uppercase tracking-wide" style={{ color: "oklch(0.5 0.01 240)" }}>Escreva RESTAURAR para confirmar</label><input value={confirmacao} onChange={e => setConfirmacao(e.target.value)} className="mt-2 w-full rounded-lg px-3 py-2 text-sm outline-none" style={{ background: "oklch(0.085 0.005 240)", color: "oklch(0.9 0.005 240)", border: "1px solid oklch(0.3 0.008 240)" }} /><div className="mt-5 flex justify-end gap-2"><button onClick={() => setARecuperar(null)} className="rounded-lg px-3 py-2 text-xs font-medium" style={{ color: "oklch(0.65 0.01 240)" }}>Cancelar</button><button disabled={confirmacao !== "RESTAURAR" || restaurar.isPending} onClick={() => restaurar.mutate({ ...credenciais, id: aRecuperar, confirmacao: "RESTAURAR" })} className="rounded-lg px-3 py-2 text-xs font-semibold disabled:opacity-50" style={{ background: "#EF4444", color: "white" }}>{restaurar.isPending ? "A recuperar…" : "Confirmar recuperação"}</button></div></section></div>}
    </div>
  );
}
