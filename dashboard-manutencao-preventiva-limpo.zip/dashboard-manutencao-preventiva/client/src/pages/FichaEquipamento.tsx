/**
 * FichaEquipamento — Vista detalhada de um equipamento
 * Design: Industrial Dark Analytics
 * Mostra: informações completas + histórico de manutenções + anexos
 * Rota: /equipamento/:codigo/:area (area em base64 UTF-8)
 * Dados: recebidos via location state (Equipamento completo) ou carregados via tRPC + JSON
 */
import { useState, useMemo, useEffect } from 'react';
import { useLocation, useParams } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Wrench, MapPin, Factory, RefreshCw, Calendar,
  ClipboardList, Hash, Tag, Activity, CheckCircle2, AlertTriangle,
  Paperclip, FileText, Image as ImageIcon, Trash2,
  ExternalLink, ChevronDown, ChevronUp, Info, ShieldCheck, Pencil,
} from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { useRealizacoesContext } from '@/contexts/RealizacoesContext';
import { ESTADO_LABELS, formatDate } from '@/lib/utils';
import { calcularProxima, calcularEstadoPrazo } from '@/hooks/useRealizacoes';
import type { Equipamento, EstadoPrazo } from '@/lib/types';
import { ModalRealizacao } from '@/components/ModalRealizacao';
import { ModalValidacao } from '@/components/ModalValidacao';
import { ModalEditarIntervencao } from '@/components/ModalEditarIntervencao';
import type { IntervencaoDb } from '@/contexts/RealizacoesContext';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function estadoColor(estado: EstadoPrazo): string {
  const map: Record<EstadoPrazo, string> = {
    vencido: '#EF4444',
    proximo: 'oklch(0.82 0.18 60)',
    em_dia: '#22C55E',
    inativo: 'oklch(0.45 0.01 240)',
    sem_periodicidade: 'oklch(0.52 0.01 240)',
  };
  return map[estado] ?? 'oklch(0.52 0.01 240)';
}

function decodeArea(encoded: string): string {
  try {
    return decodeURIComponent(escape(atob(encoded)));
  } catch {
    try { return atob(encoded); }
    catch { return encoded; }
  }
}

function InfoCard({ label, value, icon: Icon, fullWidth, multiline }: { label: string; value: string | null | undefined; icon?: React.ElementType; fullWidth?: boolean; multiline?: boolean }) {
  return (
    <div
      className="flex flex-col gap-1 p-3 rounded-lg"
      style={{ background: 'oklch(0.12 0.006 240)', border: '1px solid oklch(0.2 0.008 240)' }}
    >
      <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.48 0.01 240)' }}>
        {Icon && <Icon size={10} className="inline mr-1" />}{label}
      </span>
      {multiline
        ? <p className="text-sm whitespace-pre-wrap leading-relaxed" style={{ color: value ? 'oklch(0.88 0.005 240)' : 'oklch(0.38 0.01 240)' }}>{value || '—'}</p>
        : <span className="text-sm font-medium" style={{ color: value ? 'oklch(0.88 0.005 240)' : 'oklch(0.38 0.01 240)' }}>{value || '—'}</span>
      }
    </div>
  );
}

// ─── Componente principal ─────────────────────────────────────────────────────

export default function FichaEquipamento() {
  const params = useParams<{ codigo: string; area: string }>();
  const [, setLocation] = useLocation();

  const codigo = decodeURIComponent(params.codigo ?? '');
  const area = decodeArea(params.area ?? '');

  // Tentar obter o equipamento do location state (passado pela tabela ao navegar)
  const locationState = (window.history.state as { equipamento?: Equipamento } | null);
  const equipamentoDoState: Equipamento | null = locationState?.equipamento ?? null;

  const [modalAberto, setModalAberto] = useState(false);
  const [historicoExpandido, setHistoricoExpandido] = useState(true);
  const [intervencaoParaValidar, setIntervencaoParaValidar] = useState<IntervencaoDb | null>(null);
  const [intervencaoParaEditar, setIntervencaoParaEditar] = useState<IntervencaoDb | null>(null);
  const utils = trpc.useUtils();

  // Fallback: carregar dados da BD se não houver state
  const skipQuery = !!equipamentoDoState;
  const { data: equipamentosCustom, isLoading: loadingCustom } = trpc.gestao.listarEquipamentos.useQuery(
    undefined,
    { enabled: !skipQuery, refetchOnWindowFocus: false }
  );
  const { data: overrides, isLoading: loadingOverrides } = trpc.gestao.listarOverrides.useQuery(
    undefined,
    { enabled: !skipQuery, refetchOnWindowFocus: false }
  );

  // Carregar JSON base como fallback final
  const [dadosJson, setDadosJson] = useState<Equipamento[] | null>(null);
  useEffect(() => {
    if (skipQuery) return;
    fetch('/manutencao.json')
      .then(r => r.json())
      .then((d: { equipamentos?: Equipamento[] }) => setDadosJson(d.equipamentos ?? []))
      .catch(() => setDadosJson([]));
  }, [skipQuery]);

  const isLoading = !skipQuery && (loadingCustom || loadingOverrides || dadosJson === null);

  const {
    adicionarIntervencao,
    removerIntervencao,
    uploadAnexo,
    obterIntervencoesPorEquipamento,
    obterUltimaIntervencao,
  } = useRealizacoesContext();

  // Histórico de intervenções
  const historico = useMemo(() => {
    return obterIntervencoesPorEquipamento(codigo, area);
  }, [obterIntervencoesPorEquipamento, codigo, area]);

  const ultimaIntervencao = obterUltimaIntervencao(codigo, area);

  // Construir objeto Equipamento a partir dos dados disponíveis (fallback quando não há state)
  const equipamentoFallback: Equipamento | null = useMemo(() => {
    if (skipQuery) return null;

    // 1. Tentar equipamento custom
    const custom = equipamentosCustom?.find(e => e.codigo === codigo && e.area === area);
    if (custom) {
      const proxima = ultimaIntervencao
        ? calcularProxima(ultimaIntervencao.dataRealizacao, custom.periodicidade ?? '')
        : null;
      const estadoPrazo = proxima ? (calcularEstadoPrazo(proxima) as EstadoPrazo) : 'sem_periodicidade';
      return {
        codigo: custom.codigo,
        equipamento: custom.equipamento,
        area: custom.area,
        estado: custom.inativo ? 'Inativo' : 'Ativo',
        periodicidade: custom.periodicidade ?? '',
        periodicidade_norm: custom.periodicidade ?? '',
        proxima_manutencao: proxima,
        estado_prazo: custom.inativo ? 'inativo' : estadoPrazo,
        dias_ate_vencimento: null,
        fabrica: custom.area.startsWith('F2:') ? 'Fábrica II' : 'Fábrica I',
        id: custom.id,
        isCustom: true,
        modelo: custom.modelo ?? undefined,
        numeroSerie: custom.numeroSerie ?? undefined,
        planoIntervencao: custom.planoIntervencao ?? undefined,
      };
    }

    // 2. Tentar JSON base
    const jsonEq = dadosJson?.find(e => e.codigo === codigo && e.area === area);
    if (jsonEq) {
      const override = overrides?.find(o => o.codigoEquipamento === codigo && o.area === area);
      const eq: Equipamento = {
        ...jsonEq,
        fabrica: jsonEq.area.startsWith('F2:') ? 'Fábrica II' : 'Fábrica I',
        modelo: override?.modelo ?? jsonEq.modelo,
        numeroSerie: override?.numeroSerie ?? jsonEq.numeroSerie,
        planoIntervencao: override?.planoIntervencao ?? jsonEq.planoIntervencao,
        equipamento: override?.novoNome ?? jsonEq.equipamento,
        area: override?.novaArea ?? jsonEq.area,
        periodicidade: override?.novaPeriodicidade ?? jsonEq.periodicidade,
        periodicidade_norm: (override?.novaPeriodicidade ?? jsonEq.periodicidade_norm ?? '').toLowerCase().trim(),
        estado_prazo: override?.inativo ? 'inativo' : jsonEq.estado_prazo,
        estado: override?.inativo ? 'Inativo' : jsonEq.estado,
      };
      if (ultimaIntervencao && eq.periodicidade_norm) {
        const proxima = calcularProxima(ultimaIntervencao.dataRealizacao, eq.periodicidade_norm);
        if (proxima) {
          return {
            ...eq,
            proxima_manutencao: proxima,
            estado_prazo: calcularEstadoPrazo(proxima) as EstadoPrazo,
          };
        }
      }
      return eq;
    }

    return null;
  }, [skipQuery, equipamentosCustom, dadosJson, overrides, codigo, area, ultimaIntervencao]);

  // Equipamento final: state tem prioridade, depois fallback da BD/JSON
  const equipamento: Equipamento | null = equipamentoDoState ?? equipamentoFallback;

  // Recalcular estado com última intervenção se veio do state
  const equipamentoAtualizado: Equipamento | null = useMemo(() => {
    if (!equipamento) return null;
    if (!ultimaIntervencao || !equipamento.periodicidade_norm) return equipamento;
    const proxima = calcularProxima(ultimaIntervencao.dataRealizacao, equipamento.periodicidade_norm);
    if (!proxima) return equipamento;
    return {
      ...equipamento,
      proxima_manutencao: proxima,
      estado_prazo: calcularEstadoPrazo(proxima) as EstadoPrazo,
    };
  }, [equipamento, ultimaIntervencao]);

  // ── Render ──────────────────────────────────────────────────────────────────

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: bg }}>
        <div className="text-center">
          <RefreshCw size={28} className="animate-spin mx-auto mb-3" style={{ color: 'oklch(0.72 0.18 60)' }} />
          <p className="text-sm" style={{ color: 'oklch(0.52 0.01 240)' }}>A carregar ficha do equipamento...</p>
        </div>
      </div>
    );
  }

  const eq = equipamentoAtualizado;
  const nomeDisplay = eq?.equipamento ?? codigo;
  const areaDisplay = eq?.area ?? area;
  const estadoPrazo = eq?.estado_prazo ?? 'sem_periodicidade';

  return (
    <div className="min-h-screen flex flex-col" style={{ background: bg }}>
      {/* Header */}
      <header
        className="ficha-header flex flex-wrap items-center gap-3 px-5 py-3 flex-shrink-0 sticky top-0 z-10"
        style={{ background: cardBg, borderBottom: `1px solid ${borderColor}` }}
      >
        <button
          onClick={() => setLocation('/')}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all active:scale-95"
          style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
        >
          <ArrowLeft size={14} />
          Voltar
        </button>
        <div className="flex items-center gap-2 ml-1">
          <div
            className="w-7 h-7 rounded flex items-center justify-center"
            style={{ background: 'oklch(0.72 0.18 60 / 0.15)', border: '1px solid oklch(0.72 0.18 60 / 0.35)' }}
          >
            <Wrench size={13} style={{ color: 'oklch(0.82 0.16 60)' }} />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Ficha de Equipamento
            </h1>
            <p className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
              {codigo} · {areaDisplay}
            </p>
          </div>
        </div>
        <div className="ficha-header-actions ml-auto flex items-center gap-2">
          <span
            className="text-xs font-semibold px-2.5 py-1 rounded-full"
            style={{
              background: `${estadoColor(estadoPrazo)}22`,
              color: estadoColor(estadoPrazo),
              border: `1px solid ${estadoColor(estadoPrazo)}55`,
            }}
          >
            {ESTADO_LABELS[estadoPrazo] ?? estadoPrazo}
          </span>
          <button
            onClick={() => setModalAberto(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-95"
            style={{ background: 'oklch(0.72 0.18 60)', color: 'oklch(0.1 0.006 240)' }}
          >
            <CheckCircle2 size={13} />
            Registar Manutenção
          </button>
        </div>
      </header>

      {/* Body */}
      <main className="ficha-main flex-1 p-5 flex flex-col gap-5 max-w-5xl mx-auto w-full">

        {/* Aviso se equipamento não encontrado */}
        {!eq && (
          <div
            className="flex items-center gap-3 p-4 rounded-lg"
            style={{ background: 'oklch(0.62 0.22 25 / 0.1)', border: '1px solid oklch(0.62 0.22 25 / 0.3)' }}
          >
            <AlertTriangle size={16} style={{ color: '#EF4444' }} />
            <p className="text-sm" style={{ color: 'oklch(0.78 0.005 240)' }}>
              Equipamento não encontrado nos dados. A mostrar informações parciais.
            </p>
          </div>
        )}

        {/* Bloco de informações */}
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
          className="rounded-xl overflow-hidden"
          style={{ background: cardBg, border: `1px solid ${borderColor}` }}
        >
          <div className="flex items-center gap-2 px-5 py-3" style={{ borderBottom: `1px solid oklch(0.18 0.006 240)` }}>
            <Info size={14} style={{ color: 'oklch(0.72 0.18 60)' }} />
            <h2 className="text-sm font-semibold" style={{ color: 'oklch(0.88 0.005 240)' }}>Informações do Equipamento</h2>
          </div>

          <div className="p-5 flex flex-col gap-4">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
                Designação
              </p>
              <p className="text-xl font-bold" style={{ color: 'oklch(0.92 0.005 240)' }}>{nomeDisplay}</p>
              <p className="text-sm mt-0.5 font-mono" style={{ color: 'oklch(0.55 0.01 240)' }}>Código: {codigo}</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <InfoCard label="Área" value={areaDisplay} icon={MapPin} />
              <InfoCard label="Fábrica" value={eq?.fabrica} icon={Factory} />
              <InfoCard label="Periodicidade" value={eq?.periodicidade || 'Sem periodicidade'} icon={RefreshCw} />
              <InfoCard label="Modelo" value={eq?.modelo} icon={Tag} />
              <InfoCard label="Nº Série" value={eq?.numeroSerie} icon={Hash} />
              <InfoCard
                label="Próxima Manutenção"
                value={eq?.proxima_manutencao ? formatDate(eq.proxima_manutencao) : '—'}
                icon={Calendar}
              />
              <InfoCard
                label="Resp. validação/libertação"
                value={ultimaIntervencao?.responsavelValidacao}
                icon={ShieldCheck}
              />
            </div>

            {/* Plano de Intervenção — sempre visível */}
            <div
              className="rounded-lg p-4"
              style={{ background: 'oklch(0.12 0.006 240)', border: '1px solid oklch(0.2 0.008 240)' }}
            >
              <div className="flex items-center gap-2 mb-2">
                <ClipboardList size={12} style={{ color: 'oklch(0.72 0.18 60)' }} />
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.48 0.01 240)' }}>
                  Plano de Intervenção
                </span>
              </div>
              <p className="text-sm whitespace-pre-wrap leading-relaxed" style={{ color: eq?.planoIntervencao ? 'oklch(0.88 0.005 240)' : 'oklch(0.38 0.01 240)' }}>
                {eq?.planoIntervencao || '—'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {[
                { label: 'Total de Intervenções', value: String(historico.length), color: 'oklch(0.72 0.18 60)' },
                { label: 'Última Intervenção', value: ultimaIntervencao ? formatDate(ultimaIntervencao.dataRealizacao) : '—', color: '#22C55E' },
                { label: 'Estado Atual', value: ESTADO_LABELS[estadoPrazo] ?? estadoPrazo, color: estadoColor(estadoPrazo) },
              ].map(({ label, value, color }) => (
                <div
                  key={label}
                  className="flex flex-col gap-1 p-3 rounded-lg text-center"
                  style={{ background: `${color}11`, border: `1px solid ${color}33` }}
                >
                  <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>{label}</span>
                  <span className="text-base font-bold" style={{ color }}>{value}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* Histórico de Manutenções */}
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3, delay: 0.05, ease: [0.23, 1, 0.32, 1] }}
          className="rounded-xl overflow-hidden"
          style={{ background: cardBg, border: `1px solid ${borderColor}` }}
        >
          <button
            className="w-full flex items-center justify-between px-5 py-3"
            style={{ borderBottom: historicoExpandido ? `1px solid oklch(0.18 0.006 240)` : 'none' }}
            onClick={() => setHistoricoExpandido(v => !v)}
          >
            <div className="flex items-center gap-2">
              <Activity size={14} style={{ color: 'oklch(0.72 0.18 60)' }} />
              <h2 className="text-sm font-semibold" style={{ color: 'oklch(0.88 0.005 240)' }}>
                Histórico de Manutenções
              </h2>
              <span
                className="text-xs font-bold px-2 py-0.5 rounded-full"
                style={{ background: 'oklch(0.72 0.18 60 / 0.15)', color: 'oklch(0.82 0.16 60)' }}
              >
                {historico.length}
              </span>
            </div>
            {historicoExpandido
              ? <ChevronUp size={14} style={{ color: 'oklch(0.52 0.01 240)' }} />
              : <ChevronDown size={14} style={{ color: 'oklch(0.52 0.01 240)' }} />
            }
          </button>

          <AnimatePresence>
            {historicoExpandido && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
                style={{ overflow: 'hidden' }}
              >
                {historico.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-12 gap-3">
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center"
                      style={{ background: 'oklch(0.15 0.006 240)' }}
                    >
                      <ClipboardList size={20} style={{ color: 'oklch(0.35 0.01 240)' }} />
                    </div>
                    <p className="text-sm" style={{ color: 'oklch(0.48 0.01 240)' }}>Sem intervenções registadas</p>
                    <button
                      onClick={() => setModalAberto(true)}
                      className="text-xs font-semibold px-3 py-1.5 rounded-lg transition-all active:scale-95"
                      style={{ background: 'oklch(0.72 0.18 60 / 0.15)', color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.3)' }}
                    >
                      Registar primeira intervenção
                    </button>
                  </div>
                ) : (
                  <div className="p-5 flex flex-col gap-4">
                    {[...historico].sort((a, b) => b.criadoEm - a.criadoEm).map((intervencao, idx) => (
                      <motion.div
                        key={intervencao.id}
                        initial={{ opacity: 0, x: -8 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.2, delay: idx * 0.04, ease: [0.23, 1, 0.32, 1] }}
                        className="rounded-lg p-4 flex flex-col gap-3"
                        style={{ background: 'oklch(0.12 0.006 240)', border: '1px solid oklch(0.2 0.008 240)' }}
                      >
                        <div className="ficha-intervencao-header flex items-start justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <div
                              className="w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0"
                              style={{
                                background: intervencao.validadoEm ? '#22C55E22' : 'oklch(0.72 0.18 60 / 0.12)',
                                border: `1px solid ${intervencao.validadoEm ? '#22C55E44' : 'oklch(0.72 0.18 60 / 0.3)'}`,
                              }}
                            >
                              <CheckCircle2 size={12} style={{ color: intervencao.validadoEm ? '#22C55E' : 'oklch(0.82 0.16 60)' }} />
                            </div>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="text-sm font-semibold" style={{ color: 'oklch(0.88 0.005 240)' }}>
                                  {formatDate(intervencao.dataRealizacao)}
                                </p>
                                {intervencao.validadoEm ? (
                                  <span className="text-xs px-1.5 py-0.5 rounded-full flex items-center gap-1" style={{ background: '#22C55E11', color: '#22C55E', border: '1px solid #22C55E33' }}>
                                    <ShieldCheck size={9} /> Validado
                                  </span>
                                ) : (
                                  <span className="text-xs px-1.5 py-0.5 rounded-full" style={{ background: 'oklch(0.72 0.18 60 / 0.1)', color: 'oklch(0.72 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.3)' }}>
                                    Por validar
                                  </span>
                                )}
                              </div>
                              {intervencao.responsavel && (
                                <p className="text-xs" style={{ color: 'oklch(0.52 0.01 240)' }}>
                                  Técnico: {intervencao.responsavel}
                                </p>
                              )}
                              {intervencao.responsavelValidacao && (
                                <p className="text-xs" style={{ color: 'oklch(0.52 0.01 240)' }}>
                                  Resp. validação/libertação: <span style={{ color: 'oklch(0.78 0.005 240)' }}>{intervencao.responsavelValidacao}</span>
                                </p>
                              )}
                              {intervencao.validadoPor && (
                                <p className="text-xs" style={{ color: '#22C55E88' }}>
                                  Validado por: <span style={{ color: '#22C55E' }}>{intervencao.validadoPor}</span>
                                </p>
                              )}
                            </div>
                          </div>
                          <div className="ficha-intervencao-actions flex items-center gap-1.5">
                            <button
                              onClick={() => setIntervencaoParaEditar(intervencao)}
                              className="p-1.5 rounded transition-all hover:opacity-80 active:scale-95"
                              style={{ color: 'oklch(0.72 0.18 60)' }}
                              title="Editar intervenção, material e validação"
                            >
                              <Pencil size={13} />
                            </button>
                            {!intervencao.validadoEm && (
                              <button
                                onClick={() => setIntervencaoParaValidar(intervencao)}
                                className="flex items-center gap-1 px-2 py-1 rounded text-xs font-semibold transition-all active:scale-95"
                                style={{ background: '#22C55E', color: '#0a1a0a' }}
                                title="Validar intervenção"
                              >
                                <ShieldCheck size={11} />
                                Validar
                              </button>
                            )}
                            <button
                              onClick={() => removerIntervencao(intervencao.id)}
                              className="p-1.5 rounded transition-all hover:opacity-80 active:scale-95"
                              style={{ color: 'oklch(0.45 0.01 240)' }}
                              title="Remover intervenção"
                            >
                              <Trash2 size={13} />
                            </button>
                          </div>
                        </div>

                        {intervencao.intervencaoRealizada && (
                          <div>
                            <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.45 0.01 240)' }}>
                              Intervenção Realizada
                            </p>
                            <p className="text-sm whitespace-pre-wrap leading-relaxed" style={{ color: 'oklch(0.78 0.005 240)' }}>
                              {intervencao.intervencaoRealizada}
                            </p>
                          </div>
                        )}

                        {intervencao.materialGasto && (
                          <div>
                            <p className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: 'oklch(0.45 0.01 240)' }}>
                              Material Gasto
                            </p>
                            <p className="text-sm" style={{ color: 'oklch(0.78 0.005 240)' }}>{intervencao.materialGasto}</p>
                          </div>
                        )}

                        {intervencao.anexos && intervencao.anexos.length > 0 && (
                          <div>
                            <p className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: 'oklch(0.45 0.01 240)' }}>
                              <Paperclip size={10} className="inline mr-1" />
                              Anexos ({intervencao.anexos.length})
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {intervencao.anexos.map(anexo => {
                                const isImg = anexo.mimeType?.startsWith('image/');
                                return (
                                  <a
                                    key={anexo.id}
                                    href={anexo.storageUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all hover:opacity-80"
                                    style={{
                                      background: 'oklch(0.15 0.006 240)',
                                      color: 'oklch(0.72 0.18 60)',
                                      border: '1px solid oklch(0.25 0.008 240)',
                                      maxWidth: '180px',
                                    }}
                                  >
                                    {isImg ? <ImageIcon size={11} /> : <FileText size={11} />}
                                    <span className="truncate">{anexo.filename}</span>
                                    <ExternalLink size={10} className="flex-shrink-0" />
                                  </a>
                                );
                              })}
                            </div>
                          </div>
                        )}

                      </motion.div>
                    ))}
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </motion.section>
      </main>

        {/* Modal de validação */}
      {intervencaoParaValidar && (
        <ModalValidacao
          intervencao={{ ...intervencaoParaValidar, nomeEquipamento: nomeDisplay }}
          onValidada={() => {
            setIntervencaoParaValidar(null);
            utils.intervencoes.listarTodas.invalidate();
            utils.intervencoes.listarPorValidar.invalidate();
          }}
          onFechar={() => setIntervencaoParaValidar(null)}
        />
      )}

      {intervencaoParaEditar && (
        <ModalEditarIntervencao
          intervencao={intervencaoParaEditar}
          onGuardada={() => setIntervencaoParaEditar(null)}
          onFechar={() => setIntervencaoParaEditar(null)}
        />
      )}

      {/* Modal de registo de manução */}
      {modalAberto && eq && (
        <ModalRealizacao
          equipamento={eq}
          historico={historico}
          onAdicionar={(data, intervencaoRealizada, materialGasto, responsavel, responsavelValidacao) =>
            adicionarIntervencao(codigo, area, data, intervencaoRealizada, materialGasto, responsavel, responsavelValidacao)
          }
          onRemoverIntervencao={removerIntervencao}
          onUploadAnexo={uploadAnexo}
          onFechar={() => setModalAberto(false)}
        />
      )}
    </div>
  );
}
