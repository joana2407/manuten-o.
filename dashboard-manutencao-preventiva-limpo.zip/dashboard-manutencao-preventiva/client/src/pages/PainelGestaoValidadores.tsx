/*
 * PainelGestaoValidadores — Gestão de utilizadores com acesso ao painel de validações
 * Design: Industrial Dark Analytics
 * Acesso: PIN individual da Gestão ou Responsável de Qualidade para gestão de PINs.
 */
import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { motion, AnimatePresence } from 'framer-motion';
import {
  ArrowLeft, Shield, Lock, Eye, EyeOff, RefreshCw, Plus,
  UserCheck, UserX, Pencil, Trash2, KeyRound, User, Check, X,
} from 'lucide-react';
import { SeletorUtilizadorAcesso } from '@/components/SeletorUtilizadorAcesso';
import { autenticarUtilizadorLocal, alterarPinUtilizadorLocal, criarUtilizadorLocal, eliminarUtilizadorLocal, alterarEstadoUtilizadorLocal, listarUtilizadoresLocais } from '@/lib/localAccess';

// ─── Sessão de gestão ─────────────────────────────────────────────────────────

const SESSAO_GESTAO_KEY = 'gestao_validadores_sessao';
type SessaoGestao = { nomeUtilizador: string; codigoAcesso: string; podeGerir: boolean; podeGerirPins: boolean; podeGerirUtilizadores: boolean };

function guardarSessaoGestao(sessao: SessaoGestao) {
  sessionStorage.setItem(SESSAO_GESTAO_KEY, JSON.stringify(sessao));
}
function carregarSessaoGestao(): SessaoGestao | null {
  try {
    const valor = sessionStorage.getItem(SESSAO_GESTAO_KEY);
    const sessao = valor ? JSON.parse(valor) as SessaoGestao : null;
    return sessao?.nomeUtilizador && sessao.codigoAcesso && typeof sessao.podeGerirUtilizadores === 'boolean' ? sessao : null;
  } catch {
    return null;
  }
}
function limparSessaoGestao() {
  sessionStorage.removeItem(SESSAO_GESTAO_KEY);
}

// ─── Ecrã de Login de Gestão ──────────────────────────────────────────────────

function EcraLoginGestao({ onLogin }: { onLogin: (sessao: SessaoGestao) => void }) {
  const [nomeUtilizador, setNomeUtilizador] = useState('');
  const [codigo, setCodigo] = useState('');
  const [mostrar, setMostrar] = useState(false);
  const [erro, setErro] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  const [aAutenticar, setAAutenticar] = useState(false);

  useEffect(() => { inputRef.current?.focus(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nomeUtilizador.trim() || !codigo.trim()) return;
    setErro('');
    setAAutenticar(true);
    try {
      const resultado = autenticarUtilizadorLocal(nomeUtilizador.trim(), codigo.trim());
      if (!resultado.podeGerirUtilizadores) throw new Error('Acesso de Qualidade ou Gestão necessário');
      const sessao = { nomeUtilizador: nomeUtilizador.trim(), codigoAcesso: codigo.trim(), podeGerir: resultado.podeGerir, podeGerirPins: resultado.podeGerirPins, podeGerirUtilizadores: resultado.podeGerirUtilizadores };
      guardarSessaoGestao(sessao);
      onLogin(sessao);
    } catch {
      setErro('O PIN não corresponde ao utilizador selecionado ou não autoriza a gestão de PINs.');
      setCodigo('');
      inputRef.current?.focus();
    } finally {
      setAAutenticar(false);
    }
  };

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  return (
    <div className="min-h-screen flex flex-col items-center justify-center" style={{ background: bg }}>
      <motion.div
        initial={{ opacity: 0, y: 16, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.25, ease: [0.23, 1, 0.32, 1] }}
        className="w-full max-w-sm mx-4"
      >
        <div className="flex flex-col items-center gap-3 mb-8">
          <div
            className="w-14 h-14 rounded-2xl flex items-center justify-center"
            style={{ background: 'oklch(0.72 0.18 60 / 0.15)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}
          >
            <Shield size={24} style={{ color: 'oklch(0.82 0.16 60)' }} />
          </div>
          <div className="text-center">
            <h1 className="text-lg font-bold" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Gestão de Validadores
            </h1>
            <p className="text-sm mt-1" style={{ color: 'oklch(0.48 0.01 240)' }}>
              Selecione Gestão ou Responsável de Qualidade e introduza o respetivo PIN
            </p>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex flex-col gap-4 p-6 rounded-2xl"
          style={{ background: cardBg, border: `1px solid ${borderColor}` }}
        >
          <SeletorUtilizadorAcesso value={nomeUtilizador} onChange={utilizador => { setNomeUtilizador(utilizador); setErro(''); }} apenasGestaoPins disabled={aAutenticar} />
          <div className="flex flex-col gap-2">
            <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
              PIN de acesso
            </label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg"
              style={{ background: 'oklch(0.085 0.005 240)', border: `1px solid ${erro ? '#EF4444' : borderColor}` }}
            >
              <Lock size={14} style={{ color: 'oklch(0.45 0.01 240)' }} />
              <input
                ref={inputRef}
                type={mostrar ? 'text' : 'password'}
                value={codigo}
                onChange={e => { setCodigo(e.target.value); setErro(''); }}
                placeholder="Introduza o PIN"
                className="flex-1 bg-transparent text-sm outline-none"
                style={{ color: 'oklch(0.88 0.005 240)' }}
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setMostrar(v => !v)}
                className="transition-opacity hover:opacity-70"
                style={{ color: 'oklch(0.45 0.01 240)' }}
              >
                {mostrar ? <EyeOff size={14} /> : <Eye size={14} />}
              </button>
            </div>
            {erro && (
              <motion.p
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-xs"
                style={{ color: '#EF4444' }}
              >
                {erro}
              </motion.p>
            )}
          </div>

          <button
            type="submit"
            disabled={!nomeUtilizador.trim() || !codigo.trim() || aAutenticar}
            className="flex items-center justify-center gap-2 py-2.5 rounded-lg text-sm font-semibold transition-all active:scale-95 disabled:opacity-50"
            style={{ background: 'oklch(0.72 0.18 60)', color: 'oklch(0.1 0.006 240)' }}
          >
            {aAutenticar ? <RefreshCw size={14} className="animate-spin" /> : <Shield size={14} />}
            {aAutenticar ? 'A verificar...' : 'Entrar'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}

// ─── Modal de Criar/Editar Validador ─────────────────────────────────────────

interface ModalValidadorProps {
  modo: 'criar' | 'pin';
  validador?: { id: string; nome: string };
  nomeUtilizador: string;
  codigoAcesso: string;
  onFechado: () => void;
  onSucesso: () => void;
}

function ModalValidador({ modo, validador, nomeUtilizador, codigoAcesso, onFechado, onSucesso }: ModalValidadorProps) {
  const [nome, setNome] = useState('');
  const [nomeUtilizadorNovo, setNomeUtilizadorNovo] = useState('');
  const [pin, setPin] = useState('');
  const [confirmarPin, setConfirmarPin] = useState('');
  const [mostrarPin, setMostrarPin] = useState(false);
  const [erro, setErro] = useState('');

  const [isPending, setIsPending] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErro('');

    if (pin.length < 4) {
      setErro('O PIN deve ter pelo menos 4 caracteres.');
      return;
    }
    if (pin !== confirmarPin) {
      setErro('Os PINs não coincidem.');
      return;
    }

    try {
      setIsPending(true);
      if (modo === 'criar') {
        if (!nome.trim()) { setErro('O nome é obrigatório.'); return; }
        if (!nomeUtilizadorNovo.trim()) { setErro('O nome de utilizador é obrigatório.'); return; }
        criarUtilizadorLocal(nome.trim(), nomeUtilizadorNovo.trim(), pin);
      } else {
        alterarPinUtilizadorLocal(validador!.id, pin);
      }
      onSucesso();
    } catch (err: unknown) {
      setErro(err instanceof Error ? err.message : 'Erro ao guardar.');
    } finally {
      setIsPending(false);
    }
  };

  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';
  const inputBg = 'oklch(0.085 0.005 240)';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
      style={{ background: 'oklch(0 0 0 / 0.7)' }}
      onClick={e => { if (e.target === e.currentTarget) onFechado(); }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 12 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 12 }}
        transition={{ duration: 0.2, ease: [0.23, 1, 0.32, 1] }}
        className="w-full max-w-sm rounded-2xl p-6 flex flex-col gap-4"
        style={{ background: cardBg, border: `1px solid ${borderColor}` }}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-base font-semibold" style={{ color: 'oklch(0.92 0.005 240)' }}>
            {modo === 'criar' ? 'Novo Validador' : `Alterar PIN — ${validador?.nome}`}
          </h2>
          <button onClick={onFechado} className="p-1 rounded hover:opacity-70" style={{ color: 'oklch(0.48 0.01 240)' }}>
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-3">
          {modo === 'criar' && (
            <>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
                Nome
              </label>
              <div
                className="flex items-center gap-2 px-3 py-2.5 rounded-lg"
                style={{ background: inputBg, border: `1px solid ${borderColor}` }}
              >
                <User size={13} style={{ color: 'oklch(0.45 0.01 240)' }} />
                <input
                  type="text"
                  value={nome}
                  onChange={e => setNome(e.target.value)}
                  placeholder="Nome completo"
                  className="flex-1 bg-transparent text-sm outline-none"
                  style={{ color: 'oklch(0.88 0.005 240)' }}
                  autoFocus
                />
              </div>
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>Nome de Utilizador</label>
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-lg" style={{ background: inputBg, border: `1px solid ${borderColor}` }}>
                <User size={13} style={{ color: 'oklch(0.45 0.01 240)' }} />
                <input type="text" value={nomeUtilizadorNovo} onChange={e => setNomeUtilizadorNovo(e.target.value)} placeholder="Ex.: nome.apelido" autoCapitalize="none" autoCorrect="off" className="flex-1 bg-transparent text-sm outline-none" style={{ color: 'oklch(0.88 0.005 240)' }} />
              </div>
            </div>
            </>
          )}

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
              {modo === 'criar' ? 'PIN' : 'Novo PIN'}
            </label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg"
              style={{ background: inputBg, border: `1px solid ${borderColor}` }}
            >
              <KeyRound size={13} style={{ color: 'oklch(0.45 0.01 240)' }} />
              <input
                type={mostrarPin ? 'text' : 'password'}
                value={pin}
                onChange={e => setPin(e.target.value)}
                placeholder="Mínimo 4 caracteres"
                className="flex-1 bg-transparent text-sm outline-none"
                style={{ color: 'oklch(0.88 0.005 240)' }}
                autoFocus={modo === 'pin'}
              />
              <button
                type="button"
                onClick={() => setMostrarPin(v => !v)}
                className="hover:opacity-70"
                style={{ color: 'oklch(0.45 0.01 240)' }}
              >
                {mostrarPin ? <EyeOff size={13} /> : <Eye size={13} />}
              </button>
            </div>
          </div>

          <div className="flex flex-col gap-1.5">
            <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.52 0.01 240)' }}>
              Confirmar PIN
            </label>
            <div
              className="flex items-center gap-2 px-3 py-2.5 rounded-lg"
              style={{ background: inputBg, border: `1px solid ${erro && erro.includes('coincidem') ? '#EF4444' : borderColor}` }}
            >
              <KeyRound size={13} style={{ color: 'oklch(0.45 0.01 240)' }} />
              <input
                type={mostrarPin ? 'text' : 'password'}
                value={confirmarPin}
                onChange={e => setConfirmarPin(e.target.value)}
                placeholder="Repetir PIN"
                className="flex-1 bg-transparent text-sm outline-none"
                style={{ color: 'oklch(0.88 0.005 240)' }}
              />
            </div>
          </div>

          {erro && (
            <p className="text-xs" style={{ color: '#EF4444' }}>{erro}</p>
          )}

          <div className="flex gap-2 mt-1">
            <button
              type="button"
              onClick={onFechado}
              className="flex-1 py-2 rounded-lg text-sm font-medium transition-all active:scale-95"
              style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.62 0.01 240)', border: `1px solid ${borderColor}` }}
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isPending}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition-all active:scale-95 disabled:opacity-50"
              style={{ background: 'oklch(0.72 0.18 60)', color: 'oklch(0.1 0.006 240)' }}
            >
              {isPending ? <RefreshCw size={13} className="animate-spin" /> : <Check size={13} />}
              {isPending ? 'A guardar...' : 'Guardar'}
            </button>
          </div>
        </form>
      </motion.div>
    </div>
  );
}

// ─── Painel Principal ─────────────────────────────────────────────────────────

export default function PainelGestaoValidadores() {
  const [, setLocation] = useLocation();
  const [sessaoGestao, setSessaoGestao] = useState<SessaoGestao | null>(() => carregarSessaoGestao());
  const [modal, setModal] = useState<{ modo: 'criar' | 'pin'; validador?: { id: string; nome: string } } | null>(null);
  const [confirmEliminar, setConfirmEliminar] = useState<{ id: string; nome: string } | null>(null);

  const [validadores, setValidadores] = useState(() => listarUtilizadoresLocais());
  const [isLoading] = useState(false);
  const recarregar = () => setValidadores(listarUtilizadoresLocais());
  const toggleMut = {
    isPending: false,
    mutate: ({ id, ativo }: { id: string; ativo: boolean }) => {
      alterarEstadoUtilizadorLocal(id, ativo);
      recarregar();
    },
  };
  const eliminarMut = {
    isPending: false,
    mutate: ({ id }: { id: string }) => {
      eliminarUtilizadorLocal(id);
      setConfirmEliminar(null);
      recarregar();
    },
  };

  const handleLogout = () => {
    limparSessaoGestao();
    setSessaoGestao(null);
  };

  const bg = 'oklch(0.085 0.005 240)';
  const cardBg = 'oklch(0.1 0.006 240)';
  const borderColor = 'oklch(0.22 0.008 240)';

  if (!sessaoGestao) {
    return <EcraLoginGestao onLogin={setSessaoGestao} />;
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: bg }}>
      {/* Header */}
      <header
        className="flex items-center gap-3 px-5 py-3 flex-shrink-0 sticky top-0 z-10"
        style={{ background: cardBg, borderBottom: `1px solid ${borderColor}` }}
      >
        <button
          onClick={() => setLocation('/validacoes')}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-all active:scale-95"
          style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
        >
          <ArrowLeft size={14} />
          Validações
        </button>
        <div className="flex items-center gap-2 ml-1">
          <div
            className="w-7 h-7 rounded flex items-center justify-center"
            style={{ background: 'oklch(0.72 0.18 60 / 0.15)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}
          >
            <Shield size={13} style={{ color: 'oklch(0.82 0.16 60)' }} />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Gestão de Validadores
            </h1>
            <p className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Gestão total de utilizadores disponível para Gestão e Responsável de Qualidade
            </p>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {sessaoGestao.podeGerirUtilizadores && <button
            onClick={() => setModal({ modo: 'criar' })}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all active:scale-95"
            style={{ background: 'oklch(0.72 0.18 60)', color: 'oklch(0.1 0.006 240)' }}
          >
            <Plus size={12} />
            Novo Validador
          </button>}
          <button
            onClick={handleLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95"
            style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.55 0.01 240)', border: `1px solid ${borderColor}` }}
          >
            <Lock size={12} />
            Sair
          </button>
        </div>
      </header>

      {/* Body */}
      <main className="flex-1 p-5 max-w-3xl mx-auto w-full">
        {isLoading ? (
          <div className="flex items-center justify-center py-20">
            <RefreshCw size={24} className="animate-spin" style={{ color: 'oklch(0.72 0.18 60)' }} />
          </div>
        ) : (
          <div className="flex flex-col gap-3">
            {/* Cabeçalho da lista */}
            <div className="flex items-center justify-between mb-1">
              <p className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'oklch(0.45 0.01 240)' }}>
                {validadores.length} validador{validadores.length !== 1 ? 'es' : ''} registado{validadores.length !== 1 ? 's' : ''}
              </p>
            </div>

            {validadores.map((v, idx) => (
              <motion.div
                key={v.id}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18, delay: idx * 0.04, ease: [0.23, 1, 0.32, 1] }}
                className="flex items-center gap-3 px-4 py-3 rounded-xl"
                style={{
                  background: cardBg,
                  border: `1px solid ${v.ativo ? borderColor : 'oklch(0.18 0.006 240)'}`,
                  opacity: v.ativo ? 1 : 0.6,
                }}
              >
                {/* Avatar */}
                <div
                  className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 text-sm font-bold"
                  style={{
                    background: v.ativo ? 'oklch(0.72 0.18 60 / 0.12)' : 'oklch(0.15 0.006 240)',
                    border: `1px solid ${v.ativo ? 'oklch(0.72 0.18 60 / 0.3)' : 'oklch(0.22 0.008 240)'}`,
                    color: v.ativo ? 'oklch(0.82 0.16 60)' : 'oklch(0.45 0.01 240)',
                  }}
                >
                  {v.nome.charAt(0).toUpperCase()}
                </div>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold" style={{ color: v.ativo ? 'oklch(0.88 0.005 240)' : 'oklch(0.55 0.01 240)' }}>
                    {v.nome}
                  </p>
                  <p className="text-xs mt-0.5" style={{ color: 'oklch(0.42 0.008 240)' }}>
                    Criado em {new Date(v.criadoEm).toLocaleDateString('pt-PT')}
                  </p>
                  {v.nomeUtilizador && (
                    <p className="text-xs mt-0.5 font-mono" style={{ color: 'oklch(0.62 0.01 240)' }}>
                      @{v.nomeUtilizador}
                    </p>
                  )}
                </div>

                {/* Badge estado */}
                <span
                  className="text-xs font-semibold px-2 py-0.5 rounded-full flex items-center gap-1"
                  style={v.ativo
                    ? { background: '#22C55E11', color: '#22C55E', border: '1px solid #22C55E33' }
                    : { background: 'oklch(0.15 0.006 240)', color: 'oklch(0.45 0.01 240)', border: `1px solid ${borderColor}` }
                  }
                >
                  {v.ativo ? <UserCheck size={10} /> : <UserX size={10} />}
                  {v.ativo ? 'Ativo' : 'Inativo'}
                </span>

                {/* Ações */}
                <div className="flex items-center gap-1.5 flex-shrink-0">
                  {/* Alterar PIN */}
                  <button
                    onClick={() => setModal({ modo: 'pin', validador: { id: v.id, nome: v.nome } })}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95 hover:opacity-80"
                    style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.72 0.18 60)', border: '1px solid oklch(0.25 0.008 240)' }}
                    title="Alterar PIN"
                  >
                    <KeyRound size={11} />
                    PIN
                  </button>

                  {/* Ativar/Desativar */}
                  {sessaoGestao.podeGerirUtilizadores && <button
                    onClick={() => toggleMut.mutate({ id: v.id, ativo: !v.ativo })}
                    disabled={toggleMut.isPending}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium transition-all active:scale-95 hover:opacity-80"
                    style={{
                      background: v.ativo ? 'oklch(0.15 0.006 240)' : '#22C55E22',
                      color: v.ativo ? 'oklch(0.55 0.01 240)' : '#22C55E',
                      border: `1px solid ${v.ativo ? borderColor : '#22C55E44'}`,
                    }}
                    title={v.ativo ? 'Desativar' : 'Ativar'}
                  >
                    {v.ativo ? <UserX size={11} /> : <UserCheck size={11} />}
                    {v.ativo ? 'Desativar' : 'Ativar'}
                  </button>}

                  {/* Eliminar */}
                  {sessaoGestao.podeGerirUtilizadores && <button
                    onClick={() => setConfirmEliminar({ id: v.id, nome: v.nome })}
                    className="p-1.5 rounded-lg transition-all active:scale-95 hover:opacity-80"
                    style={{ background: 'oklch(0.15 0.006 240)', color: '#EF4444', border: `1px solid oklch(0.22 0.008 240)` }}
                    title="Eliminar"
                  >
                    <Trash2 size={13} />
                  </button>}
                </div>
              </motion.div>
            ))}

            {validadores.length === 0 && (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{ background: 'oklch(0.15 0.006 240)', border: `1px solid ${borderColor}` }}
                >
                  <User size={20} style={{ color: 'oklch(0.45 0.01 240)' }} />
                </div>
                <p className="text-sm" style={{ color: 'oklch(0.48 0.01 240)' }}>
                  Nenhum validador registado. Crie o primeiro com o botão acima.
                </p>
              </div>
            )}
          </div>
        )}
      </main>

      {/* Modal criar/alterar PIN */}
      <AnimatePresence>
        {modal && (
          <ModalValidador
            modo={modal.modo}
            validador={modal.validador}
            nomeUtilizador={sessaoGestao.nomeUtilizador}
            codigoAcesso={sessaoGestao.codigoAcesso}
            onFechado={() => setModal(null)}
            onSucesso={() => { setModal(null); recarregar(); }}
          />
        )}
      </AnimatePresence>

      {/* Confirmação de eliminação */}
      <AnimatePresence>
        {confirmEliminar && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4"
            style={{ background: 'oklch(0 0 0 / 0.7)' }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.18, ease: [0.23, 1, 0.32, 1] }}
              className="w-full max-w-sm rounded-2xl p-6 flex flex-col gap-4"
              style={{ background: cardBg, border: '1px solid #EF444433' }}
            >
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ background: '#EF444422', border: '1px solid #EF444444' }}
                >
                  <Trash2 size={18} style={{ color: '#EF4444' }} />
                </div>
                <div>
                  <h3 className="text-sm font-semibold" style={{ color: 'oklch(0.92 0.005 240)' }}>
                    Eliminar validador
                  </h3>
                  <p className="text-xs mt-0.5" style={{ color: 'oklch(0.48 0.01 240)' }}>
                    "{confirmEliminar.nome}" será removido permanentemente.
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setConfirmEliminar(null)}
                  className="flex-1 py-2 rounded-lg text-sm font-medium transition-all active:scale-95"
                  style={{ background: 'oklch(0.15 0.006 240)', color: 'oklch(0.62 0.01 240)', border: `1px solid ${borderColor}` }}
                >
                  Cancelar
                </button>
                <button
                  onClick={() => eliminarMut.mutate({ id: confirmEliminar.id })}
                  disabled={eliminarMut.isPending}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-sm font-semibold transition-all active:scale-95 disabled:opacity-50"
                  style={{ background: '#EF4444', color: '#fff' }}
                >
                  {eliminarMut.isPending ? <RefreshCw size={13} className="animate-spin" /> : <Trash2 size={13} />}
                  {eliminarMut.isPending ? 'A eliminar...' : 'Eliminar'}
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
