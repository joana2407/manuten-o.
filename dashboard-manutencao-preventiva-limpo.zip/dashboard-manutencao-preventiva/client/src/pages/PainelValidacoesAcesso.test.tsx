// @vitest-environment jsdom
import React from "react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";

const trpcMock = vi.hoisted(() => ({
  listarPorValidar: vi.fn(() => ({ data: [], isLoading: false, refetch: vi.fn() })),
  listarTodas: vi.fn(() => ({ data: [], isLoading: false })),
  validarComSessao: vi.fn(() => ({ mutateAsync: vi.fn() })),
  autenticarValidador: vi.fn(() => ({ mutateAsync: vi.fn() })),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    intervencoes: {
      listarPorValidar: { useQuery: trpcMock.listarPorValidar },
      listarTodas: { useQuery: trpcMock.listarTodas },
      validarComSessao: { useMutation: trpcMock.validarComSessao },
      autenticarValidador: { useMutation: trpcMock.autenticarValidador },
    },
  },
}));

import PainelValidacoes from "./PainelValidacoes";

describe("atalho Gestão de PINs em validações", () => {
  beforeEach(() => {
    Object.defineProperty(window, "innerWidth", { configurable: true, value: 390 });
    sessionStorage.setItem("validador_sessao", JSON.stringify({
      id: "qualidade", nome: "Joana Pina", nomeUtilizador: "joana.pina", pin: "pin-de-teste",
      perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true,
      podeGerir: false, podeGerirPins: true, podeGerirUtilizadores: true,
    }));
  });

  afterEach(() => {
    cleanup();
    sessionStorage.clear();
    vi.clearAllMocks();
  });

  it("mostra o atalho de gestão de PINs à Qualidade em ecrã móvel", () => {
    render(<PainelValidacoes />);
    expect(screen.getByRole("button", { name: "Gestão de PINs" })).toBeTruthy();
    expect(screen.queryByText("Novo Validador")).toBeNull();
  });
});
