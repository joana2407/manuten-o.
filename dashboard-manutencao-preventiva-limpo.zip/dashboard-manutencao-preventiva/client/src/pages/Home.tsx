/*
 * Home — Orquestrador do Dashboard de Manutenção Preventiva
 * Design: Industrial Dark Analytics
 * Layout: Header fixo | Sidebar filtros | Área principal (alertas + KPIs + gráficos + tabela)
 */
import { useState, useCallback, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Wrench, RefreshCw, AlertTriangle, FolderPlus, ShieldCheck, Filter, User, DatabaseBackup, KeyRound, BookOpen, FileDown } from 'lucide-react';
import { useLocation } from 'wouter';
import { useDashboard } from '@/hooks/useDashboard';
import { useRealizacoesContext } from '@/contexts/RealizacoesContext';
import { chaveEquipamento } from '@/hooks/useRealizacoes';
import { KpiCards } from '@/components/KpiCards';
import { AlertaVencidos } from '@/components/AlertaVencidos';
import { MesCorrente } from '@/components/MesCorrente';
import { GraficosPorArea } from '@/components/GraficosPorArea';
import { GraficoMensal } from '@/components/GraficoMensal';
import { GraficoDonut } from '@/components/GraficoDonut';
import { TabelaEquipamentos } from '@/components/TabelaEquipamentos';
import { Sidebar } from '@/components/Sidebar';
import { ModalRealizacao } from '@/components/ModalRealizacao';
import { ModalNovaArea } from '@/components/ModalNovaArea';
import { nomesMesAtual } from '@/lib/utils';
import type { Equipamento } from '@/lib/types';
import { trpc } from '@/lib/trpc';
import { toast } from 'sonner';
import { ModalCodigoAcesso } from '@/components/ModalCodigoAcesso';
import { InstallPwaButton } from '@/components/InstallPwaButton';
import { PainelSelector } from '@/components/PainelSelector';
import { descarregarCsvPendentes } from '@/lib/exportPendentes';

export default function Home() {
  const [, setLocation] = useLocation();
  const [agora, setAgora] = useState(() => new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setAgora(new Date()), 60_000);
    return () => window.clearInterval(timer);
  }, []);
  const podeGerir = (() => {
    try {
      const raw = sessionStorage.getItem('app_sessao');
      return raw ? Boolean((JSON.parse(raw) as { podeGerir?: boolean }).podeGerir) : false;
    } catch {
      return false;
    }
  })();
  const podeGerirUtilizadores = (() => {
    try {
      const raw = sessionStorage.getItem('app_sessao');
      return raw ? Boolean((JSON.parse(raw) as { podeGerirUtilizadores?: boolean }).podeGerirUtilizadores) : false;
    } catch {
      return false;
    }
  })();
  const podeGerirEquipamentos = (() => {
    try {
      const raw = sessionStorage.getItem('app_sessao');
      return raw ? Boolean((JSON.parse(raw) as { podeGerirEquipamentos?: boolean }).podeGerirEquipamentos) : false;
    } catch {
      return false;
    }
  })();
  const nomeUtilizadorSessao = (() => {
    try {
      const raw = sessionStorage.getItem('app_sessao');
      return raw ? (JSON.parse(raw) as { nomeUtilizador?: string }).nomeUtilizador : undefined;
    } catch {
      return undefined;
    }
  })();
  const {
    todasIntervencoes,
    listaResponsaveis,
    responsaveisPorEquipamento,
    adicionarIntervencao,
    removerIntervencao,
    uploadAnexo,
    obterIntervencoesPorEquipamento,
    obterUltimaIntervencao,
  } = useRealizacoesContext();

  const {
    data,
    loading,
    error,
    filtros,
    setFiltros,
    areas,
    areasCustomFabrica,
    equipamentosFiltrados,
    kpis,
    doMesCorrente,
    vencidosGlobal,
    pendentesExportacao,
  } = useDashboard(todasIntervencoes);

  // Aplicar filtro por responsável
  const equipamentosVisiveis = useMemo(() => {
    if (!filtros.responsavel) return equipamentosFiltrados;
    return equipamentosFiltrados.filter(e => {
      const chave = chaveEquipamento(e.codigo, e.area);
      const resp = responsaveisPorEquipamento[chave];
      return resp?.has(filtros.responsavel!) ?? false;
    });
  }, [equipamentosFiltrados, filtros.responsavel, responsaveisPorEquipamento]);

  const [sidebarCollapsed, setSidebarCollapsed] = useState(
    () => typeof window !== 'undefined' && window.innerWidth < 1024,
  );
  const handleToggleCollapse = useCallback(() => setSidebarCollapsed(v => !v), []);

  const handleMesClick = (mes: number | null) => {
    setFiltros({ ...filtros, mes });
  };

  const handleExportarPendentes = useCallback(() => {
    if (pendentesExportacao.length === 0) {
      toast.info('Não existem manutenções vencidas ou previstas para os próximos 30 dias.');
      return;
    }
    const quantidade = descarregarCsvPendentes(pendentesExportacao, agora);
    toast.success(`${quantidade} pendente${quantidade === 1 ? '' : 's'} exportado${quantidade === 1 ? '' : 's'} para Excel/CSV.`);
  }, [pendentesExportacao, agora]);

  // Modal elevado ao nível do Home para ser partilhado pelos painéis e tabela
  const [modalEquipamento, setModalEquipamento] = useState<Equipamento | null>(null);
  const [modalNovaArea, setModalNovaArea] = useState(false);

  const handleAbrirModal = useCallback((eq: Equipamento) => {
    setModalEquipamento(eq);
  }, []);

  const handleFecharModal = useCallback(() => {
    setModalEquipamento(null);
  }, []);

  // Gestão de overrides de inativos via tRPC (protegida por código de acesso)
  const [overridesInativos, setOverridesInativos] = useState<Set<string>>(new Set());
  const [pendingToggle, setPendingToggle] = useState<{ codigo: string; area: string; inativo: boolean } | null>(null);
  const [erroCodigoToggle, setErroCodigoToggle] = useState('');
  const utils = trpc.useUtils();

  const toggleInativoMutation = trpc.gestao.toggleInativo.useMutation({
    onSuccess: (_, vars) => {
      const chave = `${vars.codigoEquipamento}::${vars.area}`;
      setOverridesInativos(prev => {
        const next = new Set(prev);
        if (vars.inativo) next.add(chave); else next.delete(chave);
        return next;
      });
      void utils.gestao.listarOverrides.invalidate();
      toast.success(vars.inativo ? 'Equipamento inativado' : 'Equipamento reativado');
      setPendingToggle(null);
      setErroCodigoToggle('');
    },
    onError: (err) => {
      if (err.message.includes('Código de acesso')) {
        setErroCodigoToggle('Código de acesso inválido.');
      } else {
        toast.error(`Erro: ${err.message}`);
        setPendingToggle(null);
      }
    },
  });

  // Abre modal de código de acesso antes de inativar/reativar
  const handleToggleInativo = useCallback((codigo: string, area: string, inativo: boolean) => {
    setPendingToggle({ codigo, area, inativo });
    setErroCodigoToggle('');
  }, []);

  const handleConfirmarToggle = useCallback((codigoAcesso: string) => {
    if (!pendingToggle) return;
    toggleInativoMutation.mutate({
      codigoEquipamento: pendingToggle.codigo,
      area: pendingToggle.area,
      inativo: pendingToggle.inativo,
      codigoAcesso,
    });
  }, [pendingToggle, toggleInativoMutation]);

  // Recarregar dados quando equipamento é adicionado
  const handleEquipamentoAdicionado = useCallback(() => {
    utils.gestao.listarEquipamentos.invalidate();
  }, [utils]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'oklch(0.085 0.005 240)' }}>
        <div className="text-center">
          <RefreshCw size={32} className="animate-spin mx-auto mb-3" style={{ color: 'oklch(0.72 0.18 60)' }} />
          <p className="text-sm" style={{ color: 'oklch(0.55 0.01 240)' }}>A carregar dados...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background: 'oklch(0.085 0.005 240)' }}>
        <div className="text-center">
          <AlertTriangle size={32} className="mx-auto mb-3" style={{ color: '#EF4444' }} />
          <p className="text-sm" style={{ color: '#EF4444' }}>Erro ao carregar dados: {error}</p>
        </div>
      </div>
    );
  }

  const atualizadoEm = agora.toLocaleString('pt-PT', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });

  return (
    <div className="min-h-screen flex flex-col" style={{ background: 'oklch(0.085 0.005 240)' }}>
      {/* Header */}
      <header
        className="dashboard-header flex items-center justify-between px-5 py-3 flex-shrink-0 z-10"
        style={{ background: 'oklch(0.1 0.006 240)', borderBottom: '1px solid oklch(0.22 0.008 240)' }}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded flex items-center justify-center" style={{ background: 'oklch(0.72 0.18 60 / 0.2)', border: '1px solid oklch(0.72 0.18 60 / 0.4)' }}>
            <Wrench size={16} style={{ color: 'oklch(0.82 0.16 60)' }} />
          </div>
          <div>
            <h1 className="text-sm font-semibold leading-tight" style={{ color: 'oklch(0.92 0.005 240)' }}>
              Plano de Manutenção Preventiva
            </h1>
            <p className="text-xs" style={{ color: 'oklch(0.45 0.01 240)' }}>
              Data-base: 01/01/2026 · Atualizado: {atualizadoEm}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <PainelSelector compacto />
          <button
            onClick={() => setLocation('/acesso')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: 'oklch(0.72 0.15 260)', border: '1px solid oklch(0.55 0.18 260 / 0.35)', background: 'oklch(0.55 0.18 260 / 0.08)' }}
            title="Acesso de utilizadores"
          >
            <User size={13} />
            Acesso
          </button>
          <button
            onClick={() => setLocation('/backups')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.35)', background: 'oklch(0.72 0.18 60 / 0.06)' }}
            title="Backups semanais"
          >
            <DatabaseBackup size={13} />
            Backups
          </button>
          <button
            onClick={handleExportarPendentes}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: '#F59E0B', border: '1px solid #F59E0B55', background: '#F59E0B0d' }}
            title="Extrair lista de vencidos e próximos 30 dias"
          >
            <FileDown size={13} />
            Pendentes ({pendentesExportacao.length})
          </button>
          <button
            onClick={() => setLocation('/instrucoes')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: 'oklch(0.72 0.15 185)', border: '1px solid oklch(0.55 0.18 185 / 0.35)', background: 'oklch(0.55 0.18 185 / 0.08)' }}
            title="Instruções de utilização do software"
          >
            <BookOpen size={13} />
            Instruções
          </button>
          {podeGerirUtilizadores && <button
            onClick={() => setLocation('/gestao-validadores')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.35)', background: 'oklch(0.72 0.18 60 / 0.06)' }}
            title="Gestão de PINs de utilizadores"
          >
            <KeyRound size={13} />
            Gestão de PINs
          </button>}
          {vencidosGlobal.length > 0 && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full pulse-red"
              style={{ background: 'oklch(0.62 0.22 25 / 0.2)', border: '1px solid oklch(0.62 0.22 25 / 0.5)' }}
            >
              <AlertTriangle size={13} style={{ color: '#EF4444' }} />
              <span className="text-xs font-semibold font-mono" style={{ color: '#EF4444' }}>
                {vencidosGlobal.length} {vencidosGlobal.length !== 1 ? 'vencidas' : 'vencida'}
              </span>
            </motion.div>
          )}
          <button
            onClick={handleToggleCollapse}
            className="lg:hidden flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.4)', background: 'oklch(0.72 0.18 60 / 0.08)' }}
            title="Mostrar filtros"
          >
            <Filter size={13} />
            Filtros
          </button>
          <button
            onClick={() => setLocation('/validacoes')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10 active:scale-95"
            style={{ color: '#22C55E', border: '1px solid #22C55E44', background: '#22C55E0a' }}
            title="Painel de validações"
          >
            <ShieldCheck size={13} />
            Validações
          </button>
          <InstallPwaButton />
          {podeGerirEquipamentos && <button
            onClick={() => setModalNovaArea(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium transition-colors hover:bg-white/10"
            style={{ color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.4)', background: 'oklch(0.72 0.18 60 / 0.08)' }}
            title="Criar nova área"
          >
            <FolderPlus size={13} />
            Nova Área
          </button>}
          <div className="text-xs font-mono px-3 py-1.5 rounded" style={{ background: 'oklch(0.72 0.18 60 / 0.12)', color: 'oklch(0.82 0.16 60)', border: '1px solid oklch(0.72 0.18 60 / 0.3)' }}>
            {nomesMesAtual()} 2026
          </div>
        </div>
      </header>

      {/* Body */}
      <div className="dashboard-content flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <Sidebar
          areas={areas}
          porArea={data.por_area}
          listaResponsaveis={listaResponsaveis}
          filtros={filtros}
          setFiltros={setFiltros}
          totalFiltrado={equipamentosVisiveis.length}
          totalGlobal={data.resumo.total}
          collapsed={sidebarCollapsed}
          onToggleCollapse={handleToggleCollapse}
           areasCustomFabrica={areasCustomFabrica}
           onAreaAlterada={handleEquipamentoAdicionado}
           podeGerir={podeGerirEquipamentos}
           nomeUtilizador={nomeUtilizadorSessao}
        />

        {/* Área principal */}
        <main className="flex-1 overflow-y-auto p-4 flex flex-col gap-4">
          {/* Alertas — clicáveis para abrir modal */}
          <AlertaVencidos vencidos={vencidosGlobal} onAbrirModal={handleAbrirModal} />
          <MesCorrente equipamentos={doMesCorrente} onAbrirModal={handleAbrirModal} />

          {/* KPI Cards */}
          <KpiCards
            total={kpis.total}
            vencidos={kpis.vencidos}
            proximos={kpis.proximos}
            em_dia={kpis.em_dia}
            inativos={kpis.inativos}
          />

          {/* Gráficos */}
          <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <div className="xl:col-span-2">
              <GraficosPorArea porArea={data.por_area} />
            </div>
            <div>
              <GraficoDonut
                vencidos={kpis.vencidos}
                proximos={kpis.proximos}
                em_dia={kpis.em_dia}
                inativos={kpis.inativos}
                sem_periodicidade={kpis.sem_periodicidade}
              />
            </div>
          </div>

          <GraficoMensal
            porMes={data.por_mes}
            mesSelecionado={filtros.mes}
            onMesClick={handleMesClick}
          />

          {/* Tabela */}
          <TabelaEquipamentos
            equipamentos={equipamentosVisiveis}
            todasAreas={areas}
            areasCustomFabrica={areasCustomFabrica}
            overridesInativos={overridesInativos}
            onToggleInativo={handleToggleInativo}
             onEquipamentoAdicionado={handleEquipamentoAdicionado}
             podeGerir={podeGerirEquipamentos}
             nomeUtilizador={nomeUtilizadorSessao}
           />
        </main>
      </div>

      {/* Modal de código de acesso para inativar/reativar equipamentos do JSON */}
      {pendingToggle && (
        <ModalCodigoAcesso
          titulo={pendingToggle.inativo ? 'Inativar Equipamento' : 'Reativar Equipamento'}
          descricao={pendingToggle.inativo
            ? 'Introduza o código de acesso para inativar este equipamento.'
            : 'Introduza o código de acesso para reativar este equipamento.'
          }
          acaoBotao={pendingToggle.inativo ? 'Inativar' : 'Reativar'}
          corBotao={pendingToggle.inativo ? 'oklch(0.52 0.22 25)' : 'oklch(0.62 0.18 145)'}
          carregando={toggleInativoMutation.isPending}
          onConfirmar={handleConfirmarToggle}
          onFechar={() => { setPendingToggle(null); setErroCodigoToggle(''); }}
          erroExterno={erroCodigoToggle}
        />
      )}

      {/* Modal Nova Área */}
      {modalNovaArea && (
        <ModalNovaArea
          onFechar={() => setModalNovaArea(false)}
          onCriada={(_nome) => {
            utils.gestao.listarAreas.invalidate();
            utils.gestao.listarEquipamentos.invalidate();
          }}
        />
      )}

      {/* Modal global de registo de intervenção (partilhado pelos painéis e tabela) */}
      {modalEquipamento && (
        <ModalRealizacao
          equipamento={modalEquipamento}
          historico={obterIntervencoesPorEquipamento(modalEquipamento.codigo, modalEquipamento.area)}
          onFechar={handleFecharModal}
          onAdicionar={(data, intervencao, material, responsavel, responsavelValidacao) =>
            adicionarIntervencao(
              modalEquipamento.codigo,
              modalEquipamento.area,
              data,
              intervencao,
              material,
              responsavel,
              responsavelValidacao,
            )
          }
          onRemoverIntervencao={removerIntervencao}
          onUploadAnexo={uploadAnexo}
        />
      )}
    </div>
  );
}
