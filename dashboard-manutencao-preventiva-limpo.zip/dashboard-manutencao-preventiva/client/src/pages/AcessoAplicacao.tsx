import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Eye, EyeOff, KeyRound, LogOut, ShieldCheck, User } from "lucide-react";
import { useLocation } from "wouter";
import { SeletorUtilizadorAcesso } from "@/components/SeletorUtilizadorAcesso";
import { autenticarUtilizadorLocal } from "@/lib/localAccess";

type SessaoAcesso = {
  id: string;
  nome: string;
  nomeUtilizador: string;
  pin: string;
  perfil: string;
  funcao: string;
  podeRegistar: boolean;
  podeValidar: boolean;
  podeGerir: boolean;
  podeGerirEquipamentos: boolean;
  podeGerirUtilizadores: boolean;
};

const KEY = "app_sessao";

function lerSessao(): SessaoAcesso | null {
  try {
    const valor = sessionStorage.getItem(KEY);
    const sessao = valor ? JSON.parse(valor) as SessaoAcesso : null;
    return sessao?.nomeUtilizador ? sessao : null;
  } catch {
    return null;
  }
}

export default function AcessoAplicacao() {
  const [, setLocation] = useLocation();
  const [sessao, setSessao] = useState<SessaoAcesso | null>(() => lerSessao());
  const [nomeUtilizador, setNomeUtilizador] = useState("");
  const [pin, setPin] = useState("");
  const [mostrar, setMostrar] = useState(false);
  const [erro, setErro] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const [aAutenticar, setAAutenticar] = useState(false);

  useEffect(() => { inputRef.current?.focus(); }, []);

  async function entrar(event: React.FormEvent) {
    event.preventDefault();
    if (!nomeUtilizador.trim() || !pin.trim()) return;
    setErro("");
    setAAutenticar(true);
    try {
      const resultado = autenticarUtilizadorLocal(nomeUtilizador.trim(), pin.trim());
      const novaSessao = { ...resultado, pin: pin.trim() };
      sessionStorage.setItem(KEY, JSON.stringify(novaSessao));
      sessionStorage.setItem("validador_sessao", JSON.stringify(novaSessao));
      setSessao(novaSessao);
      setNomeUtilizador("");
      setPin("");
    } catch {
      setErro("O PIN não corresponde ao utilizador selecionado. Tente novamente.");
      setPin("");
      inputRef.current?.focus();
    } finally {
      setAAutenticar(false);
    }
  }

  function sair() {
    sessionStorage.removeItem(KEY);
    sessionStorage.removeItem("validador_sessao");
    setSessao(null);
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "oklch(0.085 0.005 240)" }}>
      <main className="w-full max-w-md">
        <button onClick={() => setLocation("/")} className="mb-5 flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm" style={{ color: "oklch(0.72 0.18 60)", border: "1px solid oklch(0.25 0.008 240)" }}>
          <ArrowLeft size={14} /> Voltar ao dashboard
        </button>
        <section className="rounded-2xl p-6" style={{ background: "oklch(0.1 0.006 240)", border: "1px solid oklch(0.22 0.008 240)" }}>
          <div className="mb-6 flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-xl" style={{ background: "#22C55E22", border: "1px solid #22C55E44" }}><ShieldCheck size={21} style={{ color: "#22C55E" }} /></div>
            <div><h1 className="text-lg font-bold" style={{ color: "oklch(0.92 0.005 240)" }}>Acesso à aplicação</h1><p className="text-xs" style={{ color: "oklch(0.5 0.01 240)" }}>Selecione o utilizador e introduza o PIN individual</p></div>
          </div>
          {sessao ? (
            <div className="space-y-4">
              <div className="rounded-xl p-4" style={{ background: "#22C55E0d", border: "1px solid #22C55E33" }}>
                <div className="flex items-center gap-2"><User size={15} style={{ color: "#22C55E" }} /><strong style={{ color: "#22C55E" }}>{sessao.nome}</strong></div>
                <p className="mt-1 text-sm" style={{ color: "oklch(0.72 0.01 240)" }}>{sessao.funcao}</p>
              </div>
              <div className="grid grid-cols-1 gap-2 text-xs sm:grid-cols-3">
                <span style={{ color: sessao.podeRegistar ? "#22C55E" : "#777" }}>● Registo {sessao.podeRegistar ? "permitido" : "consulta"}</span>
                <span style={{ color: sessao.podeValidar ? "#22C55E" : "#777" }}>● Validação {sessao.podeValidar ? "permitida" : "não disponível"}</span>
                <span style={{ color: sessao.podeGerir ? "#22C55E" : "#777" }}>● Gestão {sessao.podeGerir ? "permitida" : "não disponível"}</span>
                <span style={{ color: sessao.podeGerirUtilizadores ? "#22C55E" : "#777" }}>● Utilizadores {sessao.podeGerirUtilizadores ? "permitido" : "não disponível"}</span>
                <span style={{ color: sessao.podeGerirEquipamentos ? "#22C55E" : "#777" }}>● Equipamentos e áreas {sessao.podeGerirEquipamentos ? "permitido" : "não disponível"}</span>
              </div>
              <button onClick={sair} className="flex w-full items-center justify-center gap-2 rounded-lg px-3 py-2 text-sm" style={{ color: "#EF7777", border: "1px solid #EF444444" }}><LogOut size={14} /> Terminar sessão</button>
            </div>
          ) : (
            <form onSubmit={entrar} className="space-y-4">
              <SeletorUtilizadorAcesso value={nomeUtilizador} onChange={utilizador => { setNomeUtilizador(utilizador); setErro(""); }} disabled={aAutenticar} />
              <label className="text-xs font-semibold uppercase tracking-wider" style={{ color: "oklch(0.52 0.01 240)" }}>PIN de acesso</label>
              <div className="flex items-center gap-2 rounded-lg px-3 py-2.5" style={{ background: "oklch(0.085 0.005 240)", border: `1px solid ${erro ? "#EF4444" : "oklch(0.25 0.008 240)"}` }}>
                <KeyRound size={14} style={{ color: "oklch(0.45 0.01 240)" }} />
                <input ref={inputRef} value={pin} onChange={e => { setPin(e.target.value); setErro(""); }} type={mostrar ? "text" : "password"} inputMode="numeric" autoComplete="off" placeholder="Introduza o PIN" className="flex-1 bg-transparent text-sm outline-none" style={{ color: "oklch(0.88 0.005 240)" }} />
                <button type="button" onClick={() => setMostrar(v => !v)} style={{ color: "oklch(0.5 0.01 240)" }}>{mostrar ? <EyeOff size={14} /> : <Eye size={14} />}</button>
              </div>
              {erro && <p className="text-xs" style={{ color: "#EF7777" }}>{erro}</p>}
              <button disabled={!nomeUtilizador.trim() || !pin.trim() || aAutenticar} className="w-full rounded-lg px-3 py-2.5 text-sm font-semibold disabled:opacity-60" style={{ background: "#22C55E", color: "#071407" }}>{aAutenticar ? "A verificar…" : "Entrar"}</button>
            </form>
          )}
        </section>
      </main>
    </div>
  );
}
