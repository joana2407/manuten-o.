/*
 * RealizacoesContext — Partilha o estado de intervenções entre componentes
 * Migrado de localStorage para tRPC + base de dados partilhada
 */
import { createContext, useContext, useMemo, useCallback, type ReactNode } from 'react';
import { trpc } from '@/lib/trpc';
import { calcularProxima, calcularEstadoPrazo, chaveEquipamento } from '@/hooks/useRealizacoes';

// Tipo de intervenção retornada pelo servidor (inclui anexos)
export interface AnexoDb {
  id: string;
  intervencaoId: string;
  filename: string;
  mimeType: string;
  storageKey: string;
  storageUrl: string;
  tamanhoBytes: number | null;
  criadoEm: number;
}

export interface IntervencaoDb {
  id: string;
  codigoEquipamento: string;
  area: string;
  dataRealizacao: string;
  intervencaoRealizada: string | null;
  materialGasto: string | null;
  responsavel: string | null;
  responsavelValidacao: string | null;
  validadoPor: string | null;
  validadoEm: number | null;
  criadoEm: number;
  nomeEquipamento?: string | null;
  anexos: AnexoDb[];
}

interface RealizacoesContextType {
  todasIntervencoes: IntervencaoDb[];
  isLoading: boolean;
  adicionarIntervencao: (
    codigo: string,
    area: string,
    dataRealizacao: string,
    intervencao: string,
    materialGasto: string,
    responsavel: string,
    responsavelValidacao?: string,
  ) => Promise<string>; // retorna o id da intervenção criada
  removerIntervencao: (id: string) => Promise<void>;
  editarIntervencao: (
    id: string,
    dados: {
      intervencaoRealizada: string | null;
      materialGasto: string | null;
      responsavelValidacao: string | null;
      validadoPor: string | null;
    },
  ) => Promise<void>;
  uploadAnexo: (
    intervencaoId: string,
    file: File,
  ) => Promise<{ id: string; url: string }>;
  obterIntervencoesPorEquipamento: (codigo: string, area: string) => IntervencaoDb[];
  obterUltimaIntervencao: (codigo: string, area: string) => IntervencaoDb | null;
  listaResponsaveis: { nome: string; total: number }[];
  responsaveisPorEquipamento: Record<string, Set<string>>;
  totalEquipamentosComRegisto: number;
  totalIntervencoes: number;
}

const RealizacoesContext = createContext<RealizacoesContextType | null>(null);

export function RealizacoesProvider({ children }: { children: ReactNode }) {
  const utils = trpc.useUtils();

  // Carregar todas as intervenções de uma vez (para filtros e KPIs)
  const { data: todasIntervencoes = [], isLoading } = trpc.intervencoes.listarTodas.useQuery(
    undefined,
    { refetchOnWindowFocus: false },
  );

  const criarMutation = trpc.intervencoes.criar.useMutation({
    onSuccess: () => utils.intervencoes.listarTodas.invalidate(),
  });

  const removerMutation = trpc.intervencoes.remover.useMutation({
    onSuccess: () => utils.intervencoes.listarTodas.invalidate(),
  });

  const editarMutation = trpc.intervencoes.editar.useMutation({
    onSuccess: () => utils.intervencoes.listarTodas.invalidate(),
  });

  const uploadAnexoMutation = trpc.intervencoes.uploadAnexo.useMutation({
    onSuccess: () => utils.intervencoes.listarTodas.invalidate(),
  });

  const adicionarIntervencao = useCallback(
    async (
      codigo: string,
      area: string,
      dataRealizacao: string,
      intervencao: string,
      materialGasto: string,
      responsavel: string,
      responsavelValidacao?: string,
    ): Promise<string> => {
      const result = await criarMutation.mutateAsync({
        codigoEquipamento: codigo,
        area,
        dataRealizacao,
        intervencaoRealizada: intervencao,
        materialGasto,
        responsavel,
        responsavelValidacao,
      });
      return result.id;
    },
    [criarMutation],
  );

  const removerIntervencao = useCallback(
    async (id: string): Promise<void> => {
      await removerMutation.mutateAsync({ id });
    },
    [removerMutation],
  );

  const editarIntervencao = useCallback(
    async (id: string, dados: {
      intervencaoRealizada: string | null;
      materialGasto: string | null;
      responsavelValidacao: string | null;
      validadoPor: string | null;
    }): Promise<void> => {
      await editarMutation.mutateAsync({ id, ...dados });
    },
    [editarMutation],
  );

  const uploadAnexo = useCallback(
    async (intervencaoId: string, file: File): Promise<{ id: string; url: string }> => {
      // Converter ficheiro para base64
      const buffer = await file.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = '';
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      const dataBase64 = btoa(binary);

      return uploadAnexoMutation.mutateAsync({
        intervencaoId,
        filename: file.name,
        mimeType: file.type || 'application/octet-stream',
        dataBase64,
        tamanhoBytes: file.size,
      });
    },
    [uploadAnexoMutation],
  );

  const obterIntervencoesPorEquipamento = useCallback(
    (codigo: string, area: string): IntervencaoDb[] => {
      return todasIntervencoes
        .filter(i => i.codigoEquipamento === codigo && i.area === area)
        .sort((a, b) => b.criadoEm - a.criadoEm);
    },
    [todasIntervencoes],
  );

  const obterUltimaIntervencao = useCallback(
    (codigo: string, area: string): IntervencaoDb | null => {
      const lista = todasIntervencoes
        .filter(i => i.codigoEquipamento === codigo && i.area === area)
        .sort((a, b) => b.dataRealizacao.localeCompare(a.dataRealizacao));
      return lista[0] ?? null;
    },
    [todasIntervencoes],
  );

  const listaResponsaveis = useMemo((): { nome: string; total: number }[] => {
    const mapa: Record<string, number> = {};
    todasIntervencoes.forEach(i => {
      const nome = i.responsavel?.trim();
      if (nome) mapa[nome] = (mapa[nome] ?? 0) + 1;
    });
    return Object.entries(mapa)
      .map(([nome, total]) => ({ nome, total }))
      .sort((a, b) => a.nome.localeCompare(b.nome, 'pt'));
  }, [todasIntervencoes]);

  const responsaveisPorEquipamento = useMemo((): Record<string, Set<string>> => {
    const mapa: Record<string, Set<string>> = {};
    todasIntervencoes.forEach(i => {
      const nome = i.responsavel?.trim();
      if (!nome) return;
      const chave = chaveEquipamento(i.codigoEquipamento, i.area);
      if (!mapa[chave]) mapa[chave] = new Set();
      mapa[chave].add(nome);
    });
    return mapa;
  }, [todasIntervencoes]);

  const totalEquipamentosComRegisto = useMemo(() => {
    const chaves = new Set(todasIntervencoes.map(i => chaveEquipamento(i.codigoEquipamento, i.area)));
    return chaves.size;
  }, [todasIntervencoes]);

  const totalIntervencoes = todasIntervencoes.length;

  const value: RealizacoesContextType = {
    todasIntervencoes,
    isLoading,
    adicionarIntervencao,
    removerIntervencao,
    editarIntervencao,
    uploadAnexo,
    obterIntervencoesPorEquipamento,
    obterUltimaIntervencao,
    listaResponsaveis,
    responsaveisPorEquipamento,
    totalEquipamentosComRegisto,
    totalIntervencoes,
  };

  return (
    <RealizacoesContext.Provider value={value}>
      {children}
    </RealizacoesContext.Provider>
  );
}

export function useRealizacoesContext(): RealizacoesContextType {
  const ctx = useContext(RealizacoesContext);
  if (!ctx) throw new Error('useRealizacoesContext deve ser usado dentro de RealizacoesProvider');
  return ctx;
}

// Re-exportar utilitários para compatibilidade
export { calcularProxima, calcularEstadoPrazo, chaveEquipamento };
