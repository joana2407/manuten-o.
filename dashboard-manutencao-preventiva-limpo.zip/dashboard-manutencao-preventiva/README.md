# Dashboard de Manutenção Preventiva

Aplicação React/Vite/PWA para manutenção preventiva e corretiva, com autenticação por utilizador e PIN, intervenções, validações, equipamentos, áreas, anexos, backups e exportação Excel.

## Arquitetura independente

A aplicação não depende do runtime Manus, OAuth Manus, Forge, LLM Manus ou armazenamento Manus. O frontend é uma build Vite estática. A API tRPC corre como função serverless Vercel em `api/[...path].ts`. Os dados ficam numa base de dados MySQL/TiDB externa através de `DATABASE_URL`. Anexos e backups ficam num bucket S3 compatível.

O login visual existente por utilizador + PIN foi preservado. Os utilizadores iniciais continuam definidos pelos perfis da aplicação; em produção, a gestão deve ser feita através da base de dados e do painel de gestão.

## Publicação na Vercel

1. Importar o repositório `joana2407/dashboard-manutencao-preventiva` na Vercel.
2. Selecionar **Framework Preset: Vite**.
3. Definir **Install Command:** `pnpm install --frozen-lockfile`.
4. Definir **Build Command:** `pnpm run build`.
5. Definir **Output Directory:** `dist/public`.
6. Usar Node.js **22.x**.
7. Preencher as variáveis de ambiente indicadas abaixo para os ambientes Production, Preview e Development, conforme necessário.
8. Fazer o primeiro deploy.

O `vercel.json` já contém os rewrites SPA, a função API e o cron semanal de backups aos domingos às 03:00 UTC.

## Variáveis de ambiente

Obrigatórias:

- `DATABASE_URL`: ligação MySQL/TiDB externa.
- `JWT_SECRET`: segredo aleatório longo para sessões futuras/API.
- `S3_ENDPOINT`: endpoint do fornecedor S3 compatível.
- `S3_REGION`: região do bucket; usar `auto` no Cloudflare R2.
- `S3_ACCESS_KEY_ID`: chave S3.
- `S3_SECRET_ACCESS_KEY`: segredo S3.
- `S3_BUCKET`: nome do bucket privado.
- `CRON_SECRET`: segredo usado para autenticar o Vercel Cron.

Opcional:

- `BACKUP_CRON_UID`: identificador estável do cron; por defeito `vercel-backup-semanal`.
- `NODE_ENV`: `production` na Vercel.

Nunca guardar valores reais no GitHub. Usar o ficheiro `ENVIRONMENT.example` como modelo e copiá-lo para `.env` localmente.

## Base de dados e migrações

O projeto usa Drizzle ORM com dialecto MySQL. O schema completo está em `drizzle/schema.ts` e as migrações SQL estão em `drizzle/`.

Para criar as tabelas numa base vazia:

```bash
pnpm install
cp ENVIRONMENT.example .env
# preencher DATABASE_URL no .env
pnpm db:push
```

Para exportar os dados da base atualmente configurada:

```bash
pnpm db:export
```

O comando cria um JSON em `exports/` com todas as tabelas operacionais. Para importar numa base nova:

```bash
pnpm db:push
pnpm db:import -- exports/dashboard-manutencao-export-AAAA-MM-DD.json
```

Os ficheiros físicos de anexos e backups não ficam dentro da base de dados: devem ser copiados entre buckets S3 ou mantidos no bucket original, preservando as chaves guardadas no JSON.

## Desenvolvimento local

```bash
pnpm install
pnpm check
pnpm test
pnpm run build
pnpm dev
```

A aplicação abre em `http://localhost:3000`.

## Validação antes do deploy

A entrega deve passar:

```bash
pnpm install --frozen-lockfile
pnpm check
pnpm test
pnpm run build
```

Não foram alterados os fluxos visuais nem o tema industrial. As alterações de migração limitam-se à infraestrutura necessária para remover a dependência Manus e publicar na Vercel.
