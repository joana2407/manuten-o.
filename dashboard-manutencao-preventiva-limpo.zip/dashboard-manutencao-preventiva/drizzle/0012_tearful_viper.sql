ALTER TABLE `intervencoes` ADD `validadoPor` varchar(64);--> statement-breakpoint
ALTER TABLE `intervencoes` ADD `validadoEm` bigint;