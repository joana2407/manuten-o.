CREATE TABLE `backups_aplicacao` (
	`id` varchar(36) NOT NULL,
	`origem` enum('automatico','antes_restauro') NOT NULL,
	`estado` enum('concluido','expirado','falhou') NOT NULL DEFAULT 'concluido',
	`nome_ficheiro` varchar(255) NOT NULL,
	`storage_key` varchar(512) NOT NULL,
	`tamanho_bytes` int NOT NULL,
	`checksum` varchar(64) NOT NULL,
	`criadoEm` bigint NOT NULL,
	`expiraEm` bigint NOT NULL,
	`restauradoEm` bigint,
	`restauradoPor` varchar(128),
	`erro` text,
	CONSTRAINT `backups_aplicacao_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `configuracao_backups` (
	`id` varchar(36) NOT NULL,
	`schedule_cron_task_uid` varchar(65),
	`ativo` boolean NOT NULL DEFAULT true,
	`retencao_semanas` int NOT NULL DEFAULT 12,
	`atualizadoEm` bigint NOT NULL,
	CONSTRAINT `configuracao_backups_id` PRIMARY KEY(`id`),
	CONSTRAINT `configuracao_backups_schedule_cron_task_uid_unique` UNIQUE(`schedule_cron_task_uid`)
);
--> statement-breakpoint
CREATE INDEX `backups_aplicacao_criado_em_idx` ON `backups_aplicacao` (`criadoEm`);--> statement-breakpoint
CREATE INDEX `backups_aplicacao_estado_idx` ON `backups_aplicacao` (`estado`);--> statement-breakpoint
CREATE INDEX `configuracao_backups_task_uid_idx` ON `configuracao_backups` (`schedule_cron_task_uid`);