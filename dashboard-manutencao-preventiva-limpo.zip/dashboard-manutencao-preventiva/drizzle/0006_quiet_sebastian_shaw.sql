ALTER TABLE `equipamentos_custom` ADD `modelo` varchar(256);--> statement-breakpoint
ALTER TABLE `equipamentos_custom` ADD `numeroSerie` varchar(128);--> statement-breakpoint
ALTER TABLE `equipamentos_override` ADD `modelo` varchar(256);--> statement-breakpoint
ALTER TABLE `equipamentos_override` ADD `numeroSerie` varchar(128);