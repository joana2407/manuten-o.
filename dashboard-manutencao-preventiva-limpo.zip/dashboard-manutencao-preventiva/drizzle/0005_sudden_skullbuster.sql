ALTER TABLE `equipamentos_override` ADD `novoNome` varchar(256);--> statement-breakpoint
ALTER TABLE `equipamentos_override` ADD `novaArea` varchar(128);--> statement-breakpoint
ALTER TABLE `equipamentos_override` ADD `novaPeriodicidade` varchar(64);