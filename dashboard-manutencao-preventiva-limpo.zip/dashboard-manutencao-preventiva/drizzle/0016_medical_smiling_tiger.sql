CREATE TABLE `execucoes_backups` (
	`id` varchar(36) NOT NULL,
	`schedule_cron_task_uid` varchar(65) NOT NULL,
	`backup_id` varchar(36),
	`estado` enum('iniciado','concluido','falhou','ignorado') NOT NULL,
	`iniciadoEm` bigint NOT NULL,
	`concluidoEm` bigint,
	`erro` text,
	CONSTRAINT `execucoes_backups_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `execucoes_backups_task_uid_idx` ON `execucoes_backups` (`schedule_cron_task_uid`);--> statement-breakpoint
CREATE INDEX `execucoes_backups_iniciado_em_idx` ON `execucoes_backups` (`iniciadoEm`);