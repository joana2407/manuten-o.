CREATE TABLE `validadores_acesso` (
	`id` varchar(36) NOT NULL,
	`nome` varchar(128) NOT NULL,
	`pin` varchar(64) NOT NULL,
	`ativo` boolean NOT NULL DEFAULT true,
	`criadoEm` bigint NOT NULL,
	CONSTRAINT `validadores_acesso_id` PRIMARY KEY(`id`)
);
