CREATE TABLE `areas_custom` (
	`id` varchar(36) NOT NULL,
	`nome` varchar(128) NOT NULL,
	`descricao` text,
	`criadoEm` bigint NOT NULL,
	CONSTRAINT `areas_custom_id` PRIMARY KEY(`id`),
	CONSTRAINT `areas_custom_nome_unique` UNIQUE(`nome`)
);
--> statement-breakpoint
CREATE TABLE `equipamentos_custom` (
	`id` varchar(36) NOT NULL,
	`codigo` varchar(32) NOT NULL,
	`equipamento` varchar(256) NOT NULL,
	`area` varchar(128) NOT NULL,
	`periodicidade` varchar(64),
	`estado` varchar(32) DEFAULT 'Ativo',
	`criadoEm` bigint NOT NULL,
	CONSTRAINT `equipamentos_custom_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `equipamentos_override` (
	`id` varchar(36) NOT NULL,
	`codigoEquipamento` varchar(32) NOT NULL,
	`area` varchar(128) NOT NULL,
	`inativo` boolean NOT NULL DEFAULT false,
	`atualizadoEm` bigint NOT NULL,
	CONSTRAINT `equipamentos_override_id` PRIMARY KEY(`id`)
);
