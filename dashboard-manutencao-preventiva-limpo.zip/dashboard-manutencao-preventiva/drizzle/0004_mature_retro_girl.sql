ALTER TABLE `areas_custom` ADD `inativo` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `areas_custom` ADD `atualizadoEm` bigint;