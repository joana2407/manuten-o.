ALTER TABLE `equipamentos_custom` ADD `planoIntervencao` text;--> statement-breakpoint
ALTER TABLE `equipamentos_override` ADD `planoIntervencao` text;