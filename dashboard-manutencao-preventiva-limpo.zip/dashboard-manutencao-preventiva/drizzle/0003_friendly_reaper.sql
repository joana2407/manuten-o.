ALTER TABLE `areas_custom` ADD `fabrica` varchar(64) DEFAULT 'Fábrica I';--> statement-breakpoint
ALTER TABLE `equipamentos_custom` ADD `inativo` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `equipamentos_custom` ADD `atualizadoEm` bigint;