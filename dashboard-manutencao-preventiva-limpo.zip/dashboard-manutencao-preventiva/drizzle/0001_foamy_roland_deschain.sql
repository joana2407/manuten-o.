CREATE TABLE `anexos` (
	`id` varchar(36) NOT NULL,
	`intervencaoId` varchar(36) NOT NULL,
	`filename` varchar(256) NOT NULL,
	`mimeType` varchar(128) NOT NULL,
	`storageKey` varchar(512) NOT NULL,
	`storageUrl` varchar(512) NOT NULL,
	`tamanhoBytes` int,
	`criadoEm` bigint NOT NULL,
	CONSTRAINT `anexos_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `intervencoes` (
	`id` varchar(36) NOT NULL,
	`codigoEquipamento` varchar(32) NOT NULL,
	`area` varchar(128) NOT NULL,
	`dataRealizacao` varchar(10) NOT NULL,
	`intervencaoRealizada` text,
	`materialGasto` text,
	`responsavel` varchar(64),
	`criadoEm` bigint NOT NULL,
	CONSTRAINT `intervencoes_id` PRIMARY KEY(`id`)
);
