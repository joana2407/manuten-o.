import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, bigint, boolean, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Tabela de intervenções de manutenção preventiva.
 */
export const intervencoes = mysqlTable("intervencoes", {
  id: varchar("id", { length: 36 }).primaryKey(),
  codigoEquipamento: varchar("codigoEquipamento", { length: 32 }).notNull(),
  area: varchar("area", { length: 128 }).notNull(),
  dataRealizacao: varchar("dataRealizacao", { length: 10 }).notNull(),
  intervencaoRealizada: text("intervencaoRealizada"),
  materialGasto: text("materialGasto"),
  responsavel: varchar("responsavel", { length: 64 }),
  responsavelValidacao: varchar("responsavelValidacao", { length: 64 }),
  validadoPor: varchar("validadoPor", { length: 64 }),
  validadoEm: bigint("validadoEm", { mode: "number" }),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
});

export type Intervencao = typeof intervencoes.$inferSelect;
export type InsertIntervencao = typeof intervencoes.$inferInsert;

/**
 * Tabela de anexos associados a intervenções.
 */
export const anexos = mysqlTable("anexos", {
  id: varchar("id", { length: 36 }).primaryKey(),
  intervencaoId: varchar("intervencaoId", { length: 36 }).notNull(),
  filename: varchar("filename", { length: 256 }).notNull(),
  mimeType: varchar("mimeType", { length: 128 }).notNull(),
  storageKey: varchar("storageKey", { length: 512 }).notNull(),
  storageUrl: varchar("storageUrl", { length: 512 }).notNull(),
  tamanhoBytes: int("tamanhoBytes"),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
});

export type Anexo = typeof anexos.$inferSelect;
export type InsertAnexo = typeof anexos.$inferInsert;

/**
 * Áreas personalizadas criadas pelo utilizador (para além das do Excel).
 */
export const areasCustom = mysqlTable("areas_custom", {
  id: varchar("id", { length: 36 }).primaryKey(),
  nome: varchar("nome", { length: 128 }).notNull().unique(),
  descricao: text("descricao"),
  fabrica: varchar("fabrica", { length: 64 }).default("Fábrica I"),
  inativo: boolean("inativo").default(false).notNull(),
  isBase: boolean("isBase").default(false).notNull(),
  eliminado: boolean("eliminado").default(false).notNull(),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
  atualizadoEm: bigint("atualizadoEm", { mode: "number" }),
});

export type AreaCustom = typeof areasCustom.$inferSelect;
export type InsertAreaCustom = typeof areasCustom.$inferInsert;

/**
 * Equipamentos personalizados criados pelo utilizador.
 * Podem pertencer a áreas do Excel ou a áreas custom.
 */
export const equipamentosCustom = mysqlTable("equipamentos_custom", {
  id: varchar("id", { length: 36 }).primaryKey(),
  codigo: varchar("codigo", { length: 32 }).notNull(),
  equipamento: varchar("equipamento", { length: 256 }).notNull(),
  area: varchar("area", { length: 128 }).notNull(),
  periodicidade: varchar("periodicidade", { length: 64 }),
  estado: varchar("estado", { length: 32 }).default("Ativo"),
  inativo: boolean("inativo").default(false).notNull(),
  modelo: varchar("modelo", { length: 256 }),
  numeroSerie: varchar("numeroSerie", { length: 128 }),
  planoIntervencao: text("planoIntervencao"),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
  atualizadoEm: bigint("atualizadoEm", { mode: "number" }),
});

export type EquipamentoCustom = typeof equipamentosCustom.$inferSelect;
export type InsertEquipamentoCustom = typeof equipamentosCustom.$inferInsert;

/**
 * Overrides de estado para equipamentos do Excel.
 * Permite inativar/reativar equipamentos sem alterar o JSON original.
 */
export const equipamentosOverride = mysqlTable("equipamentos_override", {
  id: varchar("id", { length: 36 }).primaryKey(),
  codigoEquipamento: varchar("codigoEquipamento", { length: 32 }).notNull(),
  area: varchar("area", { length: 128 }).notNull(),
  inativo: boolean("inativo").default(false).notNull(),
  // Campos de override de edição (apenas para equipamentos do JSON base)
  novoNome: varchar("novoNome", { length: 256 }),
  novaArea: varchar("novaArea", { length: 128 }),
  novaPeriodicidade: varchar("novaPeriodicidade", { length: 64 }),
  modelo: varchar("modelo", { length: 256 }),
  numeroSerie: varchar("numeroSerie", { length: 128 }),
  planoIntervencao: text("planoIntervencao"),
  eliminado: boolean("eliminado").default(false).notNull(),
  atualizadoEm: bigint("atualizadoEm", { mode: "number" }).notNull(),
});

export type EquipamentoOverride = typeof equipamentosOverride.$inferSelect;
export type InsertEquipamentoOverride = typeof equipamentosOverride.$inferInsert;

/**
 * Utilizadores com acesso ao painel de validações.
 * Cada utilizador tem um PIN de 6 dígitos para autenticar a sessão.
 */
export const validadoresAcesso = mysqlTable("validadores_acesso", {
  id: varchar("id", { length: 36 }).primaryKey(),
  nome: varchar("nome", { length: 128 }).notNull(),
  nomeUtilizador: varchar("nome_utilizador", { length: 64 }).unique(),
  pin: varchar("pin", { length: 64 }).notNull(), // hash bcrypt do PIN
  ativo: boolean("ativo").default(true).notNull(),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
});

export type ValidadorAcesso = typeof validadoresAcesso.$inferSelect;
export type InsertValidadorAcesso = typeof validadoresAcesso.$inferInsert;

/**
 * Configuração única do backup semanal. O task UID é a referência durável do
 * agendamento e é a única chave usada pelo acionador para resolver a rotina.
 */
export const configuracaoBackups = mysqlTable("configuracao_backups", {
  id: varchar("id", { length: 36 }).primaryKey(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }).unique(),
  ativo: boolean("ativo").default(true).notNull(),
  retencaoSemanas: int("retencao_semanas").default(12).notNull(),
  atualizadoEm: bigint("atualizadoEm", { mode: "number" }).notNull(),
}, table => [index("configuracao_backups_task_uid_idx").on(table.scheduleCronTaskUid)]);

export type ConfiguracaoBackups = typeof configuracaoBackups.$inferSelect;

/**
 * Histórico de snapshots exportados. Os dados ficam em armazenamento privado;
 * a BD guarda apenas os metadados necessários para os localizar e auditar.
 */
export const backupsAplicacao = mysqlTable("backups_aplicacao", {
  id: varchar("id", { length: 36 }).primaryKey(),
  origem: mysqlEnum("origem", ["automatico", "antes_restauro"]).notNull(),
  estado: mysqlEnum("estado", ["concluido", "expirado", "falhou"]).default("concluido").notNull(),
  nomeFicheiro: varchar("nome_ficheiro", { length: 255 }).notNull(),
  storageKey: varchar("storage_key", { length: 512 }).notNull(),
  tamanhoBytes: int("tamanho_bytes").notNull(),
  checksum: varchar("checksum", { length: 64 }).notNull(),
  criadoEm: bigint("criadoEm", { mode: "number" }).notNull(),
  expiraEm: bigint("expiraEm", { mode: "number" }).notNull(),
  restauradoEm: bigint("restauradoEm", { mode: "number" }),
  restauradoPor: varchar("restauradoPor", { length: 128 }),
  erro: text("erro"),
}, table => [
  index("backups_aplicacao_criado_em_idx").on(table.criadoEm),
  index("backups_aplicacao_estado_idx").on(table.estado),
]);

export type BackupAplicacao = typeof backupsAplicacao.$inferSelect;

/** Registo de cada acionamento do backup semanal para auditoria de sucesso e falha. */
export const execucoesBackups = mysqlTable("execucoes_backups", {
  id: varchar("id", { length: 36 }).primaryKey(),
  scheduleCronTaskUid: varchar("schedule_cron_task_uid", { length: 65 }).notNull(),
  backupId: varchar("backup_id", { length: 36 }),
  estado: mysqlEnum("estado", ["iniciado", "concluido", "falhou", "ignorado"]).notNull(),
  iniciadoEm: bigint("iniciadoEm", { mode: "number" }).notNull(),
  concluidoEm: bigint("concluidoEm", { mode: "number" }),
  erro: text("erro"),
}, table => [
  index("execucoes_backups_task_uid_idx").on(table.scheduleCronTaskUid),
  index("execucoes_backups_iniciado_em_idx").on(table.iniciadoEm),
]);

export type ExecucaoBackup = typeof execucoesBackups.$inferSelect;
