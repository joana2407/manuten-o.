# PO-IT-001 — Procedimento de utilização e controlo do Dashboard de Manutenção

| Campo | Informação |
|---|---|
| **Organização** | A&S |
| **Processo** | Manutenção / Qualidade |
| **Documento** | Procedimento de utilização e controlo do Dashboard de Manutenção |
| **Código** | PO-IT-001 |
| **Versão** | 1.0 |
| **Data de emissão** | 06/10/2026 |
| **Elaborado por** | Responsável de Qualidade |
| **Aprovado por** | A preencher |
| **Periodicidade de revisão** | Anual ou sempre que exista alteração relevante |
| **Estado** | Para revisão e aprovação |

## 1. Objetivo

Estabelecer a forma correta e controlada de utilizar o **Dashboard de Manutenção**, assegurando que:

- os planos de manutenção preventiva são acompanhados e atualizados;
- as avarias e ordens de trabalho corretivas são registadas e acompanhadas;
- as intervenções são registadas pelos utilizadores autorizados;
- a libertação/validação das intervenções é realizada por um responsável competente;
- os acessos são atribuídos de acordo com as responsabilidades de cada utilizador;
- os registos são mantidos íntegros, rastreáveis e disponíveis para consulta;
- são realizados backups automáticos e existe capacidade de recuperação dos dados.

## 2. Âmbito

Este procedimento aplica-se a todos os colaboradores que consultem ou registem informação no Dashboard de Manutenção, incluindo as atividades de:

1. **Manutenção Preventiva** — acompanhamento do plano base, periodicidades, áreas, equipamentos, responsáveis, planos de intervenção e estado das tarefas.
2. **Manutenção Corretiva** — registo e acompanhamento de avarias, ordens de trabalho, peças/custos e histórico de intervenções.
3. **Validação de intervenções** — verificação da execução e libertação do equipamento por responsável autorizado.
4. **Gestão de utilizadores e PINs** — administração controlada dos acessos.
5. **Backups e recuperação** — proteção e recuperação dos registos operacionais.

O procedimento aplica-se à aplicação publicada nos endereços oficiais definidos pela organização, nomeadamente:

- [Dashboard de Manutenção](https://manutdash-dnqvujjm.manus.space)
- [Manutenção Preventiva](https://manutencaoprenventiva-as.manus.space)

> Se os endereços forem alterados, a Responsável de Qualidade deve atualizar este documento e comunicar a nova localização aos utilizadores.

## 3. Referências e documentos relacionados

- Plano de Manutenção Preventiva aprovado.
- Fichas de equipamento e respetivos planos de intervenção.
- Ordens de trabalho e registos de avaria.
- Matriz de competências e autorizações de validação.
- Política interna de controlo de acessos e palavras-passe/PINs.
- Registos de formação dos utilizadores.
- Histórico de backups e recuperações da aplicação.

## 4. Definições

| Termo | Definição |
|---|---|
| **Dashboard** | Aplicação web/PWA utilizada para gerir a informação de manutenção. |
| **Preventiva** | Manutenção planeada, realizada em periodicidade definida para prevenir falhas. |
| **Corretiva** | Manutenção desencadeada por avaria, anomalia ou necessidade não planeada. |
| **Intervenção** | Registo de uma atividade de manutenção realizada num equipamento. |
| **Validação** | Confirmação, por responsável autorizado, de que a intervenção foi executada e o equipamento pode ser libertado. |
| **PIN** | Código pessoal de acesso atribuído a um utilizador. |
| **Gestão** | Perfil com acesso integral à administração, validação, backups e recuperação. |
| **Backup** | Cópia de segurança dos dados operacionais e do histórico da aplicação. |

## 5. Responsabilidades e níveis de acesso

| Perfil | Responsabilidades principais | Acessos principais |
|---|---|---|
| **Técnico de Manutenção — Alfredo Silva** | Executar tarefas e registar intervenções. | Consulta dos painéis e registo de intervenções; sem validação final nem gestão de utilizadores. |
| **Responsável de Manutenção — Marco Monteiro** | Acompanhar a execução, completar informação técnica e apoiar o tratamento de desvios. | Consulta, registo e acompanhamento operacional; validação apenas quando formalmente autorizada. |
| **Responsável de Qualidade — Joana Pina** | Validar intervenções da sua competência, acompanhar registos e gerir os PINs permitidos. | Consulta, validação autorizada e alteração de PINs; não pode criar, ativar, desativar ou eliminar utilizadores. |
| **Gestão** | Assegurar supervisão global, administração e recuperação da informação. | Acesso integral, incluindo validações, gestão de utilizadores, backups e restauro. |

### 5.1 Regras de acesso

1. Cada utilizador deve utilizar apenas o seu próprio perfil e PIN.
2. É proibida a partilha de PINs.
3. O PIN deve ser alterado quando houver suspeita de divulgação, mudança de função ou indicação da Responsável de Qualidade/Gestão.
4. O utilizador deve terminar a sessão no final da utilização ou quando abandonar o equipamento.
5. Os acessos devem ser revistos pelo menos anualmente e sempre que ocorra entrada, saída ou alteração de função de um colaborador.
6. A Gestão deve assegurar que os perfis inativos são desativados atempadamente.

### 5.2 Administração de utilizadores

A **administração dos utilizadores e dos PINs é da responsabilidade da Responsável de Qualidade**. Esta responsabilidade inclui a consulta dos utilizadores autorizados, a alteração de PINs, a comunicação controlada das alterações e a revisão periódica dos acessos. As operações de criação, ativação, desativação ou eliminação de utilizadores permanecem reservadas à Gestão, de acordo com a matriz de permissões da aplicação.

## 6. Condições de utilização

Antes de iniciar o registo, o utilizador deve confirmar:

- que está a utilizar o endereço oficial da aplicação;
- que possui ligação à rede ou que compreende que o modo offline pode limitar a sincronização de novos registos;
- que está selecionado o perfil correto;
- que dispõe de autorização para a operação que pretende executar;
- que a informação introduzida corresponde ao equipamento e à intervenção reais.

A aplicação pode ser instalada como PWA em computador, tablet ou telemóvel compatível. A instalação não altera as regras de acesso nem substitui a necessidade de sincronização com a aplicação publicada.

## 7. Procedimento operacional

### 7.1 Painel explicativo de utilização

Todos os utilizadores autenticados têm acesso ao painel **Instruções do software**, disponível no cabeçalho do dashboard e na barra lateral da Manutenção Preventiva. O painel apresenta, de forma resumida:

- como entrar com o perfil e PIN pessoal;
- quando utilizar os painéis Preventiva e Corretiva;
- como registar uma intervenção;
- como encaminhar uma intervenção para validação;
- as regras de administração de utilizadores e PINs;
- o procedimento a seguir em caso de falha ou dúvida.

O painel é uma orientação rápida e não substitui este procedimento de qualidade nem as instruções técnicas específicas de cada equipamento.

### 7.2 Acesso à aplicação

1. Abrir o endereço oficial do Dashboard ou a aplicação instalada.
2. Selecionar o nome do utilizador na grelha apresentada.
3. Introduzir o PIN pessoal.
4. Confirmar que o nome e o perfil apresentados correspondem ao utilizador.
5. Se o PIN for rejeitado, não repetir tentativas de forma indiscriminada; contactar a Responsável de Qualidade ou a Gestão.

### 7.3 Escolha do painel

No seletor global ou na barra lateral, selecionar:

- **Manutenção Preventiva**, para tarefas planeadas e acompanhamento do plano base;
- **Manutenção Corretiva**, para avarias e trabalhos não planeados.

O utilizador deve confirmar o painel ativo antes de criar ou alterar um registo.

### 7.4 Consulta do plano de manutenção preventiva

1. Abrir **Manutenção Preventiva**.
2. Utilizar os filtros disponíveis por área, equipamento, responsável, mês ou estado.
3. Consultar os indicadores de tarefas vencidas, próximas, em dia e inativas.
4. Abrir a ficha do equipamento para confirmar os dados técnicos.
5. Consultar o **plano de intervenção** associado ao equipamento antes de executar a tarefa.
6. Se a informação do equipamento ou do plano estiver incorreta, comunicar a situação ao Responsável de Manutenção e não substituir informação crítica sem autorização.

### 7.5 Registo de uma intervenção preventiva

O executante deve registar a intervenção logo após a sua realização, ou no final do turno quando razões operacionais o impeçam.

1. Selecionar o equipamento correto.
2. Confirmar a identificação do equipamento e a área.
3. Registar a data e, quando aplicável, a hora da intervenção.
4. Descrever objetivamente o trabalho executado, incluindo verificações, medições e anomalias detetadas.
5. Registar materiais, peças ou observações relevantes.
6. Indicar o resultado da intervenção e eventuais ações pendentes.
7. Guardar o registo.
8. Confirmar que a intervenção ficou visível na área de **intervenções por validar**, quando aplicável.

Não devem ser utilizados comentários genéricos como “feito” ou “verificado” quando não permitam demonstrar o trabalho realizado.

### 7.6 Registo de avaria e manutenção corretiva

Quando ocorrer uma avaria ou anomalia:

1. Abrir **Manutenção Corretiva**.
2. Criar o registo da avaria ou ordem de trabalho.
3. Identificar o equipamento, área, data/hora e pessoa que detetou a ocorrência.
4. Descrever o sintoma ou falha observada, sem conclusões não confirmadas.
5. Classificar a prioridade de acordo com os critérios internos.
6. Registar a intervenção realizada, peças utilizadas, custos conhecidos e tempo de paragem, quando disponíveis.
7. Atualizar o estado da ordem de trabalho até à conclusão.
8. Encaminhar a intervenção para validação quando o trabalho estiver concluído.

Se existir risco para pessoas, ambiente, qualidade do produto ou integridade do equipamento, devem ser aplicados imediatamente os procedimentos de segurança e comunicação previstos internamente. O Dashboard não substitui a comunicação de emergência.

### 7.7 Validação e libertação do equipamento

A validação só pode ser efetuada por um utilizador com competência e acesso atribuídos para esse efeito.

1. Aceder à área **Validações**.
2. Selecionar o perfil autorizado correspondente.
3. Introduzir o PIN quando solicitado.
4. Consultar a lista de intervenções pendentes, confirmando o nome do equipamento, a área, o tipo de manutenção e o detalhe do trabalho.
5. Verificar se o registo contém informação suficiente para demonstrar a execução.
6. Confirmar, quando aplicável, que o equipamento foi testado e está em condições de ser libertado.
7. Validar a intervenção ou devolvê-la para correção, registando o motivo.
8. Confirmar que o estado do registo foi atualizado.

A validação não deve ser efetuada apenas com base na existência de um registo. O responsável deve verificar a informação disponível e, quando necessário, confirmar a condição do equipamento no local.

### 7.8 Alteração ou correção de registos

1. As correções devem preservar a rastreabilidade do registo.
2. Não se deve apagar informação para ocultar um erro ou uma intervenção realizada.
3. Quando a aplicação não permitir uma correção direta após validação, deve ser criado um registo complementar ou solicitada intervenção à Gestão/Responsável de Qualidade.
4. Eliminações definitivas de equipamentos ou áreas apenas podem ser realizadas por utilizador autorizado e de acordo com a necessidade operacional documentada.
5. Antes de uma eliminação, deve ser confirmada a inexistência de impacto em históricos, indicadores ou obrigações de retenção.

## 8. Gestão de utilizadores e PINs

### 8.1 Alteração de PIN pela Responsável de Qualidade

A Responsável de Qualidade pode consultar os utilizadores autorizados e alterar os respetivos PINs.

1. Aceder a **Gestão de PINs** através do atalho disponibilizado.
2. Autenticar-se com o próprio perfil e PIN.
3. Selecionar o utilizador.
4. Introduzir o novo PIN de acordo com as regras internas.
5. Confirmar a alteração.
6. Comunicar o novo PIN ao utilizador por canal controlado, sem o divulgar em grupo.
7. Solicitar ao utilizador que confirme o acesso e não manter o PIN em registos não protegidos.

### 8.2 Administração pela Gestão

A Gestão pode adicionar, alterar, ativar, desativar ou eliminar utilizadores, quando necessário. Cada alteração deve ter motivo identificável, data e responsável, de acordo com o registo interno de controlo de acessos.

Os PINs são armazenados pela aplicação de forma protegida; não devem ser registados em texto simples no procedimento, em folhas partilhadas ou em mensagens de grupo.

## 9. Backups e recuperação de dados

### 9.1 Backup automático

1. A aplicação dispõe de backup automático semanal, programado para domingo às **03:00 UTC**.
2. O sistema mantém uma retenção operacional de **12 semanas**.
3. O histórico deve permitir identificar execuções concluídas, falhadas ou ignoradas.
4. Os utilizadores autenticados podem consultar e exportar os backups em formato **Excel (.xlsx)** conforme as permissões atribuídas. O ficheiro Excel é organizado por folhas de consulta, incluindo intervenções, anexos, áreas, equipamentos, alterações e utilizadores.
5. A aplicação mantém internamente uma cópia técnica estruturada para permitir a verificação de integridade e o restauro controlado; essa cópia não substitui o ficheiro Excel disponibilizado para consulta.
6. A capacidade de recuperação/restauro está reservada à **Gestão**.

### 9.2 Verificação de backups

A Gestão ou a Responsável de Qualidade deve, pelo menos mensalmente:

- confirmar que existem backups recentes;
- verificar a data da última execução concluída;
- confirmar que a retenção está a funcionar;
- registar falhas ou execuções ignoradas;
- comunicar qualquer anomalia ao responsável técnico da aplicação.

### 9.3 Restauro

O restauro é uma operação controlada e só deve ser executado quando exista motivo operacional documentado.

1. Identificar o motivo e o âmbito do restauro.
2. Confirmar qual o backup a utilizar.
3. Avaliar o impacto sobre os registos criados depois da data do backup.
4. Obter autorização da Gestão.
5. Registar data, hora, responsável, backup selecionado, motivo e resultado.
6. Executar o restauro através do painel de Backups.
7. Confirmar a integridade dos dados essenciais: utilizadores, equipamentos, intervenções, validações e estados.
8. Comunicar a conclusão aos utilizadores afetados.

Não deve ser executado restauro real apenas para teste sobre o ambiente operacional. Os testes de recuperação devem ser planeados em ambiente isolado ou com uma cópia controlada.

## 10. Tratamento de falhas e contingência

| Situação | Ação imediata |
|---|---|
| Aplicação indisponível | Comunicar ao Responsável de Manutenção/Gestão e registar temporariamente a ocorrência em suporte controlado. Introduzir os dados no Dashboard após reposição. |
| PIN rejeitado | Confirmar o utilizador selecionado e contactar a Responsável de Qualidade/Gestão. Não partilhar PINs. |
| Registo no equipamento errado | Não validar. Informar o responsável e corrigir mantendo a rastreabilidade. |
| Intervenção não aparece para validação | Confirmar que foi guardada e atualizar a página. Se persistir, comunicar com identificação do equipamento e hora do registo. |
| Backup falhou | Registar a falha, informar a Gestão e verificar a execução seguinte ou solicitar backup manual controlado. |
| Suspeita de acesso indevido | Solicitar desativação/alteração do PIN, preservar evidências e comunicar imediatamente à Gestão. |
| Dados aparentemente incorretos após restauro | Suspender alterações adicionais, registar o incidente e contactar a Gestão para avaliação. |

Os registos temporários usados durante uma indisponibilidade devem ser controlados, protegidos contra perda e transcritos para o Dashboard logo que possível.

## 11. Registos e evidências

Devem ser mantidos, de acordo com os prazos internos de retenção:

- registos de intervenções preventivas;
- registos de avarias e ordens de trabalho corretivas;
- validações e libertações de equipamentos;
- alterações de utilizadores e PINs;
- histórico de backups e recuperações;
- comunicações de falhas ou indisponibilidades;
- evidências de formação e autorização dos utilizadores;
- revisões e alterações deste procedimento.

A informação deve ser legível, recuperável e associada ao equipamento/intervenção correta.

## 12. Indicadores de acompanhamento

A Responsável de Qualidade e o Responsável de Manutenção podem acompanhar, pelo menos mensalmente:

- percentagem de manutenções preventivas realizadas dentro do prazo;
- número de intervenções pendentes de validação;
- tempo médio entre registo e validação;
- número de avarias abertas e concluídas;
- número de intervenções devolvidas para correção;
- percentagem de backups semanais concluídos;
- número de falhas de acesso ou incidentes de dados.

Quando um indicador revelar desvio relevante, deve ser aberta ação de análise e melhoria de acordo com o sistema de gestão da qualidade.

## 13. Formação e competência

1. Cada utilizador deve receber instrução sobre o painel correspondente às suas funções.
2. Os utilizadores que validam intervenções devem conhecer os critérios de aceitação e libertação de equipamentos.
3. A Gestão e a Responsável de Qualidade devem conhecer o processo de gestão de PINs e backups.
4. A formação deve ser registada e atualizada quando houver alterações relevantes na aplicação.
5. O acesso deve ser removido ou revisto quando a pessoa deixa de desempenhar a função.

## 14. Controlo de alterações do procedimento

| Versão | Data | Descrição da alteração | Elaborado por | Aprovado por |
|---|---|---|---|---|
| 1.0 | 06/10/2026 | Emissão inicial do procedimento para utilização e controlo do Dashboard de Manutenção. | Responsável de Qualidade | A preencher |

## 15. Lista de verificação de utilização

### No início do turno

- [ ] Acedi com o meu próprio perfil.
- [ ] Confirmei o painel correto.
- [ ] Consultei tarefas ou ordens de trabalho pendentes.
- [ ] Verifiquei alertas relevantes.

### Após uma intervenção

- [ ] Confirmei o equipamento correto.
- [ ] Registei o trabalho executado com detalhe suficiente.
- [ ] Registei anomalias, peças ou ações pendentes.
- [ ] Guardei e confirmei o registo.
- [ ] Encaminhei para validação quando aplicável.

### Antes de validar

- [ ] Tenho competência e autorização para validar.
- [ ] Confirmei o nome e a identificação do equipamento.
- [ ] Verifiquei o detalhe da intervenção.
- [ ] Confirmei a condição/libertação do equipamento, quando aplicável.
- [ ] Registei a decisão e o motivo em caso de devolução.

### Verificação mensal de backups

- [ ] Existe backup recente concluído.
- [ ] A retenção de 12 semanas está disponível.
- [ ] Não existem falhas sem tratamento.
- [ ] O histórico foi consultado e, se necessário, arquivado.

---

**Nota de controlo:** Este procedimento deve ser aprovado antes de ser considerado documento vigente do sistema de gestão da qualidade. Qualquer alteração à autenticação, perfis, regras de validação, estrutura dos painéis ou política de backups deve ser avaliada quanto ao impacto neste documento.
