# Publicação independente na Vercel

Este pacote publica o frontend Vite e a API tRPC como função serverless em `api/[...path].ts`. O histórico de intervenções, validações, equipamentos e áreas é mantido numa base MySQL/TiDB externa; anexos e backups são guardados num bucket S3 compatível.

## Variáveis de ambiente obrigatórias na Vercel

Adicionar em **Project Settings → Environment Variables**:

- `DATABASE_URL`: ligação MySQL/TiDB da base que contém o histórico.
- `JWT_SECRET`: segredo aleatório longo para sessões.
- `S3_ENDPOINT`: endpoint S3, por exemplo AWS S3, Cloudflare R2 ou Backblaze B2.
- `S3_REGION`: região do bucket (`auto` para R2, quando aplicável).
- `S3_ACCESS_KEY_ID`: chave de acesso do bucket.
- `S3_SECRET_ACCESS_KEY`: segredo da chave.
- `S3_BUCKET`: nome do bucket.
- `CRON_SECRET`: segredo aleatório usado para autenticar o cron semanal.
- `BACKUP_CRON_UID`: opcional; identificador estável do cron, por defeito `vercel-backup-semanal`.

Não adicionar os valores ao Git nem ao ZIP.

## Preparação da base de dados

Depois de configurar `DATABASE_URL` localmente, executar:

```bash
pnpm install
pnpm db:push
```

A operação cria/atualiza as tabelas Drizzle, preservando o histórico existente quando se usa a mesma base de dados.

## Publicação

Importar o conteúdo deste pacote como projeto Vercel. A raiz contém `package.json`, `pnpm-lock.yaml`, `vercel.json`, `client/`, `server/`, `drizzle/`, `shared/` e `api/`. A Vercel executa `pnpm install --frozen-lockfile` e `pnpm run build`; o frontend é servido a partir de `dist/public` e os pedidos `/api/*` são encaminhados para a função serverless.

Esta versão não usa o runtime de debug da Manus nem o armazenamento Manus. O domínio, a base de dados e o bucket passam a ser controlados pelo proprietário da conta Vercel.

O `vercel.json` agenda o backup aos domingos às 03:00 UTC. A primeira execução regista o UID do cron na base de dados; a retenção de 12 semanas e a proteção contra duplicação continuam a ser aplicadas pelo serviço de backups.
