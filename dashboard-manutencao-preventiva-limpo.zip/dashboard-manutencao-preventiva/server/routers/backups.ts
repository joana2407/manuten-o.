import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { autenticarValidador } from "../db";
import { criarBackup, listarBackupsDisponiveis, obterLinkBackupExcel, restaurarBackup } from "../services/backups";
import { publicProcedure, router } from "../_core/trpc";

const credenciais = z.object({
  nomeUtilizador: z.string().min(1),
  pin: z.string().min(1),
});

async function exigirSessao(input: z.infer<typeof credenciais>) {
  const utilizador = await autenticarValidador(input.nomeUtilizador, input.pin);
  if (!utilizador) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sessão de acesso inválida." });
  }
  return utilizador;
}

async function exigirGestao(input: z.infer<typeof credenciais>) {
  const utilizador = await exigirSessao(input);
  if (!utilizador.podeGerir) {
    throw new TRPCError({ code: "FORBIDDEN", message: "A recuperação de backups é reservada ao perfil Gestão." });
  }
  return utilizador;
}

export const backupsRouter = router({
  listar: publicProcedure.input(credenciais).query(async ({ input }) => {
    await exigirSessao(input);
    return listarBackupsDisponiveis();
  }),

  obterDownloadExcel: publicProcedure
    .input(credenciais.extend({ id: z.string().min(1) }))
    .mutation(async ({ input }) => {
      await exigirSessao(input);
      try {
        const { backup, nomeFicheiro, url, tamanhoBytes } = await obterLinkBackupExcel(input.id);
        return { id: backup.id, nomeFicheiro, tamanhoBytes, url, formato: "xlsx" as const };
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Não foi possível exportar o backup para Excel: ${String(error)}` });
      }
    }),

  criarAgora: publicProcedure.input(credenciais).mutation(async ({ input }) => {
    await exigirGestao(input);
    try {
      return await criarBackup("automatico");
    } catch (error) {
      throw new TRPCError({ code: "INTERNAL_SERVER_ERROR", message: `Não foi possível criar o backup: ${String(error)}` });
    }
  }),

  restaurar: publicProcedure
    .input(credenciais.extend({ id: z.string().min(1), confirmacao: z.literal("RESTAURAR") }))
    .mutation(async ({ input }) => {
      const utilizador = await exigirGestao(input);
      try {
        return await restaurarBackup(input.id, utilizador.nome);
      } catch (error) {
        throw new TRPCError({ code: "BAD_REQUEST", message: `Não foi possível recuperar o backup: ${String(error)}` });
      }
    }),
});
