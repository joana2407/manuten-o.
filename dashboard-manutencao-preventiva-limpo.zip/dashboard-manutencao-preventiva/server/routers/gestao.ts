/**
 * Router tRPC — Gestão de Áreas, Equipamentos e Overrides
 * Permite: criar áreas (com fábrica), criar/editar/eliminar equipamentos, inativar/reativar
 */
import { z } from "zod";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { publicProcedure, router } from "../_core/trpc";
import {
  listarAreasCustom,
  upsertAreaBase,
  criarAreaCustom,
  editarAreaCustom,
  eliminarAreaCustom,
  toggleInativoAreaCustom,
  listarEquipamentosCustom,
  criarEquipamentoCustom,
  editarEquipamentoCustom,
  eliminarEquipamentoCustom,
  toggleInativoEquipamentoCustom,
  criarIntervencao,
  listarOverrides,
  upsertOverride,
  upsertEquipamentoOverrideEdicao,
  eliminarEquipamentoBase,
  autenticarValidador,
} from "../db";

// Código global mantido para compatibilidade com a Gestão.
const CODIGO_ACESSO = process.env.CODIGO_ACESSO_GESTAO ?? "manut2026";

/** A Gestão usa o código global; os perfis autorizados podem usar o próprio PIN. */
async function exigirGestaoEquipamentos(codigoAcesso: string, nomeUtilizador?: string) {
  if (codigoAcesso === CODIGO_ACESSO) return;
  const resultado = nomeUtilizador ? await autenticarValidador(nomeUtilizador, codigoAcesso) : null;
  if (!resultado?.podeGerirEquipamentos) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem autorização para gerir equipamentos e áreas." });
  }
}

export const gestaoRouter = router({
  listarAreas: publicProcedure.query(async () => listarAreasCustom()),

  seedAreasBase: publicProcedure
    .input(z.object({ areas: z.array(z.object({ nome: z.string(), fabrica: z.string() })) }))
    .mutation(async ({ input }) => {
      const results = [];
      for (const a of input.areas) results.push(await upsertAreaBase(a.nome, a.fabrica));
      return results;
    }),

  criarArea: publicProcedure
    .input(z.object({
      nome: z.string().min(1).max(128),
      descricao: z.string().max(512).optional(),
      fabrica: z.string().max(64).optional(),
    }))
    .mutation(async ({ input }) => {
      const id = nanoid();
      await criarAreaCustom({
        id,
        nome: input.nome,
        descricao: input.descricao ?? null,
        fabrica: input.fabrica ?? "Fábrica I",
        criadoEm: Date.now(),
      });
      return { id };
    }),

  editarArea: publicProcedure
    .input(z.object({
      id: z.string(),
      codigoAcesso: z.string(),
      nomeUtilizador: z.string().optional(),
      nome: z.string().min(1).max(128).optional(),
      descricao: z.string().max(512).optional(),
      fabrica: z.string().max(64).optional(),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      const { id, codigoAcesso: _, nomeUtilizador: __, ...campos } = input;
      await editarAreaCustom(id, campos);
      return { ok: true };
    }),

  eliminarArea: publicProcedure
    .input(z.object({ id: z.string(), codigoAcesso: z.string(), nomeUtilizador: z.string().optional() }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await eliminarAreaCustom(input.id);
      return { ok: true };
    }),

  toggleInativoArea: publicProcedure
    .input(z.object({ id: z.string(), codigoAcesso: z.string(), nomeUtilizador: z.string().optional(), inativo: z.boolean() }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await toggleInativoAreaCustom(input.id, input.inativo);
      return { ok: true };
    }),

  listarEquipamentos: publicProcedure.query(async () => listarEquipamentosCustom()),

  criarEquipamento: publicProcedure
    .input(z.object({
      codigo: z.string().min(1).max(32),
      equipamento: z.string().min(1).max(256),
      area: z.string().min(1).max(128),
      periodicidade: z.string().max(64).optional(),
      estado: z.string().max(32).optional(),
      dataUltimaIntervencao: z.string().optional(),
      modelo: z.string().max(256).optional(),
      numeroSerie: z.string().max(128).optional(),
      planoIntervencao: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const id = nanoid();
      await criarEquipamentoCustom({
        id,
        codigo: input.codigo,
        equipamento: input.equipamento,
        area: input.area,
        periodicidade: input.periodicidade ?? null,
        estado: input.estado ?? "Ativo",
        inativo: false,
        modelo: input.modelo ?? null,
        numeroSerie: input.numeroSerie ?? null,
        planoIntervencao: input.planoIntervencao ?? null,
        criadoEm: Date.now(),
        atualizadoEm: null,
      });
      if (input.dataUltimaIntervencao) {
        await criarIntervencao({
          id: nanoid(),
          codigoEquipamento: input.codigo,
          area: input.area,
          dataRealizacao: input.dataUltimaIntervencao,
          intervencaoRealizada: "Registo inicial (data de última intervenção)",
          materialGasto: null,
          responsavel: null,
          criadoEm: Date.now(),
        });
      }
      return { id };
    }),

  editarEquipamento: publicProcedure
    .input(z.object({
      id: z.string(),
      codigoAcesso: z.string(),
      nomeUtilizador: z.string().optional(),
      codigo: z.string().min(1).max(32).optional(),
      equipamento: z.string().min(1).max(256).optional(),
      area: z.string().min(1).max(128).optional(),
      periodicidade: z.string().max(64).optional(),
      estado: z.string().max(32).optional(),
      modelo: z.string().max(256).optional(),
      numeroSerie: z.string().max(128).optional(),
      planoIntervencao: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      const { id, codigoAcesso: _, nomeUtilizador: __, ...campos } = input;
      await editarEquipamentoCustom(id, campos);
      return { ok: true };
    }),

  eliminarEquipamento: publicProcedure
    .input(z.object({ id: z.string(), codigoAcesso: z.string(), nomeUtilizador: z.string().optional() }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await eliminarEquipamentoCustom(input.id);
      return { ok: true };
    }),

  toggleInativoCustom: publicProcedure
    .input(z.object({ id: z.string(), codigoAcesso: z.string(), nomeUtilizador: z.string().optional(), inativo: z.boolean() }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await toggleInativoEquipamentoCustom(input.id, input.inativo);
      return { ok: true };
    }),

  listarOverrides: publicProcedure.query(async () => listarOverrides()),

  upsertEquipamentoOverride: publicProcedure
    .input(z.object({
      codigoEquipamento: z.string(),
      area: z.string(),
      codigoAcesso: z.string(),
      nomeUtilizador: z.string().optional(),
      novoNome: z.string().max(256).optional(),
      novaArea: z.string().max(128).optional(),
      novaPeriodicidade: z.string().max(64).optional(),
      modelo: z.string().max(256).optional(),
      numeroSerie: z.string().max(128).optional(),
      planoIntervencao: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await upsertEquipamentoOverrideEdicao(input.codigoEquipamento, input.area, {
        novoNome: input.novoNome,
        novaArea: input.novaArea,
        novaPeriodicidade: input.novaPeriodicidade,
        modelo: input.modelo,
        numeroSerie: input.numeroSerie,
        planoIntervencao: input.planoIntervencao,
      });
      return { ok: true };
    }),

  eliminarEquipamentoBase: publicProcedure
    .input(z.object({ codigoEquipamento: z.string(), area: z.string(), codigoAcesso: z.string(), nomeUtilizador: z.string().optional() }))
    .mutation(async ({ input }) => {
      await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await eliminarEquipamentoBase(input.codigoEquipamento, input.area);
      return { ok: true };
    }),

  toggleInativo: publicProcedure
    .input(z.object({
      codigoEquipamento: z.string(),
      area: z.string(),
      inativo: z.boolean(),
      codigoAcesso: z.string().optional(),
      nomeUtilizador: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      if (input.codigoAcesso !== undefined) await exigirGestaoEquipamentos(input.codigoAcesso, input.nomeUtilizador);
      await upsertOverride(input.codigoEquipamento, input.area, input.inativo);
      return { ok: true };
    }),
});
