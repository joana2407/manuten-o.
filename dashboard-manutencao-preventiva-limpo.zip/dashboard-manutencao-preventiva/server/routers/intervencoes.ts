/**
 * Router tRPC para gestão de intervenções e anexos de manutenção preventiva.
 */
import { z } from "zod";
import { nanoid } from "nanoid";
import { TRPCError } from "@trpc/server";
import { publicProcedure, router } from "../_core/trpc";
import {
  criarIntervencao,
  listarIntervencoesPorEquipamento,
  listarTodasIntervencoes,
  removerIntervencao,
  editarIntervencao,
  criarAnexo,
  listarAnexosPorIntervencoes,
  validarIntervencao,
  listarIntervencoesPorValidar,
  listarEquipamentosCustom,
  listarOverrides,
  autenticarValidador,
  listarValidadores,
  criarValidador,
  alterarPinValidador,
  toggleAtivoValidador,
  eliminarValidador,
  listarTodosValidadores,
} from "../db";
import { storagePut } from "../storage";

async function exigirGestao(nomeUtilizador: string, pin: string) {
  const resultado = await autenticarValidador(nomeUtilizador, pin);
  if (!resultado || !resultado.podeGerir) {
    throw new TRPCError({ code: "FORBIDDEN", message: "PIN de Gestão inválido." });
  }
  return resultado;
}

async function exigirGestaoPins(nomeUtilizador: string, pin: string) {
  const resultado = await autenticarValidador(nomeUtilizador, pin);
  if (!resultado || !resultado.podeGerirPins) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem autorização para gerir PINs de acesso." });
  }
  return resultado;
}

async function exigirGestaoUtilizadores(nomeUtilizador: string, pin: string) {
  const resultado = await autenticarValidador(nomeUtilizador, pin);
  if (!resultado || !resultado.podeGerirUtilizadores) {
    throw new TRPCError({ code: "FORBIDDEN", message: "Sem autorização para gerir utilizadores." });
  }
  return resultado;
}

export const intervencoesRouter = router({
  // Listar intervenções de um equipamento específico (com anexos)
  listar: publicProcedure
    .input(z.object({ codigoEquipamento: z.string(), area: z.string() }))
    .query(async ({ input }) => {
      const lista = await listarIntervencoesPorEquipamento(input.codigoEquipamento, input.area);
      const ids = lista.map(i => i.id);
      const todosAnexos = await listarAnexosPorIntervencoes(ids);
      return lista.map(i => ({
        ...i,
        anexos: todosAnexos.filter(a => a.intervencaoId === i.id),
      }));
    }),

  // Listar todas as intervenções (para filtro por responsável e exportação)
  listarTodas: publicProcedure.query(async () => {
    const lista = await listarTodasIntervencoes();
    const ids = lista.map(i => i.id);
    const todosAnexos = await listarAnexosPorIntervencoes(ids);
    return lista.map(i => ({
      ...i,
      anexos: todosAnexos.filter(a => a.intervencaoId === i.id),
    }));
  }),

  // Listar intervenções pendentes de validação (com anexos e nome do equipamento)
  listarPorValidar: publicProcedure.query(async () => {
    const lista = await listarIntervencoesPorValidar();
    const ids = lista.map(i => i.id);
    const todosAnexos = await listarAnexosPorIntervencoes(ids);

    // Construir mapa de nomes: JSON base + equipamentos custom + overrides de edição
    const nomeMap = new Map<string, string>();

    // 1. Equipamentos do JSON base (ficheiro estático)
    try {
      const { readFileSync } = await import("fs");
      const { join } = await import("path");
      const jsonPath = join(process.cwd(), "client", "public", "manutencao.json");
      const jsonData = JSON.parse(readFileSync(jsonPath, "utf-8")) as {
        equipamentos: { codigo: string; area: string; equipamento: string }[];
      };
      for (const eq of jsonData.equipamentos) {
        nomeMap.set(`${eq.codigo}||${eq.area}`, eq.equipamento);
      }
    } catch {
      // JSON não disponível — continuar sem nomes do plano base
    }

    // 2. Equipamentos custom (têm precedência sobre o JSON base)
    const equipamentosCustomLista = await listarEquipamentosCustom();
    for (const eq of equipamentosCustomLista) {
      nomeMap.set(`${eq.codigo}||${eq.area}`, eq.equipamento);
    }

    // 3. Overrides de edição de nome (máxima precedência)
    const overrides = await listarOverrides();
    for (const ov of overrides) {
      if (ov.novoNome) {
        nomeMap.set(`${ov.codigoEquipamento}||${ov.area}`, ov.novoNome);
      }
    }

    return lista.map(i => ({
      ...i,
      nomeEquipamento: nomeMap.get(`${i.codigoEquipamento}||${i.area}`) ?? null,
      anexos: todosAnexos.filter(a => a.intervencaoId === i.id),
    }));
  }),

  // Criar nova intervenção
  criar: publicProcedure
    .input(
      z.object({
        codigoEquipamento: z.string(),
        area: z.string(),
        dataRealizacao: z.string(),
        intervencaoRealizada: z.string().optional(),
        materialGasto: z.string().optional(),
        responsavel: z.string().optional(),
        responsavelValidacao: z.string().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      const id = nanoid();
      await criarIntervencao({
        id,
        codigoEquipamento: input.codigoEquipamento,
        area: input.area,
        dataRealizacao: input.dataRealizacao,
        intervencaoRealizada: input.intervencaoRealizada ?? null,
        materialGasto: input.materialGasto ?? null,
        responsavel: input.responsavel ?? null,
        responsavelValidacao: input.responsavelValidacao ?? null,
        criadoEm: Date.now(),
      });
      return { id };
    }),

  // Remover intervenção (e respetivos anexos)
  remover: publicProcedure
    .input(z.object({ id: z.string() }))
    .mutation(async ({ input }) => {
      await removerIntervencao(input.id);
      return { ok: true };
    }),

  // Editar o conteúdo da intervenção e a informação de validação
  editar: publicProcedure
    .input(z.object({
      id: z.string(),
      intervencaoRealizada: z.string().nullable(),
      materialGasto: z.string().nullable(),
      responsavelValidacao: z.string().nullable(),
      validadoPor: z.string().nullable(),
    }))
    .mutation(async ({ input }) => {
      await editarIntervencao(input.id, {
        intervencaoRealizada: input.intervencaoRealizada?.trim() || null,
        materialGasto: input.materialGasto?.trim() || null,
        responsavelValidacao: input.responsavelValidacao?.trim() || null,
        validadoPor: input.validadoPor?.trim() || null,
        ...(input.validadoPor?.trim() ? {} : { validadoEm: null }),
      });
      return { ok: true };
    }),

  // Validar intervenção — protegido por código de acesso
  validar: publicProcedure
    .input(
      z.object({
        id: z.string(),
        validadoPor: z.string().min(1, "Nome do responsável é obrigatório"),
        nomeUtilizador: z.string().min(1, "Nome de utilizador é obrigatório"),
        codigoAcesso: z.string(),
      }),
    )
    .mutation(async ({ input }) => {
      const resultado = await autenticarValidador(input.nomeUtilizador, input.codigoAcesso);
      if (!resultado) {
        throw new TRPCError({ code: "FORBIDDEN", message: "PIN inválido ou utilizador inativo." });
      }
      await validarIntervencao(input.id, resultado.nome);
      return { ok: true };
    }),

  // Upload de anexo para uma intervenção
  uploadAnexo: publicProcedure
    .input(
      z.object({
        intervencaoId: z.string(),
        filename: z.string(),
        mimeType: z.string(),
        dataBase64: z.string(), // base64 do ficheiro
        tamanhoBytes: z.number().optional(),
      }),
    )
    .mutation(async ({ input }) => {
      // Converter base64 para Buffer
      const buffer = Buffer.from(input.dataBase64, "base64");
      const storageKey = `manutencao/anexos/${input.intervencaoId}/${input.filename}`;
      const { key, url } = await storagePut(storageKey, buffer, input.mimeType);

      const anexoId = nanoid();
      await criarAnexo({
        id: anexoId,
        intervencaoId: input.intervencaoId,
        filename: input.filename,
        mimeType: input.mimeType,
        storageKey: key,
        storageUrl: url,
        tamanhoBytes: input.tamanhoBytes ?? null,
        criadoEm: Date.now(),
      });

      return { id: anexoId, url };
    }),

  // Autenticar validador pelo PIN — retorna nome se correto
  autenticarValidador: publicProcedure
    .input(z.object({ nomeUtilizador: z.string().min(1), pin: z.string().min(1) }))
    .mutation(async ({ input }) => {
      const resultado = await autenticarValidador(input.nomeUtilizador, input.pin);
      if (!resultado) {
        throw new TRPCError({ code: "FORBIDDEN", message: "PIN inválido." });
      }
      return {
        id: resultado.id,
        nome: resultado.nome,
        nomeUtilizador: resultado.nomeUtilizador,
        perfil: resultado.perfil,
        funcao: resultado.funcao,
        podeRegistar: resultado.podeRegistar,
        podeValidar: resultado.podeValidar,
        podeGerir: resultado.podeGerir,
        podeGerirEquipamentos: resultado.podeGerirEquipamentos,
        podeGerirPins: resultado.podeGerirPins,
        podeGerirUtilizadores: resultado.podeGerirUtilizadores,
      };
    }),

  // Validar intervenção com sessão já autenticada (sem código de acesso extra)
  validarComSessao: publicProcedure
    .input(
      z.object({
        id: z.string(),
        validadoPor: z.string().min(1),
        validadorId: z.string().min(1), // id do validador autenticado
        nomeUtilizador: z.string().min(1),
        pin: z.string().min(1),          // PIN para confirmar a sessão server-side
      }),
    )
    .mutation(async ({ input }) => {
      // Verificar que o validador ainda é válido. O frontend Vercel pode usar
      // ids locais (mock-*) no sessionStorage; a identidade canónica é o
      // nome de utilizador autenticado pelo PIN, não o id visual da sessão.
      const resultado = await autenticarValidador(input.nomeUtilizador, input.pin);
      const mesmaIdentidade = resultado?.nomeUtilizador
        ? resultado.nomeUtilizador === input.nomeUtilizador
        : resultado?.id === input.validadorId;
      if (!resultado || !mesmaIdentidade) {
        throw new TRPCError({ code: "FORBIDDEN", message: "Sessão inválida." });
      }
      await validarIntervencao(input.id, resultado.nome);
      return { ok: true };
    }),

  // Listar validadores ativos (sem PIN)
  listarValidadores: publicProcedure.query(async () => {
    return listarValidadores();
  }),

  // ─── Gestão de Validadores (protegida por código de acesso) ──────────────────

  // Listar todos os validadores (ativos e inativos) — para painel de gestão
  listarTodosValidadores: publicProcedure
    .input(z.object({ nomeUtilizador: z.string(), codigoAcesso: z.string() }))
    .query(async ({ input }) => {
      await exigirGestaoUtilizadores(input.nomeUtilizador, input.codigoAcesso);
      return listarTodosValidadores();
    }),

  // Criar novo validador
  criarValidador: publicProcedure
    .input(z.object({
      nomeUtilizador: z.string(),
      codigoAcesso: z.string(),
      nome: z.string().min(2),
      nomeUtilizadorNovo: z.string().min(3),
      pin: z.string().min(4),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoUtilizadores(input.nomeUtilizador, input.codigoAcesso);
      await criarValidador(input.nome, input.nomeUtilizadorNovo, input.pin);
      return { ok: true };
    }),

  // Alterar PIN de um validador
  alterarPinValidador: publicProcedure
    .input(z.object({
      nomeUtilizador: z.string(),
      codigoAcesso: z.string(),
      id: z.string(),
      novoPin: z.string().min(4),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoUtilizadores(input.nomeUtilizador, input.codigoAcesso);
      await alterarPinValidador(input.id, input.novoPin);
      return { ok: true };
    }),

  // Ativar ou desativar validador
  toggleAtivoValidador: publicProcedure
    .input(z.object({
      nomeUtilizador: z.string(),
      codigoAcesso: z.string(),
      id: z.string(),
      ativo: z.boolean(),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoUtilizadores(input.nomeUtilizador, input.codigoAcesso);
      await toggleAtivoValidador(input.id, input.ativo);
      return { ok: true };
    }),

  // Eliminar validador
  eliminarValidador: publicProcedure
    .input(z.object({
      nomeUtilizador: z.string(),
      codigoAcesso: z.string(),
      id: z.string(),
    }))
    .mutation(async ({ input }) => {
      await exigirGestaoUtilizadores(input.nomeUtilizador, input.codigoAcesso);
      await eliminarValidador(input.id);
      return { ok: true };
    }),
});
