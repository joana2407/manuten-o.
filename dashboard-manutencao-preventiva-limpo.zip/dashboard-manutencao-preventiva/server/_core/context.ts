import type { CreateExpressContextOptions } from "@trpc/server/adapters/express";
import type { User } from "../../drizzle/schema";

export type TrpcContext = {
  req: CreateExpressContextOptions["req"];
  res: CreateExpressContextOptions["res"];
  user: User | null;
};

/**
 * A aplicação usa autenticação própria por utilizador/PIN e não depende de
 * OAuth externo. O contexto tRPC mantém user nulo para compatibilidade com
 * procedimentos públicos e deixa as autorizações operacionais nos routers.
 */
export async function createContext(
  opts: CreateExpressContextOptions,
): Promise<TrpcContext> {
  return { req: opts.req, res: opts.res, user: null };
}
