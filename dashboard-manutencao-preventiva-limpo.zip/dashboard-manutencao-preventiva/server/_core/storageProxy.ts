import type { Express } from "express";
import { storageGetSignedUrl } from "../storage";

export function registerStorageProxy(app: Express) {
  app.get("/storage/*", async (req, res) => {
    const key = (req.params as Record<string, string>)[0];
    if (!key) {
      res.status(400).send("Chave de armazenamento em falta");
      return;
    }
    try {
      const url = await storageGetSignedUrl(decodeURIComponent(key));
      res.set("Cache-Control", "private, max-age=300");
      res.redirect(307, url);
    } catch (error) {
      console.error("[StorageProxy] falha:", error);
      res.status(502).send("Não foi possível obter o ficheiro");
    }
  });
}
