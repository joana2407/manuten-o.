import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { and, desc, eq, gte } from "drizzle-orm";
import { nanoid } from "nanoid";
import * as XLSX from "xlsx";
import {
  anexos,
  areasCustom,
  backupsAplicacao,
  configuracaoBackups,
  equipamentosCustom,
  equipamentosOverride,
  execucoesBackups,
  intervencoes,
  validadoresAcesso,
} from "../../drizzle/schema";
import { getDb } from "../db";
import { storageGetSignedUrl, storagePut } from "../storage";

export const BACKUP_CONFIG_ID = "backup-semanal-manutencao";
const SEMANA_EM_MS = 7 * 24 * 60 * 60 * 1000;

type OrigemBackup = "automatico" | "antes_restauro";

export type SnapshotBackup = {
  versao: 1;
  criadoEm: number;
  dados: {
    intervencoes: typeof intervencoes.$inferSelect[];
    anexos: typeof anexos.$inferSelect[];
    areasCustom: typeof areasCustom.$inferSelect[];
    equipamentosCustom: typeof equipamentosCustom.$inferSelect[];
    equipamentosOverride: typeof equipamentosOverride.$inferSelect[];
    // Mantém a configuração visível de acessos sem copiar hashes de PIN.
    validadores: Array<{ id: string; nome: string; nomeUtilizador: string | null; ativo: boolean; criadoEm: number }>;
  };
};

function nomeDoFicheiro(agora: number) {
  const selo = new Date(agora).toISOString().replace(/[:.]/g, "-");
  return `backup-manutencao-${selo}.json`;
}

async function obterOuCriarConfiguracao() {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");

  const existente = await db
    .select()
    .from(configuracaoBackups)
    .where(eq(configuracaoBackups.id, BACKUP_CONFIG_ID))
    .limit(1);
  if (existente[0]) return existente[0];

  const agora = Date.now();
  await db.insert(configuracaoBackups).values({
    id: BACKUP_CONFIG_ID,
    ativo: true,
    retencaoSemanas: 12,
    atualizadoEm: agora,
  });
  return (await db.select().from(configuracaoBackups).where(eq(configuracaoBackups.id, BACKUP_CONFIG_ID)).limit(1))[0];
}

async function recolherSnapshot(): Promise<SnapshotBackup> {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");

  const [listaIntervencoes, listaAnexos, listaAreas, listaEquipamentos, listaOverrides, listaValidadores] = await Promise.all([
    db.select().from(intervencoes),
    db.select().from(anexos),
    db.select().from(areasCustom),
    db.select().from(equipamentosCustom),
    db.select().from(equipamentosOverride),
    db.select({
      id: validadoresAcesso.id,
      nome: validadoresAcesso.nome,
      nomeUtilizador: validadoresAcesso.nomeUtilizador,
      ativo: validadoresAcesso.ativo,
      criadoEm: validadoresAcesso.criadoEm,
    }).from(validadoresAcesso),
  ]);

  return {
    versao: 1,
    criadoEm: Date.now(),
    dados: {
      intervencoes: listaIntervencoes,
      anexos: listaAnexos,
      areasCustom: listaAreas,
      equipamentosCustom: listaEquipamentos,
      equipamentosOverride: listaOverrides,
      validadores: listaValidadores,
    },
  };
}

function validarSnapshot(valor: unknown): SnapshotBackup {
  const snapshot = valor as Partial<SnapshotBackup>;
  const dados = snapshot.dados;
  if (
    snapshot.versao !== 1 ||
    !dados ||
    !Array.isArray(dados.intervencoes) ||
    !Array.isArray(dados.anexos) ||
    !Array.isArray(dados.areasCustom) ||
    !Array.isArray(dados.equipamentosCustom) ||
    !Array.isArray(dados.equipamentosOverride)
  ) {
    throw new Error("O ficheiro de backup não tem uma estrutura reconhecida.");
  }
  return snapshot as SnapshotBackup;
}

async function aplicarRetencao(retencaoSemanas: number) {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");

  const automaticos = await db
    .select()
    .from(backupsAplicacao)
    .where(eq(backupsAplicacao.origem, "automatico"))
    .orderBy(desc(backupsAplicacao.criadoEm));

  const excedentes = automaticos.slice(Math.max(1, retencaoSemanas));
  if (excedentes.length === 0) return;

  await Promise.all(
    excedentes
      .filter(backup => backup.estado === "concluido")
      .map(backup => db.update(backupsAplicacao).set({ estado: "expirado" }).where(eq(backupsAplicacao.id, backup.id))),
  );
}

export async function criarBackup(origem: OrigemBackup = "automatico") {
  const configuracao = await obterOuCriarConfiguracao();
  const agora = Date.now();
  const snapshot = await recolherSnapshot();
  const conteudo = JSON.stringify(snapshot);
  const checksum = createHash("sha256").update(conteudo).digest("hex");
  const nomeFicheiro = nomeDoFicheiro(agora);
  const id = nanoid();
  const { key } = await storagePut(`manutencao/backups/${nomeFicheiro}`, conteudo, "application/json");
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");

  await db.insert(backupsAplicacao).values({
    id,
    origem,
    estado: "concluido",
    nomeFicheiro,
    storageKey: key,
    tamanhoBytes: Buffer.byteLength(conteudo, "utf8"),
    checksum,
    criadoEm: agora,
    expiraEm: agora + configuracao.retencaoSemanas * SEMANA_EM_MS,
  });

  if (origem === "automatico") await aplicarRetencao(configuracao.retencaoSemanas);
  return { id, nomeFicheiro, criadoEm: agora, checksum };
}

export async function listarBackupsDisponiveis() {
  const db = await getDb();
  if (!db) return [];
  const agora = Date.now();
  const lista = await db.select().from(backupsAplicacao).orderBy(desc(backupsAplicacao.criadoEm));
  return lista.filter(backup => backup.estado === "concluido" && backup.expiraEm >= agora);
}

export async function obterLinkBackup(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");
  const backup = (await db.select().from(backupsAplicacao).where(eq(backupsAplicacao.id, id)).limit(1))[0];
  if (!backup || backup.estado !== "concluido" || backup.expiraEm < Date.now()) {
    throw new Error("Backup indisponível ou expirado.");
  }
  return { backup, url: await storageGetSignedUrl(backup.storageKey) };
}

function dataExcel(valor: number | null | undefined) {
  return valor ? new Date(valor) : null;
}

function mapaNomesEquipamentos(snapshot: SnapshotBackup) {
  const mapa = new Map<string, string>();
  try {
    const jsonPath = join(process.cwd(), "client", "public", "manutencao.json");
    const plano = JSON.parse(readFileSync(jsonPath, "utf8")) as {
      equipamentos?: Array<{ codigo: string; area: string; equipamento: string }>;
    };
    for (const equipamento of plano.equipamentos ?? []) {
      mapa.set(`${equipamento.codigo}||${equipamento.area}`, equipamento.equipamento);
    }
  } catch {
    // O Excel continua a ser gerado mesmo que o plano base não esteja disponível.
  }
  for (const equipamento of snapshot.dados.equipamentosCustom) {
    mapa.set(`${equipamento.codigo}||${equipamento.area}`, equipamento.equipamento);
  }
  for (const override of snapshot.dados.equipamentosOverride) {
    if (override.novoNome) {
      mapa.set(`${override.codigoEquipamento}||${override.area}`, override.novoNome);
    }
  }
  return mapa;
}

/** Gera um ficheiro Excel de consulta, sem expor hashes de PINs. */
export function gerarExcelBackup(snapshot: SnapshotBackup): Buffer {
  const workbook = XLSX.utils.book_new();
  const nomesEquipamentos = mapaNomesEquipamentos(snapshot);
  const adicionarFolha = (nome: string, linhas: Record<string, unknown>[]) => {
    const folha = XLSX.utils.json_to_sheet(linhas);
    XLSX.utils.book_append_sheet(workbook, folha, nome);
  };

  adicionarFolha("Intervenções", snapshot.dados.intervencoes.map(item => ({
    ID: item.id,
    Equipamento: item.codigoEquipamento,
    "Nome equipamento": nomesEquipamentos.get(`${item.codigoEquipamento}||${item.area}`) ?? null,
    Área: item.area,
    "Data realização": item.dataRealizacao,
    Intervenção: item.intervencaoRealizada,
    "Material gasto": item.materialGasto,
    Responsável: item.responsavel,
    "Resp. validação": item.responsavelValidacao,
    "Validado por": item.validadoPor,
    "Validado em": dataExcel(item.validadoEm),
    "Criado em": dataExcel(item.criadoEm),
  })));
  adicionarFolha("Anexos", snapshot.dados.anexos.map(item => ({
    ID: item.id,
    "ID intervenção": item.intervencaoId,
    Ficheiro: item.filename,
    "Tipo MIME": item.mimeType,
    "Tamanho bytes": item.tamanhoBytes,
    "Criado em": dataExcel(item.criadoEm),
  })));
  adicionarFolha("Áreas", snapshot.dados.areasCustom.map(item => ({
    ID: item.id,
    Área: item.nome,
    Descrição: item.descricao,
    Fábrica: item.fabrica,
    Inativa: item.inativo ? "Sim" : "Não",
    Eliminada: item.eliminado ? "Sim" : "Não",
    "Criada em": dataExcel(item.criadoEm),
  })));
  adicionarFolha("Equipamentos", snapshot.dados.equipamentosCustom.map(item => ({
    ID: item.id,
    Código: item.codigo,
    Equipamento: item.equipamento,
    Área: item.area,
    Periodicidade: item.periodicidade,
    Estado: item.estado,
    Modelo: item.modelo,
    "N.º série": item.numeroSerie,
    "Plano intervenção": item.planoIntervencao,
    Inativo: item.inativo ? "Sim" : "Não",
    "Criado em": dataExcel(item.criadoEm),
  })));
  adicionarFolha("Overrides", snapshot.dados.equipamentosOverride.map(item => ({
    ID: item.id,
    Equipamento: item.codigoEquipamento,
    Área: item.area,
    "Novo nome": item.novoNome,
    "Nova área": item.novaArea,
    "Nova periodicidade": item.novaPeriodicidade,
    Modelo: item.modelo,
    "N.º série": item.numeroSerie,
    "Plano intervenção": item.planoIntervencao,
    Inativo: item.inativo ? "Sim" : "Não",
    Eliminado: item.eliminado ? "Sim" : "Não",
    "Atualizado em": dataExcel(item.atualizadoEm),
  })));
  adicionarFolha("Utilizadores", snapshot.dados.validadores.map(item => ({
    ID: item.id,
    Nome: item.nome,
    Utilizador: item.nomeUtilizador,
    Ativo: item.ativo ? "Sim" : "Não",
    "Criado em": dataExcel(item.criadoEm),
  })));

  return XLSX.write(workbook, { bookType: "xlsx", type: "buffer" }) as Buffer;
}

export async function obterLinkBackupExcel(id: string) {
  const { backup, snapshot } = await prepararRestauroBackup(id);
  const conteudo = gerarExcelBackup(snapshot);
  const nomeFicheiro = backup.nomeFicheiro.replace(/\.json$/i, ".xlsx");
  const { url } = await storagePut(`manutencao/backups/exportacoes/${nomeFicheiro}`, conteudo, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
  return { backup, nomeFicheiro, url, tamanhoBytes: conteudo.byteLength };
}

export async function prepararRestauroBackup(id: string) {
  const { backup, url } = await obterLinkBackup(id);
  const resposta = await fetch(url);
  if (!resposta.ok) throw new Error("Não foi possível ler o ficheiro de backup.");
  const conteudo = await resposta.text();
  const checksum = createHash("sha256").update(conteudo).digest("hex");
  if (checksum !== backup.checksum) throw new Error("A verificação de integridade do backup falhou.");
  const snapshot = validarSnapshot(JSON.parse(conteudo));
  return { backup, snapshot };
}

export async function restaurarBackup(
  id: string,
  restauradoPor: string,
  criarCopiaPreRestauro: () => Promise<unknown> = () => criarBackup("antes_restauro"),
) {
  const { backup, snapshot } = await prepararRestauroBackup(id);

  // Garante uma cópia imediatamente anterior a qualquer operação destrutiva.
  await criarCopiaPreRestauro();
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");

  await db.transaction(async tx => {
    await tx.delete(anexos);
    await tx.delete(intervencoes);
    await tx.delete(areasCustom);
    await tx.delete(equipamentosCustom);
    await tx.delete(equipamentosOverride);

    if (snapshot.dados.intervencoes.length) await tx.insert(intervencoes).values(snapshot.dados.intervencoes);
    if (snapshot.dados.anexos.length) await tx.insert(anexos).values(snapshot.dados.anexos);
    if (snapshot.dados.areasCustom.length) await tx.insert(areasCustom).values(snapshot.dados.areasCustom);
    if (snapshot.dados.equipamentosCustom.length) await tx.insert(equipamentosCustom).values(snapshot.dados.equipamentosCustom);
    if (snapshot.dados.equipamentosOverride.length) await tx.insert(equipamentosOverride).values(snapshot.dados.equipamentosOverride);
  });

  await db.update(backupsAplicacao).set({ restauradoEm: Date.now(), restauradoPor }).where(eq(backupsAplicacao.id, id));
  return { ok: true, restauradoPor };
}

export async function associarAgendamentoSemanal(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");
  await obterOuCriarConfiguracao();
  await db
    .update(configuracaoBackups)
    .set({ scheduleCronTaskUid: taskUid, ativo: true, atualizadoEm: Date.now() })
    .where(eq(configuracaoBackups.id, BACKUP_CONFIG_ID));
}

async function registarExecucaoIgnorada(taskUid: string, motivo: string, backupId?: string) {
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");
  const agora = Date.now();
  await db.insert(execucoesBackups).values({
    id: nanoid(),
    scheduleCronTaskUid: taskUid,
    backupId,
    estado: "ignorado",
    iniciadoEm: agora,
    concluidoEm: agora,
    erro: motivo,
  });
}

export async function executarBackupSemanalAgendado(
  taskUid: string,
  criarSnapshot: typeof criarBackup = criarBackup,
) {
  const configuracao = await obterOuCriarConfiguracao();
  if (configuracao.scheduleCronTaskUid !== taskUid) {
    await registarExecucaoIgnorada(taskUid, "orphan");
    return { ok: true, skipped: "orphan" as const };
  }
  if (!configuracao.ativo) {
    await registarExecucaoIgnorada(taskUid, "disabled");
    return { ok: true, skipped: "disabled" as const };
  }
  const db = await getDb();
  if (!db) throw new Error("Base de dados indisponível.");
  const agora = Date.now();
  const data = new Date(agora);
  const inicioSemana = Date.UTC(data.getUTCFullYear(), data.getUTCMonth(), data.getUTCDate() - data.getUTCDay());

  // Evita duplicar cópias se a plataforma repetir a chamada após uma falha transitória.
  const backupDaSemana = await db
    .select()
    .from(backupsAplicacao)
    .where(and(eq(backupsAplicacao.origem, "automatico"), gte(backupsAplicacao.criadoEm, inicioSemana)))
    .orderBy(desc(backupsAplicacao.criadoEm))
    .limit(1);
  if (backupDaSemana[0]) {
    await registarExecucaoIgnorada(taskUid, "already-run", backupDaSemana[0].id);
    return { ok: true, skipped: "already-run" as const, backupId: backupDaSemana[0].id };
  }

  const execucaoId = nanoid();
  await db.insert(execucoesBackups).values({
    id: execucaoId,
    scheduleCronTaskUid: taskUid,
    estado: "iniciado",
    iniciadoEm: agora,
  });

  try {
    const backup = await criarSnapshot("automatico");
    await db
      .update(execucoesBackups)
      .set({ estado: "concluido", backupId: backup.id, concluidoEm: Date.now() })
      .where(eq(execucoesBackups.id, execucaoId));
    return { ok: true, backupId: backup.id };
  } catch (error) {
    await db
      .update(execucoesBackups)
      .set({ estado: "falhou", concluidoEm: Date.now(), erro: String(error).slice(0, 4000) })
      .where(eq(execucoesBackups.id, execucaoId));
    throw error;
  }
}
