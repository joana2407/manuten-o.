import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("Painéis de manutenção", () => {
  it("mantém o painel Preventivo na raiz e adiciona a rota Corretiva", async () => {
    const app = await readFile(resolve(process.cwd(), "client", "src", "App.tsx"), "utf-8");
    const preventiva = await readFile(resolve(process.cwd(), "client", "src", "pages", "Home.tsx"), "utf-8");
    const corretiva = await readFile(resolve(process.cwd(), "client", "src", "pages", "PainelCorretiva.tsx"), "utf-8");

    expect(app).toContain('<Route path={"/"}>{() => <AcessoGuard><Home /></AcessoGuard>}</Route>');
    expect(app).toContain('<Route path={"/corretiva"} component={PainelCorretiva} />');
    expect(app).toContain('<Route path={"/acesso"} component={AcessoAplicacao} />');
    expect(preventiva).toContain('Plano de Manutenção Preventiva');
    expect(corretiva).toContain('Manutenção Corretiva');
    expect(corretiva).toContain('Área em preparação');
    const acesso = await readFile(resolve(process.cwd(), "client", "src", "pages", "AcessoAplicacao.tsx"), "utf-8");
    expect(acesso).toContain('Acesso à aplicação');
    expect(acesso).toContain('sessionStorage.setItem(KEY');
  });

  it("disponibiliza navegação acessível entre os dois contextos", async () => {
    const [selector, sidebar] = await Promise.all([
      readFile(resolve(process.cwd(), "client", "src", "components", "PainelSelector.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "components", "Sidebar.tsx"), "utf-8"),
    ]);

    expect(selector).toContain('aria-label="Seleção de painel"');
    expect(selector).toContain("setLocation('/')");
    expect(selector).toContain("setLocation('/corretiva')");
    expect(selector).toContain('Preventiva');
    expect(selector).toContain('Corretiva');
    expect(sidebar).toContain('aria-label="Navegação de manutenção"');
    expect(sidebar).toContain('Manutenção Preventiva');
    expect(sidebar).toContain('Manutenção Corretiva');
    expect(sidebar).toContain("setLocation(destino)");
    expect(sidebar).toContain("aria-current={ativo ? 'page' : undefined}");
  });

  it("mantém o retorno ao painel Preventivo e o seletor utilizável em ecrãs estreitos", async () => {
    const corretiva = await readFile(resolve(process.cwd(), "client", "src", "pages", "PainelCorretiva.tsx"), "utf-8");
    const styles = await readFile(resolve(process.cwd(), "client", "src", "index.css"), "utf-8");

    expect(corretiva).toContain("setLocation('/')");
    expect(corretiva).toContain('<PainelSelector compacto />');
    expect(styles).toContain('.painel-selector { max-width: 100%; overflow-x: auto; }');
    expect(styles).toContain('.painel-selector button { white-space: nowrap; }');
  });

  it("mantém a gestão de PINs visível para o perfil de Qualidade", async () => {
    const [validacoes, preventiva, gestao] = await Promise.all([
      readFile(resolve(process.cwd(), "client", "src", "pages", "PainelValidacoes.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "Home.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "PainelGestaoValidadores.tsx"), "utf-8"),
    ]);

    expect(validacoes).toContain('sessao.podeGerirUtilizadores');
    expect(validacoes).toContain("setLocation('/gestao-validadores')");
    expect(preventiva).toContain('podeGerirUtilizadores');
    expect(preventiva).toContain('Gestão de PINs');
    expect(gestao).toContain('apenasGestaoPins');
    expect(gestao).toContain('sessaoGestao.podeGerirUtilizadores &&');
  });
});
