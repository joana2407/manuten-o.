import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({ getDb: vi.fn() }));

vi.mock("./db", () => ({ getDb: mocks.getDb }));
vi.mock("./storage", () => ({ storageGetSignedUrl: vi.fn(), storagePut: vi.fn() }));

import { executarBackupSemanalAgendado } from "./services/backups";

const configuracaoBase = {
  id: "backup-semanal-manutencao",
  scheduleCronTaskUid: "tarefa-semanal",
  ativo: true,
  retencaoSemanas: 12,
  atualizadoEm: Date.now(),
};

function dbParaConfiguracao(configuracao: typeof configuracaoBase, backupDaSemana?: { id: string }) {
  const valoresInseridos = vi.fn().mockResolvedValue(undefined);
  const inserir = vi.fn(() => ({ values: valoresInseridos }));
  const selecionarConfiguracao = {
    from: vi.fn(() => ({ where: vi.fn(() => ({ limit: vi.fn().mockResolvedValue([configuracao]) })) })),
  };
  const selecionarBackup = {
    from: vi.fn(() => ({
      where: vi.fn(() => ({ orderBy: vi.fn(() => ({ limit: vi.fn().mockResolvedValue(backupDaSemana ? [backupDaSemana] : []) })) })),
    })),
  };
  const select = vi.fn().mockReturnValueOnce(selecionarConfiguracao).mockReturnValueOnce(selecionarBackup);
  return { select, insert: inserir, valoresInseridos };
}

describe("auditoria do acionador semanal de backups", () => {
  beforeEach(() => vi.clearAllMocks());

  it("regista triggers órfãos como ignorados", async () => {
    const db = dbParaConfiguracao(configuracaoBase);
    mocks.getDb.mockResolvedValue(db);
    await expect(executarBackupSemanalAgendado("tarefa-desconhecida")).resolves.toMatchObject({ skipped: "orphan" });
    expect(db.valoresInseridos).toHaveBeenCalledWith(expect.objectContaining({ estado: "ignorado", erro: "orphan", scheduleCronTaskUid: "tarefa-desconhecida" }));
  });

  it("regista triggers suspensos como ignorados", async () => {
    const db = dbParaConfiguracao({ ...configuracaoBase, ativo: false });
    mocks.getDb.mockResolvedValue(db);
    await expect(executarBackupSemanalAgendado("tarefa-semanal")).resolves.toMatchObject({ skipped: "disabled" });
    expect(db.valoresInseridos).toHaveBeenCalledWith(expect.objectContaining({ estado: "ignorado", erro: "disabled" }));
  });

  it("regista repetições idempotentes como ignoradas", async () => {
    const db = dbParaConfiguracao(configuracaoBase, { id: "backup-ja-criado" });
    mocks.getDb.mockResolvedValue(db);
    await expect(executarBackupSemanalAgendado("tarefa-semanal")).resolves.toMatchObject({ skipped: "already-run", backupId: "backup-ja-criado" });
    expect(db.valoresInseridos).toHaveBeenCalledWith(expect.objectContaining({ estado: "ignorado", erro: "already-run", backupId: "backup-ja-criado" }));
  });
});
