import type { Request, Response } from "express";
import { associarAgendamentoSemanal, executarBackupSemanalAgendado } from "../services/backups";

const VERCEL_CRON_UID = "vercel-backup-semanal";

/** Callback semanal compatível com Vercel Cron. */
export async function executarBackupSemanal(req: Request, res: Response) {
  const segredo = process.env.CRON_SECRET;
  const autorizacao = req.headers.authorization;
  if (!segredo || autorizacao !== `Bearer ${segredo}`) {
    return res.status(401).json({ error: "cron-unauthorized" });
  }

  try {
    const taskUid = process.env.BACKUP_CRON_UID || VERCEL_CRON_UID;
    // Regista o UID na BD na primeira execução, permitindo manter a lógica
    // idempotente e a auditoria existente sem depender da Manus.
    await associarAgendamentoSemanal(taskUid);
    const resultado = await executarBackupSemanalAgendado(taskUid);
    return res.status(200).json(resultado);
  } catch (error) {
    return res.status(500).json({
      error: "backup-weekly-failed",
      detail: String(error),
      context: { path: req.path },
      timestamp: new Date().toISOString(),
    });
  }
}
