import { createHash } from "node:crypto";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  getDb: vi.fn(),
  storageGetSignedUrl: vi.fn(),
  storagePut: vi.fn(),
}));

vi.mock("./db", () => ({ getDb: mocks.getDb }));
vi.mock("./storage", () => ({
  storageGetSignedUrl: mocks.storageGetSignedUrl,
  storagePut: mocks.storagePut,
}));

import { anexos, areasCustom, equipamentosCustom, equipamentosOverride, intervencoes } from "../drizzle/schema";
import { restaurarBackup } from "./services/backups";

describe("restauro isolado de backups", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.clearAllMocks();
  });

  it("repõe cada coleção do snapshot numa transação isolada e cria cópia pré-restauro", async () => {
    const snapshot = {
      versao: 1,
      criadoEm: 1,
      dados: {
        intervencoes: [{ id: "intervencao-temporaria" }],
        anexos: [{ id: "anexo-temporario" }],
        areasCustom: [{ id: "area-temporaria" }],
        equipamentosCustom: [{ id: "equipamento-temporario" }],
        equipamentosOverride: [{ id: "override-temporario" }],
        validadores: [],
      },
    };
    const conteudo = JSON.stringify(snapshot);
    const backup = {
      id: "backup-temporario",
      estado: "concluido",
      expiraEm: Date.now() + 60_000,
      storageKey: "backup-temporario.json",
      checksum: createHash("sha256").update(conteudo).digest("hex"),
    };
    const tx = {
      delete: vi.fn().mockResolvedValue(undefined),
      insert: vi.fn(table => ({ values: vi.fn().mockResolvedValue(table) })),
    };
    const db = {
      select: vi.fn(() => ({ from: vi.fn(() => ({ where: vi.fn(() => ({ limit: vi.fn().mockResolvedValue([backup]) })) })) })),
      transaction: vi.fn(async callback => callback(tx)),
      update: vi.fn(() => ({ set: vi.fn(() => ({ where: vi.fn().mockResolvedValue(undefined) })) })),
    };
    const criarCopiaPreRestauro = vi.fn().mockResolvedValue({ id: "pre-restauro" });

    mocks.getDb.mockResolvedValue(db);
    mocks.storageGetSignedUrl.mockResolvedValue("https://storage.test/backup-temporario");
    vi.stubGlobal("fetch", vi.fn().mockResolvedValue({ ok: true, text: async () => conteudo }));

    await expect(restaurarBackup(backup.id, "teste-isolado", criarCopiaPreRestauro)).resolves.toEqual({ ok: true, restauradoPor: "teste-isolado" });

    expect(criarCopiaPreRestauro).toHaveBeenCalledOnce();
    expect(tx.delete).toHaveBeenCalledTimes(5);
    expect(tx.insert).toHaveBeenNthCalledWith(1, intervencoes);
    expect(tx.insert).toHaveBeenNthCalledWith(2, anexos);
    expect(tx.insert).toHaveBeenNthCalledWith(3, areasCustom);
    expect(tx.insert).toHaveBeenNthCalledWith(4, equipamentosCustom);
    expect(tx.insert).toHaveBeenNthCalledWith(5, equipamentosOverride);
    expect(db.update).toHaveBeenCalledOnce();
  });
});
