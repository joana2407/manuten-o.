import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  autenticarValidador: vi.fn(),
  listarBackupsDisponiveis: vi.fn(),
  obterLinkBackupExcel: vi.fn(),
  criarBackup: vi.fn(),
  restaurarBackup: vi.fn(),
}));

vi.mock("./db", () => ({ autenticarValidador: mocks.autenticarValidador }));
vi.mock("./services/backups", () => ({
  listarBackupsDisponiveis: mocks.listarBackupsDisponiveis,
  obterLinkBackupExcel: mocks.obterLinkBackupExcel,
  criarBackup: mocks.criarBackup,
  restaurarBackup: mocks.restaurarBackup,
}));

import { backupsRouter } from "./routers/backups";

const credenciais = { nomeUtilizador: "tecnico", pin: "1234" };
const perfilConsulta = { id: "1", nome: "Técnico", podeGerir: false };
const perfilGestao = { id: "2", nome: "Gestão", podeGerir: true };

describe("router de backups", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mocks.autenticarValidador.mockResolvedValue(perfilConsulta);
  });

  it("permite a qualquer utilizador autenticado consultar e descarregar backups", async () => {
    const caller = backupsRouter.createCaller({} as any);
    mocks.listarBackupsDisponiveis.mockResolvedValue([{ id: "backup-1" }]);
    mocks.obterLinkBackupExcel.mockResolvedValue({ backup: { id: "backup-1", nomeFicheiro: "backup.json" }, nomeFicheiro: "backup.xlsx", tamanhoBytes: 1000, url: "https://example.test/backup" });

    await expect(caller.listar(credenciais)).resolves.toEqual([{ id: "backup-1" }]);
    await expect(caller.obterDownloadExcel({ ...credenciais, id: "backup-1" })).resolves.toEqual({ id: "backup-1", nomeFicheiro: "backup.xlsx", tamanhoBytes: 1000, formato: "xlsx", url: "https://example.test/backup" });
  });

  it("rejeita consulta sem sessão válida", async () => {
    const caller = backupsRouter.createCaller({} as any);
    mocks.autenticarValidador.mockResolvedValue(null);
    await expect(caller.listar(credenciais)).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("reserva a criação e a recuperação de backups para Gestão", async () => {
    const caller = backupsRouter.createCaller({} as any);
    await expect(caller.criarAgora(credenciais)).rejects.toMatchObject({ code: "FORBIDDEN" });
    await expect(caller.restaurar({ ...credenciais, id: "backup-1", confirmacao: "RESTAURAR" })).rejects.toMatchObject({ code: "FORBIDDEN" });
  });

  it("permite que Gestão crie e recupere com confirmação explícita", async () => {
    const caller = backupsRouter.createCaller({} as any);
    mocks.autenticarValidador.mockResolvedValue(perfilGestao);
    mocks.criarBackup.mockResolvedValue({ id: "backup-2" });
    mocks.restaurarBackup.mockResolvedValue({ ok: true, restauradoPor: "Gestão" });

    await expect(caller.criarAgora(credenciais)).resolves.toEqual({ id: "backup-2" });
    await expect(caller.restaurar({ ...credenciais, id: "backup-1", confirmacao: "RESTAURAR" })).resolves.toEqual({ ok: true, restauradoPor: "Gestão" });
    expect(mocks.restaurarBackup).toHaveBeenCalledWith("backup-1", "Gestão");
  });
});
