import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// TODO: add feature queries here as your schema grows.

// ─── Intervenções ────────────────────────────────────────────────────────────

import { intervencoes, anexos, InsertIntervencao, InsertAnexo } from "../drizzle/schema";
import { and } from "drizzle-orm";

export async function criarIntervencao(data: InsertIntervencao): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(intervencoes).values(data);
}

export async function listarIntervencoesPorEquipamento(
  codigoEquipamento: string,
  area: string,
): Promise<typeof intervencoes.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(intervencoes)
    .where(
      and(
        eq(intervencoes.codigoEquipamento, codigoEquipamento),
        eq(intervencoes.area, area),
      ),
    )
    .orderBy(intervencoes.criadoEm);
}

export async function listarTodasIntervencoes(): Promise<typeof intervencoes.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(intervencoes).orderBy(intervencoes.criadoEm);
}

export async function removerIntervencao(id: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(intervencoes).where(eq(intervencoes.id, id));
  // Remover anexos associados
  await db.delete(anexos).where(eq(anexos.intervencaoId, id));
}

export async function editarIntervencao(
  id: string,
  data: Partial<Pick<InsertIntervencao, 'intervencaoRealizada' | 'materialGasto' | 'responsavelValidacao' | 'validadoPor' | 'validadoEm'>>,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(intervencoes).set(data).where(eq(intervencoes.id, id));
}

export async function validarIntervencao(
  id: string,
  validadoPor: string,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(intervencoes)
    .set({ validadoPor, validadoEm: Date.now() })
    .where(eq(intervencoes.id, id));
}

export async function listarIntervencoesPorValidar(): Promise<typeof intervencoes.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  // Intervenções sem validação (validadoEm é null)
  const todas = await db.select().from(intervencoes).orderBy(intervencoes.criadoEm);
  return todas.filter(i => !i.validadoEm);
}

// ─── Anexos ──────────────────────────────────────────────────────────────────

export async function criarAnexo(data: InsertAnexo): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(anexos).values(data);
}

export async function listarAnexosPorIntervencao(
  intervencaoId: string,
): Promise<typeof anexos.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(anexos).where(eq(anexos.intervencaoId, intervencaoId));
}

export async function listarAnexosPorIntervencoes(
  intervencaoIds: string[],
): Promise<typeof anexos.$inferSelect[]> {
  if (intervencaoIds.length === 0) return [];
  const db = await getDb();
  if (!db) return [];
  // Fetch all and filter — simple approach for small datasets
  const all = await db.select().from(anexos);
  return all.filter(a => intervencaoIds.includes(a.intervencaoId));
}

// ─── Áreas Custom ─────────────────────────────────────────────────────────────

import {
  areasCustom, equipamentosCustom, equipamentosOverride, validadoresAcesso,
  InsertAreaCustom, InsertEquipamentoCustom, InsertEquipamentoOverride,
} from "../drizzle/schema";
import { obterPerfilPorNome } from "../shared/access";

export async function upsertAreaBase(nome: string, fabrica: string): Promise<typeof areasCustom.$inferSelect> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Verificar se já existe
  const existing = await db.select().from(areasCustom).where(eq(areasCustom.nome, nome));
  if (existing.length > 0) {
    return existing[0];
  }
  // Criar registo base
  const { nanoid } = await import('nanoid');
  const id = nanoid();
  await db.insert(areasCustom).values({
    id,
    nome,
    fabrica,
    inativo: false,
    isBase: true,
    criadoEm: Date.now(),
  });
  const created = await db.select().from(areasCustom).where(eq(areasCustom.id, id));
  return created[0];
}

export async function listarAreasCustom(): Promise<typeof areasCustom.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  // Excluir áreas marcadas como eliminadas
  return db.select().from(areasCustom)
    .where(eq(areasCustom.eliminado, false))
    .orderBy(areasCustom.criadoEm);
}

export async function criarAreaCustom(data: InsertAreaCustom): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(areasCustom).values(data);
}

export async function editarAreaCustom(
  id: string,
  data: Partial<Pick<InsertAreaCustom, 'nome' | 'descricao' | 'fabrica'>>
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(areasCustom).set({ ...data, atualizadoEm: Date.now() }).where(eq(areasCustom.id, id));
}

export async function eliminarAreaCustom(id: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Marcar como eliminada em vez de apagar fisicamente (preserva histórico)
  await db.update(areasCustom).set({ eliminado: true, atualizadoEm: Date.now() }).where(eq(areasCustom.id, id));
}

export async function toggleInativoAreaCustom(id: string, inativo: boolean): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(areasCustom).set({ inativo, atualizadoEm: Date.now() }).where(eq(areasCustom.id, id));
}

// ─── Equipamentos Custom ──────────────────────────────────────────────────────

export async function listarEquipamentosCustom(): Promise<typeof equipamentosCustom.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(equipamentosCustom).orderBy(equipamentosCustom.criadoEm);
}

export async function criarEquipamentoCustom(data: InsertEquipamentoCustom): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(equipamentosCustom).values(data);
}

export async function editarEquipamentoCustom(
  id: string,
  data: Partial<Pick<InsertEquipamentoCustom, 'codigo' | 'equipamento' | 'area' | 'periodicidade' | 'estado' | 'modelo' | 'numeroSerie' | 'planoIntervencao'>>
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(equipamentosCustom).set({ ...data, atualizadoEm: Date.now() }).where(eq(equipamentosCustom.id, id));
}

export async function eliminarEquipamentoCustom(id: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(equipamentosCustom).where(eq(equipamentosCustom.id, id));
}

export async function toggleInativoEquipamentoCustom(id: string, inativo: boolean): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(equipamentosCustom).set({ inativo, atualizadoEm: Date.now() }).where(eq(equipamentosCustom.id, id));
}

// ─── Overrides de Estado ──────────────────────────────────────────────────────

export async function listarOverrides(): Promise<typeof equipamentosOverride.$inferSelect[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(equipamentosOverride);
}

export async function upsertEquipamentoOverrideEdicao(
  codigoEquipamento: string,
  area: string,
  campos: { novoNome?: string; novaArea?: string; novaPeriodicidade?: string; modelo?: string; numeroSerie?: string; planoIntervencao?: string },
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { nanoid } = await import("nanoid");
  await db
    .insert(equipamentosOverride)
    .values({
      id: nanoid(),
      codigoEquipamento,
      area,
      inativo: false,
      novoNome: campos.novoNome ?? null,
      novaArea: campos.novaArea ?? null,
      novaPeriodicidade: campos.novaPeriodicidade ?? null,
      modelo: campos.modelo ?? null,
      numeroSerie: campos.numeroSerie ?? null,
      planoIntervencao: campos.planoIntervencao ?? null,
      atualizadoEm: Date.now(),
    })
    .onDuplicateKeyUpdate({
      set: {
        novoNome: campos.novoNome ?? null,
        novaArea: campos.novaArea ?? null,
        novaPeriodicidade: campos.novaPeriodicidade ?? null,
        modelo: campos.modelo ?? null,
        numeroSerie: campos.numeroSerie ?? null,
        planoIntervencao: campos.planoIntervencao ?? null,
        atualizadoEm: Date.now(),
      },
    });
}

export async function upsertOverride(
  codigoEquipamento: string,
  area: string,
  inativo: boolean,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { nanoid } = await import("nanoid");
  await db
    .insert(equipamentosOverride)
    .values({
      id: nanoid(),
      codigoEquipamento,
      area,
      inativo,
      atualizadoEm: Date.now(),
    })
    .onDuplicateKeyUpdate({ set: { inativo, atualizadoEm: Date.now() } });
}

// Marcar equipamento do JSON base como eliminado (oculto do dashboard)
export async function eliminarEquipamentoBase(
  codigoEquipamento: string,
  area: string,
): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const { nanoid } = await import("nanoid");
  await db
    .insert(equipamentosOverride)
    .values({
      id: nanoid(),
      codigoEquipamento,
      area,
      inativo: true,
      eliminado: true,
      atualizadoEm: Date.now(),
    })
    .onDuplicateKeyUpdate({ set: { eliminado: true, inativo: true, atualizadoEm: Date.now() } });
}

// ─── Validadores de Acesso ────────────────────────────────────────────────────

/**
 * Autentica um validador pelo PIN fornecido.
 * Retorna o nome do validador se o PIN for correto, ou null caso contrário.
 */
export async function autenticarValidador(nomeUtilizador: string, pin: string): Promise<({ id: string; nome: string; nomeUtilizador: string } & ReturnType<typeof obterPerfilPorNome>) | null> {
  const db = await getDb();
  if (!db) return null;
  const bcrypt = await import("bcryptjs");
  const utilizador = nomeUtilizador.trim().toLocaleLowerCase("pt-PT");
  const lista = await db.select().from(validadoresAcesso).where(eq(validadoresAcesso.ativo, true));
  const v = lista.find(item => item.nomeUtilizador?.toLocaleLowerCase("pt-PT") === utilizador);
  if (!v || !v.nomeUtilizador) return null;
  const ok = await bcrypt.compare(pin, v.pin);
  if (ok) return { id: v.id, nome: v.nome, nomeUtilizador: v.nomeUtilizador, ...obterPerfilPorNome(v.nome) };
  return null;
}

/**
 * Lista todos os validadores ativos (sem expor o PIN).
 */
export async function listarValidadores(): Promise<({ id: string; nome: string; nomeUtilizador: string | null } & ReturnType<typeof obterPerfilPorNome>)[]> {
  const db = await getDb();
  if (!db) return [];
  const lista = await db.select({
    id: validadoresAcesso.id,
    nome: validadoresAcesso.nome,
    nomeUtilizador: validadoresAcesso.nomeUtilizador,
  }).from(validadoresAcesso).where(eq(validadoresAcesso.ativo, true));
  return lista.map(v => ({ ...v, ...obterPerfilPorNome(v.nome) }));
}

/**
 * Criar um novo validador com PIN hasheado.
 */
export async function criarValidador(nome: string, nomeUtilizador: string, pin: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const bcrypt = await import("bcryptjs");
  const { nanoid } = await import("nanoid");
  const hash = await bcrypt.hash(pin, 12);
  await db.insert(validadoresAcesso).values({
    id: nanoid(),
    nome,
    nomeUtilizador: nomeUtilizador.trim().toLocaleLowerCase("pt-PT"),
    pin: hash,
    ativo: true,
    criadoEm: Date.now(),
  });
}

/**
 * Alterar o PIN de um validador.
 */
export async function alterarPinValidador(id: string, novoPin: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const bcrypt = await import("bcryptjs");
  const hash = await bcrypt.hash(novoPin, 12);
  await db.update(validadoresAcesso).set({ pin: hash }).where(eq(validadoresAcesso.id, id));
}

/**
 * Ativar ou desativar um validador.
 */
export async function toggleAtivoValidador(id: string, ativo: boolean): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(validadoresAcesso).set({ ativo }).where(eq(validadoresAcesso.id, id));
}

/**
 * Eliminar um validador.
 */
export async function eliminarValidador(id: string): Promise<void> {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(validadoresAcesso).where(eq(validadoresAcesso.id, id));
}

/**
 * Listar todos os validadores (ativos e inativos), sem expor o PIN.
 */
export async function listarTodosValidadores(): Promise<{ id: string; nome: string; nomeUtilizador: string | null; ativo: boolean; criadoEm: number }[]> {
  const db = await getDb();
  if (!db) return [];
  return db.select({
    id: validadoresAcesso.id,
    nome: validadoresAcesso.nome,
    nomeUtilizador: validadoresAcesso.nomeUtilizador,
    ativo: validadoresAcesso.ativo,
    criadoEm: validadoresAcesso.criadoEm,
  }).from(validadoresAcesso).orderBy(validadoresAcesso.criadoEm);
}
