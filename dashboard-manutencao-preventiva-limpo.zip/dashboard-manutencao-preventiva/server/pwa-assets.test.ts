import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

const publicDir = resolve(process.cwd(), "client", "public");

describe("PWA instalável", () => {
  it("expõe um manifesto standalone com identidade e ícone maskable", async () => {
    const manifestRaw = await readFile(resolve(publicDir, "manifest.webmanifest"), "utf-8");
    const manifest = JSON.parse(manifestRaw) as {
      name: string;
      short_name: string;
      display: string;
      start_url: string;
      theme_color: string;
      icons: Array<{ src: string; purpose?: string }>;
    };

    expect(manifest.name).toBe("Manutenção Preventiva A&S");
    expect(manifest.short_name).toBe("Manutenção A&S");
    expect(manifest.display).toBe("standalone");
    expect(manifest.start_url).toBe("/");
    expect(manifest.theme_color).toBe("#151619");
    expect(manifest.icons).toContainEqual(
      expect.objectContaining({ src: "/pwa-icon.svg", purpose: "any maskable" }),
    );
  });

  it("mantém os dados essenciais no cache e não coloca chamadas tRPC no cache offline", async () => {
    const serviceWorker = await readFile(resolve(publicDir, "sw.js"), "utf-8");

    expect(serviceWorker).toContain('"/manutencao.json"');
    expect(serviceWorker).toContain('"/manifest.webmanifest"');
    expect(serviceWorker).toContain('url.pathname.startsWith("/api/")');
    expect(serviceWorker).toContain('caches.match("/")');
  });

  it("liga o manifesto e regista o service worker apenas na build de produção", async () => {
    const [html, main] = await Promise.all([
      readFile(resolve(process.cwd(), "client", "index.html"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "main.tsx"), "utf-8"),
    ]);

    expect(html).toContain('rel="manifest" href="/manifest.webmanifest"');
    expect(html).toContain('name="apple-mobile-web-app-capable" content="yes"');
    expect(main).toContain('"serviceWorker" in navigator');
    expect(main).toContain('import.meta.env.PROD');
    expect(main).toContain('navigator.serviceWorker.register("/sw.js")');
  });

  it("mantém versões móveis dos fluxos de filtros, ficha, validações e tabela", async () => {
    const [home, table, ficha, validacoes, styles] = await Promise.all([
      readFile(resolve(process.cwd(), "client", "src", "pages", "Home.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "components", "TabelaEquipamentos.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "FichaEquipamento.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "PainelValidacoes.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "index.css"), "utf-8"),
    ]);

    expect(home).toContain('window.innerWidth < 1024');
    expect(home).toContain('Filtros');
    expect(table).toContain('lg:hidden p-3 space-y-2');
    expect(table).toContain('mobile-${e.codigo}-${e.area}-${i}');
    expect(ficha).toContain('ficha-header');
    expect(ficha).toContain('ficha-intervencao-header');
    expect(validacoes).toContain('validacoes-header');
    expect(validacoes).toContain('validacao-card-header');
    expect(styles).toContain('@media (max-width: 1023px)');
    expect(styles).toContain('.dashboard-sidebar[data-collapsed="true"]');
  });
});
