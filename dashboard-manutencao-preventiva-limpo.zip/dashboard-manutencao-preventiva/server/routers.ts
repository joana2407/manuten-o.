import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { intervencoesRouter } from "./routers/intervencoes";
import { gestaoRouter } from "./routers/gestao";
import { backupsRouter } from "./routers/backups";

export const appRouter = router({
  system: systemRouter,
  intervencoes: intervencoesRouter,
  gestao: gestaoRouter,
  backups: backupsRouter,
  auth: router({
    me: publicProcedure.query(() => null),
    logout: publicProcedure.mutation(() => ({ success: true } as const)),
  }),
});

export type AppRouter = typeof appRouter;
