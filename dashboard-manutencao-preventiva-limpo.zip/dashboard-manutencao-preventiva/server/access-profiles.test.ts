import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import { describe, expect, it, vi } from "vitest";
import { obterPerfilPorNome, perfisBase } from "../shared/access";
import { filtrarUtilizadoresAcesso } from "../client/src/components/SeletorUtilizadorAcesso";

import { appRouter } from "./routers";
import * as db from "./db";

describe("Perfis de acesso da manutenção", () => {
  it("define os quatro acessos base com os PINs solicitados", () => {
    expect(perfisBase()).toEqual([
      { nome: "Alfredo Silva", perfil: "tecnico" },
      { nome: "Marco Monteiro", perfil: "manutencao" },
      { nome: "Joana Pina", perfil: "qualidade" },
      { nome: "Gestão", perfil: "gestao" },
    ]);
  });

  it("mantém registo, validação e gestão como permissões distintas", () => {
    expect(obterPerfilPorNome("Alfredo Silva")).toMatchObject({ funcao: "Téc. Manutenção", podeRegistar: true, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true });
    expect(obterPerfilPorNome("Marco Monteiro")).toMatchObject({ funcao: "Resp. Manutenção", podeRegistar: true, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true });
    expect(obterPerfilPorNome("Joana Pina")).toMatchObject({ funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false, podeGerirEquipamentos: true, podeGerirPins: true, podeGerirUtilizadores: true });
    expect(obterPerfilPorNome("Gestão")).toMatchObject({ funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true, podeGerirEquipamentos: true, podeGerirPins: true, podeGerirUtilizadores: true });
  });

  it("filtra no seletor Gestão, mantendo todos os utilizadores ativos na validação", () => {
    const utilizadores = [
      { id: "tecnico", nomeUtilizador: "alfredo.silva", podeGerir: false, podeGerirPins: false, podeGerirUtilizadores: false, podeValidar: false },
      { id: "qualidade", nomeUtilizador: "joana.pina", podeGerir: false, podeGerirPins: true, podeGerirUtilizadores: true, podeValidar: true },
      { id: "gestao", nomeUtilizador: "gestao", podeGerir: true, podeGerirPins: true, podeGerirUtilizadores: true, podeValidar: true },
      { id: "incompleto", nomeUtilizador: null, podeGerir: true, podeGerirPins: true, podeGerirUtilizadores: true, podeValidar: true },
    ];

    expect(filtrarUtilizadoresAcesso(utilizadores, false, true).map(item => item.id)).toEqual(["tecnico", "qualidade", "gestao"]);
    expect(filtrarUtilizadoresAcesso(utilizadores, true, false).map(item => item.id)).toEqual(["gestao"]);
    expect(filtrarUtilizadoresAcesso(utilizadores, false, false).map(item => item.id)).toEqual(["tecnico", "qualidade", "gestao"]);
    expect(filtrarUtilizadoresAcesso(utilizadores, false, false, true).map(item => item.id)).toEqual(["qualidade", "gestao"]);
  });

  it("exercita os callers tRPC para autenticação e rejeição por perfil", async () => {
    const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
    const autenticarMock = vi.spyOn(db, "autenticarValidador");
    autenticarMock.mockResolvedValueOnce({ id: "gestao-id", nome: "Gestão", nomeUtilizador: "gestao", perfil: "gestao", funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true } as any);
    await expect(caller.intervencoes.autenticarValidador({ nomeUtilizador: "gestao", pin: "pin-nao-exposto" })).resolves.toMatchObject({ nome: "Gestão", nomeUtilizador: "gestao", podeGerir: true });

    autenticarMock.mockResolvedValueOnce({ id: "tecnico-id", nome: "Alfredo Silva", perfil: "tecnico", funcao: "Téc. Manutenção", podeRegistar: true, podeValidar: true, podeGerir: false } as any);
    const validarMock = vi.spyOn(db, "validarIntervencao").mockResolvedValueOnce(undefined as any);
    await expect(caller.intervencoes.validar({ id: "intervencao-1", validadoPor: "Alfredo Silva", nomeUtilizador: "alfredo.silva", codigoAcesso: "pin-nao-exposto" })).resolves.toMatchObject({ ok: true });
    validarMock.mockRestore();

    autenticarMock.mockResolvedValueOnce({ id: "qualidade-id", nome: "Joana Pina", perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false } as any);
    await expect(caller.intervencoes.validar({ id: "intervencao-1", validadoPor: "Joana Pina", nomeUtilizador: "joana.pina", codigoAcesso: "pin-nao-exposto" })).resolves.toMatchObject({ ok: true });

    const validarSessaoMock = vi.spyOn(db, "validarIntervencao").mockResolvedValueOnce(undefined as any);
    autenticarMock.mockResolvedValueOnce({ id: "id-da-base-de-dados", nome: "Joana Pina", nomeUtilizador: "joana.pina", perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false } as any);
    await expect(caller.intervencoes.validarComSessao({ id: "intervencao-1", validadoPor: "Joana Pina", validadorId: "mock-3", nomeUtilizador: "joana.pina", pin: "pin-nao-exposto" })).resolves.toMatchObject({ ok: true });
    validarSessaoMock.mockRestore();

    autenticarMock.mockResolvedValueOnce({ id: "tecnico-id", nome: "Alfredo Silva", perfil: "tecnico", funcao: "Téc. Manutenção", podeRegistar: true, podeValidar: false, podeGerir: false } as any);
    await expect(caller.intervencoes.criarValidador({ nomeUtilizador: "alfredo.silva", codigoAcesso: "pin-nao-exposto", nome: "Novo utilizador", nomeUtilizadorNovo: "novo.utilizador", pin: "pin-nao-exposto" })).rejects.toMatchObject({ code: "FORBIDDEN" });

    autenticarMock.mockResolvedValueOnce({ id: "gestao-id", nome: "Gestão", perfil: "gestao", funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true, podeGerirUtilizadores: true } as any);
    const criarMock = vi.spyOn(db, "criarValidador").mockResolvedValueOnce(undefined as any);
    await expect(caller.intervencoes.criarValidador({ nomeUtilizador: "gestao", codigoAcesso: "pin-nao-exposto", nome: "Novo utilizador", nomeUtilizadorNovo: "novo.utilizador", pin: "pin-nao-exposto" })).resolves.toMatchObject({ ok: true });
    criarMock.mockRestore();
  });

  it("mantém as verificações de autorização no servidor e no registo móvel", async () => {
    const router = await readFile(resolve(process.cwd(), "server", "routers", "intervencoes.ts"), "utf-8");
    const modal = await readFile(resolve(process.cwd(), "client", "src", "components", "ModalRealizacao.tsx"), "utf-8");

    expect(router).not.toContain("if (!resultado.podeValidar)");
    expect(router).toContain("if (!resultado || !resultado.podeGerir)");
    expect(modal).toContain("sessao.podeRegistar");
    expect(router).not.toContain('0206');
    expect(router).not.toContain('0205');
    expect(router).not.toContain('1709');
    expect(router).not.toContain('2403');
  });

  it("mantém a seleção visual de utilizador e o PIN nos acessos global, validação e gestão", async () => {
    const [acesso, validacoes, gestao, modalValidacao, seletor] = await Promise.all([
      readFile(resolve(process.cwd(), "client", "src", "pages", "AcessoAplicacao.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "PainelValidacoes.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "pages", "PainelGestaoValidadores.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "components", "ModalValidacao.tsx"), "utf-8"),
      readFile(resolve(process.cwd(), "client", "src", "components", "SeletorUtilizadorAcesso.tsx"), "utf-8"),
    ]);

    expect(acesso).toContain('SeletorUtilizadorAcesso');
    expect(validacoes).toContain('SeletorUtilizadorAcesso');
    expect(gestao).toContain('apenasGestaoPins');
    expect(modalValidacao).toContain('SeletorUtilizadorAcesso');
    expect(modalValidacao).toContain('apenasValidacao');
    expect(seletor).toContain('listarUtilizadoresLocais');
    expect(seletor).toContain('useState(() => listarUtilizadoresLocais');
    expect(seletor).toContain('visiveis.length === 0');
  });

  it("lista para o seletor apenas identificadores públicos de utilizadores ativos", async () => {
    const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
    const listarMock = vi.spyOn(db, "listarValidadores").mockResolvedValueOnce([
      { id: "joana-id", nome: "Joana Pina", nomeUtilizador: "joana.pina", perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false },
    ] as any);

    await expect(caller.intervencoes.listarValidadores()).resolves.toEqual([
      expect.objectContaining({ id: "joana-id", nome: "Joana Pina", nomeUtilizador: "joana.pina" }),
    ]);
    listarMock.mockRestore();
  });

  it("cria contratos de sessão válidos para os logins de validações e gestão", async () => {
    const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
    const autenticarMock = vi.spyOn(db, "autenticarValidador");

    autenticarMock.mockResolvedValueOnce({ id: "qualidade-id", nome: "Joana Pina", nomeUtilizador: "joana.pina", perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false, podeGerirPins: true, podeGerirUtilizadores: true } as any);
    const sessaoValidacoes = await caller.intervencoes.autenticarValidador({ nomeUtilizador: "joana.pina", pin: "pin-nao-exposto" });
    expect(sessaoValidacoes).toMatchObject({ nomeUtilizador: "joana.pina", podeValidar: true, podeGerir: false, podeGerirUtilizadores: true });

    autenticarMock.mockResolvedValueOnce({ id: "gestao-id", nome: "Gestão", nomeUtilizador: "gestao", perfil: "gestao", funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true, podeGerirPins: true, podeGerirUtilizadores: true } as any);
    const sessaoGestao = await caller.intervencoes.autenticarValidador({ nomeUtilizador: "gestao", pin: "pin-nao-exposto" });
    expect(sessaoGestao).toMatchObject({ nomeUtilizador: "gestao", podeValidar: true, podeGerir: true });

    const listarGestaoMock = vi.spyOn(db, "listarTodosValidadores").mockResolvedValueOnce([]);
    autenticarMock.mockResolvedValueOnce({ id: "gestao-id", nome: "Gestão", nomeUtilizador: "gestao", perfil: "gestao", funcao: "Gestão", podeRegistar: true, podeValidar: true, podeGerir: true, podeGerirPins: true, podeGerirUtilizadores: true } as any);
    await expect(caller.intervencoes.listarTodosValidadores({ nomeUtilizador: "gestao", codigoAcesso: "pin-nao-exposto" })).resolves.toEqual([]);

    autenticarMock.mockResolvedValueOnce(null);
    await expect(caller.intervencoes.listarTodosValidadores({ nomeUtilizador: "gestao", codigoAcesso: "pin-invalido" })).rejects.toMatchObject({ code: "FORBIDDEN" });
    listarGestaoMock.mockRestore();
  });

  it("permite à Qualidade gerir integralmente os utilizadores", async () => {
    const caller = appRouter.createCaller({ req: {} as any, res: {} as any, user: null });
    const autenticarMock = vi.spyOn(db, "autenticarValidador");
    const qualidade = { id: "qualidade-id", nome: "Joana Pina", nomeUtilizador: "joana.pina", perfil: "qualidade", funcao: "Resp. Qualidade", podeRegistar: false, podeValidar: true, podeGerir: false, podeGerirPins: true, podeGerirUtilizadores: true } as any;
    const listarMock = vi.spyOn(db, "listarTodosValidadores").mockResolvedValueOnce([]);
    const alterarMock = vi.spyOn(db, "alterarPinValidador").mockResolvedValueOnce(undefined as any);

    autenticarMock.mockResolvedValueOnce(qualidade);
    await expect(caller.intervencoes.listarTodosValidadores({ nomeUtilizador: "joana.pina", codigoAcesso: "pin-nao-exposto" })).resolves.toEqual([]);
    autenticarMock.mockResolvedValueOnce(qualidade);
    await expect(caller.intervencoes.alterarPinValidador({ nomeUtilizador: "joana.pina", codigoAcesso: "pin-nao-exposto", id: "tecnico-id", novoPin: "novo-pin" })).resolves.toMatchObject({ ok: true });
    expect(alterarMock).toHaveBeenCalledWith("tecnico-id", "novo-pin");
    const criarMock = vi.spyOn(db, "criarValidador").mockResolvedValueOnce(undefined as any);
    autenticarMock.mockResolvedValueOnce(qualidade);
    await expect(caller.intervencoes.criarValidador({ nomeUtilizador: "joana.pina", codigoAcesso: "pin-nao-exposto", nome: "Novo utilizador", nomeUtilizadorNovo: "novo.utilizador", pin: "novo-pin" })).resolves.toMatchObject({ ok: true });
    expect(criarMock).toHaveBeenCalledWith("Novo utilizador", "novo.utilizador", "novo-pin");
    criarMock.mockRestore();

    listarMock.mockRestore();
    alterarMock.mockRestore();
    autenticarMock.mockRestore();
  });
});
