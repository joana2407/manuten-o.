# Evidência de validação manual

Em 25/08/2026, o preview foi aberto na raiz do dashboard, o seletor navegou de Manutenção Preventiva para `/corretiva` e regressou para `/`. O painel Corretiva apresentou o shell com as secções de avarias, ordens de trabalho, peças/custos e histórico corretivo.

O painel `/acesso` foi validado com o PIN de Gestão fornecido pela utilizadora. A resposta identificou o perfil `Gestão`, mostrou a função e as três permissões permitidas (registo, validação e gestão). De seguida, o botão `Terminar sessão` removeu a sessão e devolveu o formulário de PIN.

A apresentação móvel foi capturada anteriormente em 390x844 para `/`, `/corretiva` e `/acesso`. Os testes Vitest cobrem as rotas, o seletor, a sequência de retorno, a regra responsiva do seletor e a matriz de permissões.

Na validação posterior da autenticação por nome de utilizador, o acesso global foi concluído com o utilizador `gestao` e o respetivo PIN. O mesmo fluxo foi repetido com sucesso em `/validacoes` após terminar a sessão anterior, e em `/gestao-validadores`. A gestão confirmou a apresentação dos nove nomes de utilizador atribuídos, sem expor PINs.

O acesso foi posteriormente simplificado para seleção visual do utilizador e introdução exclusiva de PIN. A lista de utilizadores ativos foi apresentada no painel de acesso e o perfil Gestão foi selecionado, autenticado e confirmado com sucesso apenas através do respetivo PIN. A apresentação móvel foi também verificada nos acessos global, de validações e de gestão.

Após reforçar os estados do seletor, foram testados em browser os dois fluxos adicionais. Em `/validacoes`, o perfil Gestão foi escolhido na grelha e a sessão foi aberta apenas com o PIN. Em `/gestao-validadores`, a grelha mostrou exclusivamente o perfil Gestão e o acesso foi concluído com a sua seleção e PIN. O modal de validação passou a restringir a grelha a perfis com permissão de validar; a verificação funcional da chamada permanece coberta pelo teste de autorização server-side.

Foram introduzidos atalhos na barra lateral do painel Preventivo para Manutenção Preventiva e Manutenção Corretiva. A navegação real foi confirmada no browser: o atalho lateral Corretiva abriu `/corretiva` e o seletor do painel Corretivo devolveu corretamente a `/`. Em ecrã estreito, a barra lateral mantém os mesmos atalhos quando é aberta pelo controlo de filtros do dashboard.

No painel de backups, com o perfil Gestão autenticado, foi criada uma cópia inicial privada. A cópia foi apresentada na lista com data, tamanho e prazo de retenção e a ação de descarregar foi validada através da transferência direta do ficheiro, sem abrir o conteúdo JSON no painel.

No painel de gestão de validadores, a Responsável de Qualidade (Joana Pina) foi autenticada através do seletor de utilizador e do respetivo PIN. A lista apresentou exclusivamente a ação de alteração de PIN para todos os utilizadores, sem mostrar criação, ativação, desativação ou eliminação de utilizadores.

Após iniciar sessão no painel de validações como Joana Pina, o atalho “Gestão de PINs” ficou visível no cabeçalho e encaminha para `/gestao-validadores`. A sessão antiga sem esta permissão é descartada, pedindo uma nova autenticação segura.

O perfil Gestão foi também autenticado no painel `/gestao-validadores`. Ao contrário da Qualidade, este perfil mantém a criação de novos validadores e as ações de ativar, desativar e eliminar, além da alteração de PINs.

Em sessão autenticada da Qualidade, o painel de validações foi verificado sob uma largura de 390 px. O atalho “Gestão de PINs” manteve-se visível no cabeçalho compacto e a navegação pelo atalho abriu o painel `/gestao-validadores` com as ações de PIN disponíveis.

Uma validação automatizada real em Chromium, com viewport de 390 × 844 px, autenticou Joana Pina, confirmou o botão “Gestão de PINs” e navegou para `/gestao-validadores`. Foram guardadas capturas no arquivo de validação externo ao projeto para auditoria interna.

Foi executada a verificação não destrutiva da cópia mais recente através do mesmo caminho de integridade usado no restauro: checksum confirmado, formato reconhecido e contagens de intervenções, anexos, áreas, equipamentos e alterações verificadas. A tentativa de criar uma base temporária isolada foi rejeitada pelas permissões restritas da conta de dados, pelo que não foi executado qualquer restauro sobre os dados operacionais.
