import "dotenv/config";
import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerStorageProxy } from "../server/_core/storageProxy";
import { appRouter } from "../server/routers";
import { createContext } from "../server/_core/context";
import { executarBackupSemanal } from "../server/scheduled/backups";

const app = express();
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));
registerStorageProxy(app);
app.get("/api/scheduled/backup-semanal", executarBackupSemanal);
app.post("/api/scheduled/backup-semanal", executarBackupSemanal);
app.use(
  "/api/trpc",
  createExpressMiddleware({ router: appRouter, createContext }),
);

export default app;
