import { prepararRestauroBackup } from "../server/services/backups.ts";

const backupId = process.argv[2];
if (!backupId) throw new Error("Indique o ID do backup a verificar.");

const { backup, snapshot } = await prepararRestauroBackup(backupId);
const campos = ["intervencoes", "anexos", "areasCustom", "equipamentosCustom", "equipamentosOverride"];
for (const campo of campos) {
  if (!Array.isArray(snapshot?.dados?.[campo])) throw new Error(`Snapshot sem coleção válida: ${campo}.`);
}

console.log(JSON.stringify({
  ok: true,
  backupId: backup.id,
  checksumVerificado: true,
  versaoSnapshot: snapshot.versao,
  colecoes: Object.fromEntries(campos.map(campo => [campo, snapshot.dados[campo].length])),
  operacao: "Verificação não destrutiva; nenhum dado operacional foi alterado.",
}, null, 2));

process.exit(0);
