import "dotenv/config";
import { mkdir, writeFile } from "node:fs/promises";
import { createConnection } from "mysql2/promise";

const tables = [
  "users",
  "intervencoes",
  "anexos",
  "areas_custom",
  "equipamentos_custom",
  "equipamentos_override",
  "validadores_acesso",
  "configuracao_backups",
  "backups_aplicacao",
  "execucoes_backups",
];

if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL é obrigatória.");
const connection = await createConnection(process.env.DATABASE_URL);
try {
  const data = {};
  for (const table of tables) {
    const [rows] = await connection.query(`SELECT * FROM \`${table}\``);
    data[table] = rows;
  }
  const payload = {
    format: "dashboard-manutencao-preventiva-mysql-export",
    version: 1,
    exportedAt: new Date().toISOString(),
    tables: data,
  };
  await mkdir("exports", { recursive: true });
  const filename = `exports/dashboard-manutencao-export-${new Date().toISOString().slice(0, 10)}.json`;
  await writeFile(filename, JSON.stringify(payload, null, 2) + "\n", "utf8");
  console.log(`Exportação concluída: ${filename}`);
} finally {
  await connection.end();
}
