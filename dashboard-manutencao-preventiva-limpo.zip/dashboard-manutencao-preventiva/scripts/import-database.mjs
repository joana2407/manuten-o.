import "dotenv/config";
import { readFile } from "node:fs/promises";
import { createConnection } from "mysql2/promise";

const filename = process.argv[2];
if (!filename) throw new Error("Indique o ficheiro JSON: pnpm db:import -- exports/ficheiro.json");
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL é obrigatória.");
const payload = JSON.parse(await readFile(filename, "utf8"));
if (payload.format !== "dashboard-manutencao-preventiva-mysql-export" || payload.version !== 1 || !payload.tables) {
  throw new Error("Formato de exportação inválido.");
}

const order = [
  "users",
  "intervencoes",
  "anexos",
  "areas_custom",
  "equipamentos_custom",
  "equipamentos_override",
  "validadores_acesso",
  "configuracao_backups",
  "backups_aplicacao",
  "execucoes_backups",
];
const connection = await createConnection(process.env.DATABASE_URL);
try {
  await connection.beginTransaction();
  await connection.query("SET FOREIGN_KEY_CHECKS=0");
  for (const table of [...order].reverse()) await connection.query(`TRUNCATE TABLE \`${table}\``);
  for (const table of order) {
    const rows = payload.tables[table] ?? [];
    for (const row of rows) {
      const columns = Object.keys(row);
      if (!columns.length) continue;
      const placeholders = columns.map(() => "?").join(", ");
      await connection.query(
        `INSERT INTO \`${table}\` (${columns.map(column => `\`${column}\``).join(", ")}) VALUES (${placeholders})`,
        columns.map(column => row[column]),
      );
    }
  }
  await connection.query("SET FOREIGN_KEY_CHECKS=1");
  await connection.commit();
  console.log(`Importação concluída: ${filename}`);
} catch (error) {
  await connection.rollback();
  throw error;
} finally {
  await connection.end();
}
