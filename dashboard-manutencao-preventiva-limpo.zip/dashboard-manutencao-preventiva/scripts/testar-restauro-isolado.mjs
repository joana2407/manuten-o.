import { createHash, randomUUID } from "node:crypto";
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import mysql from "mysql2/promise";

const originalUrl = process.env.DATABASE_URL;
if (!originalUrl) throw new Error("DATABASE_URL não está configurada.");

const origem = await mysql.createConnection(originalUrl);
const [backups] = await origem.query(
  "SELECT id, nome_ficheiro, storage_key, checksum, criadoEm, expiraEm FROM backups_aplicacao WHERE estado = 'concluido' ORDER BY criadoEm DESC LIMIT 1",
);
const backup = backups[0];
if (!backup) throw new Error("Não existe uma cópia concluída para testar.");

const { storageGetSignedUrl } = await import("../server/storage.ts");
const snapshotUrl = await storageGetSignedUrl(backup.storage_key);
const resposta = await fetch(snapshotUrl);
if (!resposta.ok) throw new Error(`Não foi possível obter o snapshot (${resposta.status}).`);
const conteudo = await resposta.text();
if (createHash("sha256").update(conteudo).digest("hex") !== backup.checksum) {
  throw new Error("O checksum do snapshot não corresponde ao registo de backup.");
}
const snapshot = JSON.parse(conteudo);

const url = new URL(originalUrl);
const baseTemporaria = `backup_restore_test_${randomUUID().replaceAll("-", "").slice(0, 16)}`;
const rootUrl = new URL(url);
rootUrl.pathname = "/";
await origem.end();

let raiz;
try {
  raiz = await mysql.createConnection(rootUrl.toString());
  await raiz.query(`CREATE DATABASE \`${baseTemporaria}\``);
  const urlTemporaria = new URL(originalUrl);
  urlTemporaria.pathname = `/${baseTemporaria}`;

  const ligacaoTemporaria = await mysql.createConnection(urlTemporaria.toString());
  const pastaMigrations = path.resolve(import.meta.dirname, "..", "drizzle");
  const migrations = (await readdir(pastaMigrations)).filter(nome => nome.endsWith(".sql")).sort();
  for (const migration of migrations) {
    const sql = await readFile(path.join(pastaMigrations, migration), "utf8");
    for (const declaracao of sql.split("--> statement-breakpoint").map(item => item.trim()).filter(Boolean)) {
      await ligacaoTemporaria.query(declaracao);
    }
  }
  await ligacaoTemporaria.end();

  process.env.DATABASE_URL = urlTemporaria.toString();
  const { getDb } = await import("../server/db.ts");
  const { backupsAplicacao, configuracaoBackups, intervencoes, anexos, areasCustom, equipamentosCustom, equipamentosOverride } = await import("../drizzle/schema.ts");
  const { restaurarBackup } = await import("../server/services/backups.ts");
  const db = await getDb();
  if (!db) throw new Error("Não foi possível inicializar a base temporária.");

  await db.insert(configuracaoBackups).values({
    id: "backup-semanal-manutencao", ativo: true, retencaoSemanas: 12, atualizadoEm: Date.now(),
  });
  await db.insert(backupsAplicacao).values({
    id: backup.id, origem: "automatico", estado: "concluido", nomeFicheiro: backup.nome_ficheiro,
    storageKey: backup.storage_key, tamanhoBytes: Buffer.byteLength(conteudo, "utf8"), checksum: backup.checksum,
    criadoEm: Number(backup.criadoEm), expiraEm: Number(backup.expiraEm),
  });

  // O restauro real é executado sobre a base temporária. A cópia pré-restauro é simulada para não gravar objetos adicionais.
  await restaurarBackup(backup.id, "teste-isolado", async () => ({ id: "pre-restauro-simulado" }));
  const [resultadoIntervencoes, resultadoAnexos, resultadoAreas, resultadoEquipamentos, resultadoOverrides] = await Promise.all([
    db.select().from(intervencoes), db.select().from(anexos), db.select().from(areasCustom),
    db.select().from(equipamentosCustom), db.select().from(equipamentosOverride),
  ]);
  const esperado = snapshot.dados;
  const verificado = {
    intervencoes: resultadoIntervencoes.length === esperado.intervencoes.length,
    anexos: resultadoAnexos.length === esperado.anexos.length,
    areasCustom: resultadoAreas.length === esperado.areasCustom.length,
    equipamentosCustom: resultadoEquipamentos.length === esperado.equipamentosCustom.length,
    equipamentosOverride: resultadoOverrides.length === esperado.equipamentosOverride.length,
  };
  if (!Object.values(verificado).every(Boolean)) throw new Error(`Contagens restauradas não correspondem ao snapshot: ${JSON.stringify(verificado)}`);

  console.log(JSON.stringify({ ok: true, backupId: backup.id, verificado, ambiente: baseTemporaria, dadosOperacionaisAlterados: false }, null, 2));
} finally {
  if (raiz) {
    await raiz.query(`DROP DATABASE IF EXISTS \`${baseTemporaria}\``);
    await raiz.end();
  }
  process.exit(0);
}
