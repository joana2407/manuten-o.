import { chromium } from "playwright-core";
import { mkdir } from "node:fs/promises";

const pinQualidade = process.env.TEST_QUALITY_PIN;
if (!pinQualidade) throw new Error("Defina TEST_QUALITY_PIN apenas para a execução desta validação.");

const outputDir = "/home/ubuntu/webdev-static-assets/dashboard-manutencao-preventiva";
await mkdir(outputDir, { recursive: true });
const browser = await chromium.launch({ executablePath: "/usr/bin/chromium", headless: true, args: ["--no-sandbox"] });
try {
  const page = await browser.newPage({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 1 });
  await page.goto("http://localhost:3000/validacoes", { waitUntil: "networkidle" });
  await page.getByRole("option", { name: /Joana Pina/i }).click();
  await page.getByPlaceholder("Introduza o seu PIN").fill(pinQualidade);
  await page.getByRole("button", { name: "Entrar" }).click();
  await page.getByRole("button", { name: "Gestão de PINs" }).waitFor();
  await page.screenshot({ path: `${outputDir}/validacoes-qualidade-390px.png`, fullPage: true });
  await page.getByRole("button", { name: "Gestão de PINs" }).click();
  await page.waitForURL("**/gestao-validadores");
  await page.screenshot({ path: `${outputDir}/gestao-pins-390px.png`, fullPage: true });
  console.log(JSON.stringify({
    ok: true,
    viewport: "390x844",
    atalhoVisivel: true,
    rotaDestino: new URL(page.url()).pathname,
    capturas: ["validacoes-qualidade-390px.png", "gestao-pins-390px.png"],
  }, null, 2));
} finally {
  await browser.close();
}
